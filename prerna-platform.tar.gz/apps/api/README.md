# Prerna API

Run from the repository root:

```powershell
python -m uvicorn prerna_api.main:app --app-dir apps/api/src --reload --port 8000
```

The first increment uses an in-memory repository and simulated records so the approval workflow can be reviewed before the PostgreSQL/Alembic foundation is introduced. Demo credentials are documented in the web app login screen and must never be used outside local development.
