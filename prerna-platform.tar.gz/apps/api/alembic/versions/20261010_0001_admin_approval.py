"""Create admin approval foundation.

Revision ID: 20261010_0001
Revises:
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20261010_0001"
down_revision: str | None = None
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "admin_users",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("name", sa.String(160), nullable=False),
        sa.Column("email", sa.String(320), nullable=False),
        sa.Column("password_hash", sa.Text(), nullable=False),
        sa.Column("is_active", sa.Boolean(), server_default=sa.true(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_admin_users_email", "admin_users", ["email"], unique=True)
    op.create_table(
        "admin_login_attempts",
        sa.Column("key_hash", sa.String(64), primary_key=True),
        sa.Column("failed_count", sa.Integer(), nullable=False),
        sa.Column("window_started_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("blocked_until", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_table(
        "admin_sessions",
        sa.Column("token_hash", sa.String(64), primary_key=True),
        sa.Column(
            "admin_user_id",
            sa.String(36),
            sa.ForeignKey("admin_users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("revoked_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_admin_sessions_admin_user_id", "admin_sessions", ["admin_user_id"])
    op.create_index("ix_admin_sessions_expires_at", "admin_sessions", ["expires_at"])
    op.create_table(
        "donation_requests",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("donor_name", sa.String(200), nullable=False),
        sa.Column("donor_email", sa.String(320), nullable=False),
        sa.Column("donor_mobile", sa.String(40), nullable=False),
        sa.Column("amount", sa.Numeric(14, 2), nullable=False),
        sa.Column("programmes", sa.JSON(), nullable=False),
        sa.Column("frequency", sa.String(30), nullable=False),
        sa.Column("verification_status", sa.String(40), nullable=False),
        sa.Column("returning_donor", sa.Boolean(), server_default=sa.false(), nullable=False),
        sa.Column("submitted_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("status", sa.String(40), nullable=False),
        sa.Column("decided_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("decided_by", sa.String(36), sa.ForeignKey("admin_users.id"), nullable=True),
        sa.Column("internal_note", sa.Text(), nullable=True),
    )
    op.create_index("ix_donation_requests_status", "donation_requests", ["status"])
    op.create_index("ix_donation_requests_submitted_at", "donation_requests", ["submitted_at"])
    op.create_table(
        "approval_actions",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "donation_request_id",
            sa.String(40),
            sa.ForeignKey("donation_requests.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column("decision", sa.String(20), nullable=False),
        sa.Column(
            "admin_user_id",
            sa.String(36),
            sa.ForeignKey("admin_users.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column("internal_note", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("donation_request_id", name="uq_approval_actions_request"),
    )
    op.create_index("ix_approval_actions_donation_request_id", "approval_actions", ["donation_request_id"])


def downgrade() -> None:
    op.drop_table("approval_actions")
    op.drop_table("donation_requests")
    op.drop_table("admin_sessions")
    op.drop_table("admin_login_attempts")
    op.drop_table("admin_users")
