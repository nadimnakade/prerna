"""secure payment link retry material

Revision ID: 20261013_0005
Revises: 20261013_0004
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20261013_0005"
down_revision: str | None = "20261013_0004"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column("payment_links", sa.Column("encrypted_token", sa.Text(), nullable=True))
    op.add_column("payment_links", sa.Column("provider_link_url", sa.Text(), nullable=True))
    op.execute("UPDATE payment_links SET encrypted_token = '', provider_link_url = ''")
    op.alter_column("payment_links", "encrypted_token", nullable=False)
    op.alter_column("payment_links", "provider_link_url", nullable=False)


def downgrade() -> None:
    op.drop_column("payment_links", "provider_link_url")
    op.drop_column("payment_links", "encrypted_token")
