"""add donation journey verification and idempotency

Revision ID: 20261013_0004
Revises: 20261012_0003
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20261013_0004"
down_revision: str | None = "20261012_0003"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column("donation_requests", sa.Column("client_submission_id", sa.String(length=64), nullable=True))
    op.create_unique_constraint("uq_donation_request_submission", "donation_requests", ["client_submission_id"])
    op.create_table(
        "verification_sessions",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("provider", sa.String(length=60), nullable=False),
        sa.Column("target_digest", sa.String(length=64), nullable=False),
        sa.Column("code_digest", sa.String(length=64), nullable=False),
        sa.Column("send_count", sa.Integer(), nullable=False),
        sa.Column("failed_attempts", sa.Integer(), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("verified_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_verification_sessions_target_digest", "verification_sessions", ["target_digest"])
    op.create_index("ix_verification_sessions_expires_at", "verification_sessions", ["expires_at"])


def downgrade() -> None:
    op.drop_index("ix_verification_sessions_expires_at", table_name="verification_sessions")
    op.drop_index("ix_verification_sessions_target_digest", table_name="verification_sessions")
    op.drop_table("verification_sessions")
    op.drop_constraint("uq_donation_request_submission", "donation_requests", type_="unique")
    op.drop_column("donation_requests", "client_submission_id")
