"""Add auditable admin master records.

Revision ID: 20261012_0003
Revises: 4e019e704c16
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20261012_0003"
down_revision: str | None = "4e019e704c16"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column("programmes", sa.Column("wordpress_slug", sa.String(160), nullable=True))
    op.add_column("programmes", sa.Column("updated_by", sa.String(36), nullable=True))
    op.add_column("programmes", sa.Column("created_at", sa.DateTime(timezone=True), nullable=True))
    op.add_column("programmes", sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True))
    op.create_unique_constraint("uq_programmes_wordpress_slug", "programmes", ["wordpress_slug"])
    op.create_foreign_key(
        "fk_programmes_updated_by", "programmes", "admin_users", ["updated_by"], ["id"], ondelete="RESTRICT"
    )
    op.execute("UPDATE programmes SET created_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP")
    op.alter_column("programmes", "created_at", nullable=False)
    op.alter_column("programmes", "updated_at", nullable=False)

    op.add_column("business_settings", sa.Column("updated_by", sa.String(36), nullable=True))
    op.create_foreign_key(
        "fk_business_settings_updated_by",
        "business_settings",
        "admin_users",
        ["updated_by"],
        ["id"],
        ondelete="RESTRICT",
    )

    op.create_table(
        "master_records",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("category", sa.String(40), nullable=False),
        sa.Column("code", sa.String(60), nullable=False),
        sa.Column("name", sa.String(180), nullable=False),
        sa.Column("configuration", sa.JSON(), nullable=False),
        sa.Column("is_active", sa.Boolean(), server_default=sa.true(), nullable=False),
        sa.Column("updated_by", sa.String(36), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["updated_by"], ["admin_users.id"], ondelete="RESTRICT"),
        sa.UniqueConstraint("category", "code", name="uq_master_category_code"),
    )
    op.create_index("ix_master_records_category", "master_records", ["category"])


def downgrade() -> None:
    op.drop_index("ix_master_records_category", table_name="master_records")
    op.drop_table("master_records")
    op.drop_constraint("fk_business_settings_updated_by", "business_settings", type_="foreignkey")
    op.drop_column("business_settings", "updated_by")
    op.drop_constraint("fk_programmes_updated_by", "programmes", type_="foreignkey")
    op.drop_constraint("uq_programmes_wordpress_slug", "programmes", type_="unique")
    op.drop_column("programmes", "updated_at")
    op.drop_column("programmes", "created_at")
    op.drop_column("programmes", "updated_by")
    op.drop_column("programmes", "wordpress_slug")
