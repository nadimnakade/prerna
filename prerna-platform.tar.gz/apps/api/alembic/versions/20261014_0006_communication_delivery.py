"""communication delivery recovery fields

Revision ID: 20261014_0006
Revises: 20261013_0005
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20261014_0006"
down_revision: str | None = "20261013_0005"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column("communications", sa.Column("attempt_count", sa.Integer(), server_default="0", nullable=False))
    op.add_column("communications", sa.Column("last_error", sa.Text(), nullable=True))


def downgrade() -> None:
    op.drop_column("communications", "last_error")
    op.drop_column("communications", "attempt_count")
