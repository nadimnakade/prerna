import hashlib
import hmac
import json
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .domain_services import InvariantViolation, allocate_receipt_number
from .models import DonationRequestModel
from .records import (
    CommunicationModel,
    DonorPreferenceModel,
    OfflineCollectionModel,
    PaymentLinkModel,
    PaymentModel,
    ProviderEventModel,
    ReceiptModel,
)
from .settings import Settings


def verify_razorpay_signature(body: bytes, signature: str | None, secret: str) -> bool:
    if not signature:
        return False
    expected = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature)


def ingest_event(session: Session, provider: str, body: bytes) -> tuple[ProviderEventModel, bool]:
    payload = json.loads(body)
    event_id = str(payload.get("id", "")).strip()
    event_type = str(payload.get("event", "")).strip()
    if not event_id or not event_type:
        raise InvariantViolation("Provider event id and type are required")
    row = ProviderEventModel(provider=provider, provider_event_id=event_id, event_type=event_type, payload=payload)
    try:
        session.add(row)
        session.commit()
        return row, True
    except IntegrityError:
        session.rollback()
        existing = session.scalar(
            select(ProviderEventModel).where(
                ProviderEventModel.provider == provider, ProviderEventModel.provider_event_id == event_id
            )
        )
        return existing, False  # type: ignore[return-value]


def _financial_year(moment: datetime) -> str:
    year = moment.year if moment.month >= 4 else moment.year - 1
    return f"{year}-{str(year + 1)[2:]}"


def _receipt_pdf(number: str, donor: str, amount: Decimal, paid_at: datetime) -> bytes:
    text = f"Prerna Donation Receipt | {number} | Donor: {donor} | Amount: INR {amount:.2f} | Date: {paid_at.date()}"
    safe = text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
    stream = f"BT /F1 11 Tf 50 760 Td ({safe}) Tj ET".encode()
    parts = [
        b"%PDF-1.4\n",
        b"1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n",
        b"2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n",
        b"3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]"
        b"/Resources<</Font<</F1 4 0 R>>>>/Contents 5 0 R>>endobj\n",
        b"4 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj\n",
        f"5 0 obj<</Length {len(stream)}>>stream\n".encode() + stream + b"\nendstream endobj\n",
        b"trailer<</Root 1 0 R>>\n%%EOF",
    ]
    return b"".join(parts)


def create_receipt(session: Session, payment: PaymentModel, settings: Settings) -> ReceiptModel:
    existing = session.scalar(select(ReceiptModel).where(ReceiptModel.payment_id == payment.id))
    if existing:
        return existing
    request = session.get(DonationRequestModel, payment.donation_request_id)
    if request is None or request.donor_id is None:
        raise InvariantViolation("A receipt requires a donor")
    paid_at = payment.paid_at or datetime.now(UTC)
    fy = _financial_year(paid_at)
    sequence, number = allocate_receipt_number(session, fy)
    target = Path(settings.receipt_storage_path) / fy / f"{number.replace('/', '-')}.pdf"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(_receipt_pdf(number, request.donor_name, payment.amount, paid_at))
    receipt = ReceiptModel(
        payment_id=payment.id,
        donor_id=request.donor_id,
        receipt_number=number,
        financial_year=fy,
        sequence_value=sequence,
        document_key=str(target),
    )
    request.status = "RECEIPTED"
    session.add(receipt)
    session.add(
        CommunicationModel(
            donor_id=request.donor_id,
            donation_request_id=request.id,
            channel="EMAIL",
            template_key="receipt_issued",
            provider="pending",
            status="PENDING",
        )
    )
    session.commit()
    return receipt


def process_event(session: Session, event_id: str, settings: Settings) -> ProviderEventModel:
    event = session.scalar(select(ProviderEventModel).where(ProviderEventModel.id == event_id).with_for_update())
    if event is None:
        raise LookupError(event_id)
    if event.processed_at:
        return event
    try:
        if event.event_type not in {"payment.captured", "payment.failed"}:
            raise InvariantViolation("Unsupported payment event")
        entity = event.payload["payload"]["payment"]["entity"]
        link_ref = entity.get("notes", {}).get("payment_link_id") or entity.get("payment_link_id")
        link = session.scalar(select(PaymentLinkModel).where(PaymentLinkModel.provider_link_id == link_ref))
        if link is None:
            raise InvariantViolation("Unknown payment link")
        request = session.get(DonationRequestModel, link.donation_request_id)
        amount = Decimal(entity["amount"]) / 100
        if request is None or amount != Decimal(request.amount):
            raise InvariantViolation("Payment amount mismatch")
        payment = session.scalar(
            select(PaymentModel).where(
                PaymentModel.provider == event.provider, PaymentModel.provider_payment_id == entity["id"]
            )
        )
        if payment is None:
            payment = PaymentModel(
                donation_request_id=request.id,
                payment_link_id=link.id,
                provider=event.provider,
                provider_payment_id=entity["id"],
                amount=amount,
                currency=entity.get("currency", "INR"),
                status="CAPTURED" if event.event_type == "payment.captured" else "FAILED",
                paid_at=datetime.now(UTC) if event.event_type == "payment.captured" else None,
            )
            session.add(payment)
            session.flush()
        if event.event_type == "payment.failed":
            request.status = "FAILED_OR_LAPSED"
        else:
            request.status = "PAID"
        event.processed_at = datetime.now(UTC)
        session.commit()
        if payment.status == "CAPTURED":
            create_receipt(session, payment, settings)
        return event
    except (KeyError, ValueError, InvariantViolation) as exc:
        session.rollback()
        event = session.get(ProviderEventModel, event_id)
        event.processing_error = str(exc)
        event.processed_at = datetime.now(UTC)
        session.commit()
        return event


def record_offline(
    session: Session, request_id: str, admin_id: str, mode: str, reference: str, received_on: datetime, amount: Decimal
) -> OfflineCollectionModel:
    request = session.scalar(
        select(DonationRequestModel).where(DonationRequestModel.id == request_id).with_for_update()
    )
    if request is None:
        raise LookupError(request_id)
    if request.status != "APPROVED" or amount != Decimal(request.amount):
        raise InvariantViolation("Offline collection requires an approved request with the exact amount")
    row = OfflineCollectionModel(
        donation_request_id=request.id,
        mode=mode,
        reference=reference,
        amount=amount,
        received_on=received_on.date(),
        recorded_by=admin_id,
    )
    request.source = "OFFLINE"
    request.status = "OFFLINE_RECORDED"
    session.add(row)
    session.commit()
    return row


def confirm_offline(session: Session, request_id: str, admin_id: str, settings: Settings) -> ReceiptModel:
    collection = session.scalar(
        select(OfflineCollectionModel).where(OfflineCollectionModel.donation_request_id == request_id).with_for_update()
    )
    request = session.get(DonationRequestModel, request_id)
    if collection is None or request is None or request.status != "OFFLINE_RECORDED" or collection.confirmed_at:
        raise InvariantViolation("Offline collection is not awaiting finance confirmation")
    collection.confirmed_by = admin_id
    collection.confirmed_at = datetime.now(UTC)
    payment = PaymentModel(
        donation_request_id=request.id,
        provider="offline",
        provider_payment_id=f"offline:{collection.id}",
        amount=collection.amount,
        currency="INR",
        status="CAPTURED",
        paid_at=collection.confirmed_at,
    )
    request.status = "PAID"
    session.add(payment)
    session.commit()
    return create_receipt(session, payment, settings)


def deliver_communication(session: Session, communication_id: str) -> CommunicationModel:
    row = session.scalar(select(CommunicationModel).where(CommunicationModel.id == communication_id).with_for_update())
    if row is None:
        raise LookupError(communication_id)
    if row.status == "SENT":
        return row
    preference = session.scalar(select(DonorPreferenceModel).where(DonorPreferenceModel.donor_id == row.donor_id))
    allowed = {
        "EMAIL": preference is None or preference.email_opt_in,
        "SMS": preference is None or preference.sms_opt_in,
        "WHATSAPP": preference is not None and preference.whatsapp_opt_in,
    }.get(row.channel, False)
    row.attempt_count += 1
    if not allowed:
        row.status = "SUPPRESSED"
        row.last_error = "Donor has not consented to this channel"
    else:
        row.status = "SENT"
        row.provider = "local"
        row.provider_message_id = row.provider_message_id or f"local:{row.id}"
        row.sent_at = datetime.now(UTC)
        row.last_error = None
    session.commit()
    return row
