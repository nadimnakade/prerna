import hashlib
import hmac
import re
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Protocol
from uuid import uuid4

from fastapi import APIRouter, Depends, Header, HTTPException, status
from pydantic import BaseModel, Field, field_validator, model_validator
from sqlalchemy import func, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .database import get_db
from .models import DonationRequestModel
from .protected_identifiers import IdentifierProtector, ProtectedIdentifierError
from .records import (
    DonorAddressModel,
    DonorModel,
    DonorPreferenceModel,
    ProgrammeModel,
    ProtectedIdentifierModel,
    RequestProgrammeModel,
    VerificationAttemptModel,
    VerificationSessionModel,
    WorkflowHistoryModel,
)
from .settings import get_settings

router = APIRouter(prefix="/api/v1/donations", tags=["donations"])
settings = get_settings()


def normalize_email(value: str) -> str:
    return value.strip().casefold()


def normalize_mobile(value: str) -> str:
    digits = re.sub(r"\D", "", value)
    if len(digits) == 10:
        digits = "91" + digits
    if len(digits) < 10 or len(digits) > 15:
        raise ValueError("Enter a valid mobile number")
    return "+" + digits


def digest(value: str) -> str:
    return hmac.new(settings.identifier_matching_key.encode(), value.encode(), hashlib.sha256).hexdigest()


class VerificationProvider(Protocol):
    name: str

    def issue_code(self) -> str: ...

    def verify_identity(self, identifier: str) -> bool: ...


class LocalVerificationProvider:
    name = "local"

    def issue_code(self) -> str:
        return "123456"

    def verify_identity(self, identifier: str) -> bool:
        normalized = re.sub(r"[^A-Za-z0-9]", "", identifier).upper()
        return len(normalized) >= 4 and not normalized.endswith("0000")


def verification_provider() -> VerificationProvider:
    providers: dict[str, VerificationProvider] = {"local": LocalVerificationProvider()}
    return providers[settings.verification_provider]


class VerificationStartInput(BaseModel):
    email: str = Field(min_length=5, max_length=320)
    mobile: str = Field(min_length=10, max_length=40)

    @field_validator("email")
    @classmethod
    def valid_email(cls, value: str) -> str:
        normalized = normalize_email(value)
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", normalized):
            raise ValueError("Enter a valid email address")
        return normalized

    @field_validator("mobile")
    @classmethod
    def valid_mobile(cls, value: str) -> str:
        return normalize_mobile(value)


class VerificationStartOutput(BaseModel):
    verification_token: str
    expires_at: datetime
    retry_after_seconds: int = 30
    development_code: str | None = None


class VerificationConfirmInput(BaseModel):
    verification_token: str
    code: str = Field(pattern=r"^\d{6}$")


class VerificationConfirmOutput(BaseModel):
    verified: bool


@router.post("/verification/start", response_model=VerificationStartOutput, status_code=status.HTTP_201_CREATED)
def start_verification(payload: VerificationStartInput, db: Session = Depends(get_db)) -> VerificationStartOutput:
    now = datetime.now(UTC)
    target = digest(payload.email + "|" + payload.mobile)
    recent = db.scalar(
        select(func.count())
        .select_from(VerificationSessionModel)
        .where(
            VerificationSessionModel.target_digest == target,
            VerificationSessionModel.created_at >= now - timedelta(hours=1),
        )
    )
    if recent and recent >= 5:
        raise HTTPException(status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail="Too many verification requests")
    provider = verification_provider()
    code = provider.issue_code()
    row = VerificationSessionModel(
        provider=provider.name,
        target_digest=target,
        code_digest=digest(code),
        expires_at=now + timedelta(minutes=settings.verification_otp_minutes),
    )
    db.add(row)
    db.commit()
    return VerificationStartOutput(
        verification_token=row.id,
        expires_at=row.expires_at,
        development_code=code if settings.environment in {"development", "test"} else None,
    )


@router.post("/verification/confirm", response_model=VerificationConfirmOutput)
def confirm_verification(payload: VerificationConfirmInput, db: Session = Depends(get_db)) -> VerificationConfirmOutput:
    row = db.get(VerificationSessionModel, payload.verification_token)
    now = datetime.now(UTC)
    if row is None or row.expires_at.replace(tzinfo=row.expires_at.tzinfo or UTC) <= now:
        raise HTTPException(status_code=status.HTTP_410_GONE, detail="Verification code expired")
    if row.failed_attempts >= 5:
        raise HTTPException(status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail="Too many incorrect attempts")
    if not hmac.compare_digest(row.code_digest, digest(payload.code)):
        row.failed_attempts += 1
        db.commit()
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Verification code is incorrect")
    row.verified_at = now
    db.commit()
    return VerificationConfirmOutput(verified=True)


class AddressInput(BaseModel):
    line1: str = Field(min_length=3, max_length=240)
    line2: str | None = Field(default=None, max_length=240)
    city: str = Field(min_length=2, max_length=120)
    state: str = Field(min_length=2, max_length=120)
    postal_code: str = Field(pattern=r"^[1-9][0-9]{5}$")
    country_code: str = Field(default="IN", pattern=r"^[A-Z]{2}$")


class PreferencesInput(BaseModel):
    consent_confirmed: bool
    email: bool = False
    sms: bool = False
    whatsapp: bool = False

    @model_validator(mode="after")
    def consent_is_explicit(self) -> "PreferencesInput":
        if not self.consent_confirmed:
            raise ValueError("Communication preferences require explicit consent")
        return self


class DonationSubmissionInput(BaseModel):
    verification_token: str
    name: str = Field(min_length=2, max_length=200)
    email: str = Field(min_length=5, max_length=320)
    mobile: str = Field(min_length=10, max_length=40)
    address: AddressInput
    identifier_type: str = Field(default="PAN", pattern=r"^[A-Z][A-Z0-9_]{1,23}$")
    protected_identifier: str = Field(min_length=4, max_length=40)
    programme_slugs: list[str] = Field(min_length=1, max_length=10)
    frequency: str = Field(pattern=r"^(ONE_TIME|MONTHLY)$")
    amount: Decimal = Field(gt=0, max_digits=14, decimal_places=2)
    purpose: str | None = Field(default=None, max_length=500)
    terms_accepted: bool
    preferences: PreferencesInput | None = None

    @field_validator("email")
    @classmethod
    def normalize_valid_email(cls, value: str) -> str:
        return VerificationStartInput.valid_email(value)

    @field_validator("mobile")
    @classmethod
    def normalize_valid_mobile(cls, value: str) -> str:
        return normalize_mobile(value)

    @field_validator("programme_slugs")
    @classmethod
    def normalize_slugs(cls, values: list[str]) -> list[str]:
        return list(dict.fromkeys(value.strip().lower() for value in values))

    @model_validator(mode="after")
    def terms_are_required(self) -> "DonationSubmissionInput":
        if not self.terms_accepted:
            raise ValueError("Donation terms must be accepted")
        return self


class DonationSubmissionOutput(BaseModel):
    request_id: str
    status: str
    masked_identifier: str
    masked_email: str
    masked_mobile: str
    returning_donor: bool


def masked_email(value: str) -> str:
    local, domain = value.split("@", 1)
    return local[:1] + "***@" + domain


def masked_mobile(value: str) -> str:
    return value[:3] + "••••••" + value[-4:]


@router.post("/requests", response_model=DonationSubmissionOutput, status_code=status.HTTP_201_CREATED)
def submit_donation(
    payload: DonationSubmissionInput,
    idempotency_key: str = Header(min_length=16, max_length=64, alias="Idempotency-Key"),
    db: Session = Depends(get_db),
) -> DonationSubmissionOutput:
    existing = db.scalar(
        select(DonationRequestModel).where(DonationRequestModel.client_submission_id == idempotency_key)
    )
    if existing:
        protected = db.scalar(
            select(ProtectedIdentifierModel).where(ProtectedIdentifierModel.donor_id == existing.donor_id)
        )
        return submission_output(existing, protected.masked_value if protected else "••••")

    verification = db.get(VerificationSessionModel, payload.verification_token)
    now = datetime.now(UTC)
    target = digest(payload.email + "|" + payload.mobile)
    if (
        verification is None
        or verification.verified_at is None
        or verification.expires_at.replace(tzinfo=verification.expires_at.tzinfo or UTC) <= now
        or not hmac.compare_digest(verification.target_digest, target)
    ):
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Contact verification is required")
    if not verification_provider().verify_identity(payload.protected_identifier):
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Identity verification failed")

    programmes = list(
        db.scalars(
            select(ProgrammeModel).where(
                ProgrammeModel.is_active.is_(True), ProgrammeModel.wordpress_slug.in_(payload.programme_slugs)
            )
        )
    )
    if len(programmes) != len(payload.programme_slugs):
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Select an active programme")

    protector = IdentifierProtector(settings.identifier_encryption_key, settings.identifier_matching_key)
    try:
        encrypted, identifier_digest, identifier_mask = protector.protected_values(payload.protected_identifier)
    except ProtectedIdentifierError as error:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(error)) from error

    contact_matches = list(
        db.scalars(
            select(DonorModel).where(or_(DonorModel.email == payload.email, DonorModel.mobile == payload.mobile))
        )
    )
    identifier_match = db.scalar(
        select(DonorModel)
        .join(ProtectedIdentifierModel, ProtectedIdentifierModel.donor_id == DonorModel.id)
        .where(
            ProtectedIdentifierModel.identifier_type == payload.identifier_type,
            ProtectedIdentifierModel.matching_digest == identifier_digest,
        )
    )
    matches = {row.id: row for row in [*contact_matches, *([identifier_match] if identifier_match else [])]}
    if len(matches) > 1:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Donor details could not be verified"
        )
    donor = next(iter(matches.values()), None)
    returning = donor is not None
    if donor is None:
        donor = DonorModel(display_name=payload.name.strip(), email=payload.email, mobile=payload.mobile)
        db.add(donor)
        db.flush()
        db.add(
            ProtectedIdentifierModel(
                donor_id=donor.id,
                identifier_type=payload.identifier_type,
                encrypted_value=encrypted,
                matching_digest=identifier_digest,
                masked_value=identifier_mask,
                verification_status="VERIFIED",
            )
        )
    else:
        donor_identifier = db.scalar(
            select(ProtectedIdentifierModel).where(
                ProtectedIdentifierModel.donor_id == donor.id,
                ProtectedIdentifierModel.identifier_type == payload.identifier_type,
            )
        )
        if donor_identifier is not None and not hmac.compare_digest(
            donor_identifier.matching_digest, identifier_digest
        ):
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Donor details could not be verified"
            )
        if donor_identifier is None:
            db.add(
                ProtectedIdentifierModel(
                    donor_id=donor.id,
                    identifier_type=payload.identifier_type,
                    encrypted_value=encrypted,
                    matching_digest=identifier_digest,
                    masked_value=identifier_mask,
                    verification_status="VERIFIED",
                )
            )
        donor.display_name = payload.name.strip()
        donor.email = payload.email
        donor.mobile = payload.mobile

    db.add(DonorAddressModel(donor_id=donor.id, **payload.address.model_dump()))
    if payload.preferences is not None:
        preference = db.scalar(select(DonorPreferenceModel).where(DonorPreferenceModel.donor_id == donor.id))
        values = {
            "email_opt_in": payload.preferences.email,
            "sms_opt_in": payload.preferences.sms,
            "whatsapp_opt_in": payload.preferences.whatsapp,
        }
        if preference is None:
            db.add(DonorPreferenceModel(donor_id=donor.id, **values))
        else:
            for key, value in values.items():
                setattr(preference, key, value)

    request = DonationRequestModel(
        id="DR-" + uuid4().hex[:16].upper(),
        client_submission_id=idempotency_key,
        donor_id=donor.id,
        donor_name=donor.display_name,
        donor_email=masked_email(donor.email),
        donor_mobile=masked_mobile(donor.mobile),
        amount=payload.amount,
        programmes=[programme.name for programme in programmes],
        frequency=payload.frequency,
        source="ONLINE",
        purpose=payload.purpose,
        verification_status="VERIFIED",
        returning_donor=returning,
        submitted_at=now,
        status="PENDING_APPROVAL",
    )
    db.add(request)
    db.flush()
    for programme in programmes:
        db.add(RequestProgrammeModel(donation_request_id=request.id, programme_id=programme.id))
    db.add(
        VerificationAttemptModel(
            donation_request_id=request.id,
            verification_type="CONTACT_AND_IDENTITY",
            provider=verification.provider,
            provider_reference=verification.id,
            status="VERIFIED",
            response_code="LOCAL_OK",
        )
    )
    db.add(
        WorkflowHistoryModel(
            donation_request_id=request.id,
            from_state=None,
            action="SUBMIT",
            to_state="PENDING_APPROVAL",
            actor_type="DONOR",
            actor_id=donor.id,
        )
    )
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        existing = db.scalar(
            select(DonationRequestModel).where(DonationRequestModel.client_submission_id == idempotency_key)
        )
        if existing is None:
            raise
        protected = db.scalar(
            select(ProtectedIdentifierModel).where(ProtectedIdentifierModel.donor_id == existing.donor_id)
        )
        return submission_output(existing, protected.masked_value if protected else "••••")
    return submission_output(request, identifier_mask)


def submission_output(request: DonationRequestModel, identifier_mask: str) -> DonationSubmissionOutput:
    return DonationSubmissionOutput(
        request_id=request.id,
        status=request.status,
        masked_identifier=identifier_mask,
        masked_email=request.donor_email,
        masked_mobile=request.donor_mobile,
        returning_donor=request.returning_donor,
    )
