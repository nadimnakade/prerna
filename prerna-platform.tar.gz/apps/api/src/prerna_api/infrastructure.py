from datetime import UTC, datetime, timedelta
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .domain import DonationRequest
from .models import ApprovalActionModel, DonationRequestModel


class InMemoryDonationRequestRepository:
    def __init__(self, requests: list[DonationRequest] | None = None) -> None:
        self._requests = {request.id: request for request in requests or []}

    def list(self) -> list[DonationRequest]:
        return list(self._requests.values())

    def get(self, request_id: str) -> DonationRequest | None:
        return self._requests.get(request_id)

    def save(self, request: DonationRequest) -> None:
        self._requests[request.id] = request


class SqlAlchemyDonationRequestRepository:
    def __init__(self, session: Session) -> None:
        self.session = session

    def list(self) -> list[DonationRequest]:
        rows = self.session.scalars(select(DonationRequestModel).order_by(DonationRequestModel.submitted_at)).all()
        return [self._to_domain(row) for row in rows]

    def get(self, request_id: str) -> DonationRequest | None:
        row = self.session.scalar(
            select(DonationRequestModel).where(DonationRequestModel.id == request_id).with_for_update()
        )
        return self._to_domain(row) if row else None

    def save(self, request: DonationRequest) -> None:
        row = self.session.get(DonationRequestModel, request.id)
        if row is None:
            raise LookupError(request.id)
        row.status = request.status.value
        row.decided_at = request.decided_at
        row.decided_by = request.decided_by
        row.internal_note = request.internal_note
        self.session.add(
            ApprovalActionModel(
                donation_request_id=request.id,
                decision=request.status.value,
                admin_user_id=request.decided_by,
                internal_note=request.internal_note,
                created_at=request.decided_at,
            )
        )
        try:
            self.session.commit()
        except IntegrityError:
            self.session.rollback()
            raise

    @staticmethod
    def _to_domain(row: DonationRequestModel) -> DonationRequest:
        submitted_at = row.submitted_at
        if submitted_at.tzinfo is None:
            submitted_at = submitted_at.replace(tzinfo=UTC)
        decided_at = row.decided_at
        if decided_at is not None and decided_at.tzinfo is None:
            decided_at = decided_at.replace(tzinfo=UTC)
        return DonationRequest(
            id=row.id,
            donor_name=row.donor_name,
            donor_email=row.donor_email,
            donor_mobile=row.donor_mobile,
            amount=row.amount,
            programmes=tuple(row.programmes),
            frequency=row.frequency,
            verification_status=row.verification_status,
            returning_donor=row.returning_donor,
            submitted_at=submitted_at,
            status=row.status,
            decided_at=decided_at,
            decided_by=row.decided_by,
            internal_note=row.internal_note,
        )


def seeded_requests() -> list[DonationRequest]:
    now = datetime.now(UTC)
    return [
        DonationRequest(
            id="DR-2026-0042",
            donor_name="Ananya Mehta",
            donor_email="ananya.mehta@example.org",
            donor_mobile="+91 98••• ••421",
            amount=Decimal("25000"),
            programmes=("Education", "Healthcare"),
            frequency="One-time",
            verification_status="Verified",
            returning_donor=True,
            submitted_at=now - timedelta(hours=53, minutes=18),
        ),
        DonationRequest(
            id="DR-2026-0043",
            donor_name="Vikram Rao",
            donor_email="vikram.rao@example.org",
            donor_mobile="+91 97••• ••806",
            amount=Decimal("5000"),
            programmes=("Sports",),
            frequency="Monthly",
            verification_status="Verified",
            returning_donor=False,
            submitted_at=now - timedelta(hours=19, minutes=42),
        ),
        DonationRequest(
            id="DR-2026-0044",
            donor_name="Neha Shah",
            donor_email="neha.shah@example.org",
            donor_mobile="+91 99••• ••117",
            amount=Decimal("10000"),
            programmes=("Any",),
            frequency="One-time",
            verification_status="Verified",
            returning_donor=False,
            submitted_at=now - timedelta(hours=4, minutes=8),
        ),
    ]
