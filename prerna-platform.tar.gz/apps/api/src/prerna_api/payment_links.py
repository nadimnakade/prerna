import base64
import hashlib
import json
import secrets
import urllib.request
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Protocol
from uuid import uuid4

from cryptography.fernet import Fernet, InvalidToken
from sqlalchemy import select
from sqlalchemy.orm import Session

from .domain_services import InvariantViolation
from .models import DonationRequestModel
from .records import BusinessSettingModel, CommunicationModel, DonorModel, PaymentLinkModel, WorkflowHistoryModel
from .settings import Settings


@dataclass(frozen=True)
class GatewayLink:
    reference: str
    url: str


class PaymentLinkGateway(Protocol):
    name: str

    def create(self, request: DonationRequestModel, donor: DonorModel, expires_at: datetime) -> GatewayLink: ...


class LocalPaymentLinkGateway:
    name = "local"

    def __init__(self, base_url: str) -> None:
        self.base_url = base_url.rstrip("/")

    def create(self, request: DonationRequestModel, donor: DonorModel, expires_at: datetime) -> GatewayLink:
        reference = "local_" + uuid4().hex
        return GatewayLink(reference=reference, url=f"{self.base_url}/{reference}")


class RazorpayPaymentLinkGateway:
    name = "razorpay"

    def __init__(self, key_id: str, key_secret: str) -> None:
        self.authorization = base64.b64encode(f"{key_id}:{key_secret}".encode()).decode()

    def create(self, request: DonationRequestModel, donor: DonorModel, expires_at: datetime) -> GatewayLink:
        payload = json.dumps(
            {
                "amount": int(Decimal(request.amount) * 100),
                "currency": "INR",
                "accept_partial": False,
                "description": f"Prerna donation request {request.id}",
                "expire_by": int(expires_at.timestamp()),
                "reference_id": request.id,
                "customer": {"name": donor.display_name, "email": donor.email, "contact": donor.mobile},
                "notify": {"sms": False, "email": False},
                "reminder_enable": False,
            }
        ).encode()
        call = urllib.request.Request(
            "https://api.razorpay.com/v1/payment_links",
            data=payload,
            method="POST",
            headers={"Authorization": "Basic " + self.authorization, "Content-Type": "application/json"},
        )
        with urllib.request.urlopen(call, timeout=10) as response:  # noqa: S310 - fixed HTTPS provider endpoint
            body = json.loads(response.read())
        return GatewayLink(reference=body["id"], url=body["short_url"])


def gateway(settings: Settings) -> PaymentLinkGateway:
    if settings.payment_gateway == "razorpay":
        if settings.environment != "production":
            raise InvariantViolation("Real Razorpay calls are disabled outside production")
        if not settings.razorpay_key_id or not settings.razorpay_key_secret:
            raise InvariantViolation("Razorpay credentials are not configured")
        return RazorpayPaymentLinkGateway(settings.razorpay_key_id, settings.razorpay_key_secret)
    return LocalPaymentLinkGateway(settings.local_payment_base_url)


def _cipher(settings: Settings) -> Fernet:
    material = hashlib.sha256((settings.identifier_encryption_key + ":payment-links").encode()).digest()
    return Fernet(base64.urlsafe_b64encode(material))


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def link_url(row: PaymentLinkModel, settings: Settings) -> str:
    try:
        token = _cipher(settings).decrypt(row.encrypted_token.encode()).decode()
    except (InvalidToken, ValueError) as exc:
        raise InvariantViolation("The stored payment link cannot be recovered; expire it before reissuing") from exc
    return row.provider_link_url + "#token=" + token


def issue_or_recover_payment_link(
    session: Session, request_id: str, admin_id: str, settings: Settings
) -> tuple[PaymentLinkModel, str, bool]:
    now = datetime.now(UTC)
    request = session.scalar(
        select(DonationRequestModel).where(DonationRequestModel.id == request_id).with_for_update()
    )
    if request is None:
        raise LookupError(request_id)
    existing = session.scalar(
        select(PaymentLinkModel)
        .where(
            PaymentLinkModel.donation_request_id == request_id,
            PaymentLinkModel.used_at.is_(None),
            PaymentLinkModel.expires_at > now,
            PaymentLinkModel.encrypted_token != "",
        )
        .order_by(PaymentLinkModel.created_at.desc())
    )
    if existing is not None:
        return existing, link_url(existing, settings), False
    if request.status not in {"APPROVED", "PAYMENT_LINK_SENT"}:
        raise InvariantViolation("A payment link requires an approved donation request")
    if request.status == "PAYMENT_LINK_SENT":
        previous = session.scalar(
            select(PaymentLinkModel)
            .where(PaymentLinkModel.donation_request_id == request_id)
            .order_by(PaymentLinkModel.created_at.desc())
            .limit(1)
        )
        if previous is None or (
            previous.used_at is None
            and previous.encrypted_token != ""
            and previous.expires_at.replace(tzinfo=previous.expires_at.tzinfo or UTC) > now
        ):
            raise InvariantViolation("An active payment link already exists")
    donor = session.get(DonorModel, request.donor_id) if request.donor_id else None
    if donor is None:
        raise InvariantViolation("The donation request has no donor record")
    validity_setting = session.get(BusinessSettingModel, "payment_link_validity_hours")
    validity = int(validity_setting.value.get("hours", 24)) if validity_setting else 24
    expires_at = now + timedelta(hours=validity)
    adapter = gateway(settings)
    provider_link = adapter.create(request, donor, expires_at)
    raw_token = secrets.token_urlsafe(32)
    row = PaymentLinkModel(
        donation_request_id=request.id,
        provider=adapter.name,
        provider_link_id=provider_link.reference,
        token_hash=hash_token(raw_token),
        encrypted_token=_cipher(settings).encrypt(raw_token.encode()).decode(),
        provider_link_url=provider_link.url,
        created_at=now,
        expires_at=expires_at,
    )
    from_state = request.status
    request.status = "PAYMENT_LINK_SENT"
    session.add(row)
    session.add(
        WorkflowHistoryModel(
            donation_request_id=request.id,
            from_state=from_state,
            action="ISSUE_PAYMENT_LINK",
            to_state="PAYMENT_LINK_SENT",
            actor_type="ADMIN",
            actor_id=admin_id,
        )
    )
    session.add(
        CommunicationModel(
            donor_id=donor.id,
            donation_request_id=request.id,
            channel="EMAIL",
            template_key="payment_link_issued",
            provider="pending",
            status="PENDING",
        )
    )
    session.commit()
    return row, provider_link.url + "#token=" + raw_token, True
