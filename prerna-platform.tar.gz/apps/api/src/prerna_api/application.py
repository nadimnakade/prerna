from collections.abc import Iterable
from dataclasses import dataclass
from typing import Protocol

from .domain import DonationRequest


class DonationRequestRepository(Protocol):
    def list(self) -> Iterable[DonationRequest]: ...

    def get(self, request_id: str) -> DonationRequest | None: ...

    def save(self, request: DonationRequest) -> None: ...


class RequestNotFound(LookupError):
    pass


@dataclass(slots=True)
class ApprovalService:
    repository: DonationRequestRepository

    def list_requests(self) -> list[DonationRequest]:
        return sorted(self.repository.list(), key=lambda item: item.submitted_at)

    def get_request(self, request_id: str) -> DonationRequest:
        request = self.repository.get(request_id)
        if request is None:
            raise RequestNotFound(request_id)
        return request

    def approve(self, request_id: str, *, admin_id: str, note: str | None) -> DonationRequest:
        request = self.get_request(request_id).approve(admin_id=admin_id, note=note)
        self.repository.save(request)
        return request

    def reject(self, request_id: str, *, admin_id: str, note: str | None) -> DonationRequest:
        request = self.get_request(request_id).reject(admin_id=admin_id, note=note)
        self.repository.save(request)
        return request
