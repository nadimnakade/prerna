import base64
import hashlib
import hmac
import re

from cryptography.fernet import Fernet, InvalidToken


class ProtectedIdentifierError(ValueError):
    """Raised when encrypted identifier material is invalid or cannot be decrypted."""


def normalize_identifier(value: str) -> str:
    normalized = re.sub(r"[^A-Za-z0-9]", "", value).upper()
    if len(normalized) < 4:
        raise ProtectedIdentifierError("Identifier must contain at least four letters or digits")
    return normalized


class IdentifierProtector:
    def __init__(self, encryption_key: str, matching_key: str) -> None:
        encryption_material = hashlib.sha256(encryption_key.encode()).digest()
        self._cipher = Fernet(base64.urlsafe_b64encode(encryption_material))
        self._matching_key = matching_key.encode()

    def encrypt(self, value: str) -> str:
        return self._cipher.encrypt(normalize_identifier(value).encode()).decode()

    def decrypt(self, encrypted_value: str) -> str:
        try:
            return self._cipher.decrypt(encrypted_value.encode()).decode()
        except InvalidToken as error:
            raise ProtectedIdentifierError("Identifier ciphertext is invalid") from error

    def matching_digest(self, value: str) -> str:
        return hmac.new(
            self._matching_key,
            normalize_identifier(value).encode(),
            hashlib.sha256,
        ).hexdigest()

    def mask(self, value: str) -> str:
        normalized = normalize_identifier(value)
        return f"{'•' * (len(normalized) - 4)}{normalized[-4:]}"

    def protected_values(self, value: str) -> tuple[str, str, str]:
        normalized = normalize_identifier(value)
        return self.encrypt(normalized), self.matching_digest(normalized), self.mask(normalized)
