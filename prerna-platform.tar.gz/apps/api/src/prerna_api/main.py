from contextlib import asynccontextmanager
from datetime import UTC, date, datetime, timedelta
from decimal import Decimal
from pathlib import Path

from fastapi import Cookie, Depends, FastAPI, HTTPException, Request, Response, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import func, select, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from starlette.middleware.trustedhost import TrustedHostMiddleware

from .application import ApprovalService, RequestNotFound
from .database import Base, engine, get_db
from .domain import DonationRequest, InvalidDecision
from .domain_services import InvariantViolation, consume_payment_link
from .donation_journey import router as donation_router
from .infrastructure import SqlAlchemyDonationRequestRepository, seeded_requests
from .models import (
    AdminLoginAttemptModel,
    AdminSessionModel,
    AdminUserModel,
    DonationRequestModel,
)
from .payment_links import hash_token, issue_or_recover_payment_link
from .payments import (
    confirm_offline,
    deliver_communication,
    ingest_event,
    process_event,
    record_offline,
    verify_razorpay_signature,
)
from .records import (
    BusinessSettingModel,
    CommunicationModel,
    MasterRecordModel,
    OfflineCollectionModel,
    PaymentLinkModel,
    PaymentModel,
    ProgrammeModel,
    ReceiptModel,
)
from .security import (
    hash_login_key,
    hash_password,
    hash_session_token,
    new_session_token,
    session_expiry,
    verify_password,
)
from .settings import get_settings

settings = get_settings()
dummy_password_hash = hash_password("not-a-real-administrator-password")


def seed_development_data(session: Session) -> None:
    if settings.environment not in {"development", "test"}:
        return
    # Uvicorn workers start concurrently. Serialize development seeding so each
    # process can safely re-check the database after the first worker commits.
    if session.bind is not None and session.bind.dialect.name == "postgresql":
        session.execute(text("SELECT pg_advisory_xact_lock(73467201)"))
    if session.scalar(select(func.count()).select_from(AdminUserModel)) == 0:
        session.add(
            AdminUserModel(
                id="admin-001",
                name="Prerna Administrator",
                email="admin@prerna.org",
                password_hash=hash_password("PrernaDemo!2026"),
            )
        )
    if session.scalar(select(func.count()).select_from(DonationRequestModel)) == 0:
        for item in seeded_requests():
            session.add(
                DonationRequestModel(
                    id=item.id,
                    donor_name=item.donor_name,
                    donor_email=item.donor_email,
                    donor_mobile=item.donor_mobile,
                    amount=item.amount,
                    programmes=list(item.programmes),
                    frequency=item.frequency,
                    verification_status=item.verification_status,
                    returning_donor=item.returning_donor,
                    submitted_at=item.submitted_at,
                    status=item.status.value,
                )
            )
    if session.scalar(select(func.count()).select_from(ProgrammeModel)) == 0:
        session.add_all(
            [
                ProgrammeModel(code="EDUCATION", name="Education", wordpress_slug="education"),
                ProgrammeModel(code="HEALTHCARE", name="Healthcare", wordpress_slug="healthcare"),
                ProgrammeModel(code="SPORTS", name="Sports", wordpress_slug="sports"),
                ProgrammeModel(code="ANY", name="Any"),
            ]
        )
    else:
        default_slugs = {"EDUCATION": "education", "HEALTHCARE": "healthcare", "SPORTS": "sports"}
        for programme in session.scalars(select(ProgrammeModel).where(ProgrammeModel.code.in_(default_slugs))):
            if not programme.wordpress_slug:
                programme.wordpress_slug = default_slugs[programme.code]
    if session.scalar(select(func.count()).select_from(BusinessSettingModel)) == 0:
        session.add_all(
            [
                BusinessSettingModel(key="payment_link_validity_hours", value={"hours": 24}),
                BusinessSettingModel(
                    key="receipt_numbering",
                    value={"format": "PRERNA/{financial_year}/{sequence:06d}"},
                ),
            ]
        )
    session.commit()


@asynccontextmanager
async def lifespan(_: FastAPI):
    if settings.environment in {"development", "test"}:
        Base.metadata.create_all(engine)
        with Session(engine) as session:
            seed_development_data(session)
    yield


app = FastAPI(title="Prerna API", version="0.2.0", lifespan=lifespan)
app.include_router(donation_router)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.origins,
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)
app.add_middleware(TrustedHostMiddleware, allowed_hosts=settings.hosts)


@app.middleware("http")
async def enforce_admin_origin(request: Request, call_next):
    is_mutating_admin = request.method in {
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
    } and request.url.path.startswith("/api/v1/admin/")
    if is_mutating_admin:
        origin = request.headers.get("origin")
        origin_required = settings.environment == "production"
        if (origin_required and origin is None) or (origin is not None and origin.rstrip("/") not in settings.origins):
            return Response(status_code=status.HTTP_403_FORBIDDEN, content="Origin not allowed")
    return await call_next(request)


class LoginInput(BaseModel):
    email: str
    password: str


class AdminOutput(BaseModel):
    id: str
    name: str
    email: str


class AdminCreateInput(BaseModel):
    name: str = Field(min_length=2, max_length=160)
    email: str = Field(min_length=5, max_length=320)
    password: str = Field(min_length=12, max_length=200)


class AdminListOutput(AdminOutput):
    is_active: bool


class MasterInput(BaseModel):
    code: str = Field(pattern=r"^[A-Z0-9][A-Z0-9_-]{1,59}$")
    name: str = Field(min_length=2, max_length=180)
    wordpress_slug: str | None = Field(default=None, pattern=r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
    configuration: dict = Field(default_factory=dict)


class MasterUpdateInput(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=180)
    wordpress_slug: str | None = Field(default=None, pattern=r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
    configuration: dict | None = None
    is_active: bool | None = None


class MasterOutput(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    category: str
    code: str
    name: str
    wordpress_slug: str | None
    configuration: dict
    is_active: bool
    updated_by: str | None


class SettingInput(BaseModel):
    value: dict


class SettingOutput(BaseModel):
    key: str
    value: dict
    updated_by: str | None


class DecisionInput(BaseModel):
    internal_note: str | None = Field(default=None, max_length=1000)


class DonationRequestOutput(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    donor_name: str
    donor_email: str
    donor_mobile: str
    amount: Decimal
    programmes: tuple[str, ...]
    frequency: str
    verification_status: str
    returning_donor: bool
    submitted_at: datetime
    status: str
    decided_at: datetime | None
    decided_by: str | None
    internal_note: str | None

    @classmethod
    def from_domain(cls, request: DonationRequest) -> "DonationRequestOutput":
        return cls.model_validate(request)


class PaymentLinkOutput(BaseModel):
    id: str
    provider: str
    provider_reference: str
    url: str
    expires_at: datetime
    created: bool


class PaymentLinkConsumeInput(BaseModel):
    token: str = Field(min_length=32, max_length=200)


class PaymentLinkConsumeOutput(BaseModel):
    valid: bool
    provider: str
    provider_reference: str


class OfflineCollectionInput(BaseModel):
    mode: str = Field(min_length=2, max_length=30)
    reference: str = Field(min_length=1, max_length=160)
    received_at: datetime
    amount: Decimal = Field(gt=0)


class FinancialRecordOutput(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    donation_request_id: str
    amount: Decimal
    status: str
    provider: str
    provider_payment_id: str


class ReceiptOutput(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    payment_id: str
    receipt_number: str
    financial_year: str
    issued_at: datetime
    document_key: str


class OfflineOutput(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    donation_request_id: str
    mode: str
    reference: str
    amount: Decimal
    received_on: date
    confirmed_at: datetime | None


class CommunicationOutput(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    donation_request_id: str | None
    channel: str
    template_key: str
    provider: str
    status: str
    attempt_count: int
    last_error: str | None
    sent_at: datetime | None


class RequestContextOutput(BaseModel):
    request: DonationRequestOutput
    waiting_minutes: int
    donor_request_count: int
    previous_statuses: list[str]
    active_payment_link_expires_at: datetime | None


class DashboardOutput(BaseModel):
    total_requests: int
    pending_approvals: int
    approved_requests: int
    rejected_requests: int
    total_requested_amount: Decimal


def current_admin(
    prerna_session: str | None = Cookie(default=None),
    db: Session = Depends(get_db),
) -> AdminUserModel:
    if prerna_session is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required")
    session = db.get(AdminSessionModel, hash_session_token(prerna_session))
    now = datetime.now(UTC)
    if (
        session is None
        or session.revoked_at is not None
        or session.expires_at.replace(tzinfo=session.expires_at.tzinfo or UTC) <= now
        or not session.admin_user.is_active
    ):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required")
    return session.admin_user


def approval_service(db: Session) -> ApprovalService:
    return ApprovalService(SqlAlchemyDonationRequestRepository(db))


@app.get("/health/live")
def liveness() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/health/ready")
def readiness(db: Session = Depends(get_db)) -> dict[str, str]:
    db.execute(select(1))
    return {"status": "ready"}


@app.post("/api/v1/admin/auth/login", response_model=AdminOutput)
def login(
    payload: LoginInput,
    response: Response,
    request: Request,
    db: Session = Depends(get_db),
) -> AdminOutput:
    now = datetime.now(UTC)
    client_ip = request.client.host if request.client else "unknown"
    login_key = hash_login_key(payload.email, client_ip)
    attempt = db.scalar(
        select(AdminLoginAttemptModel).where(AdminLoginAttemptModel.key_hash == login_key).with_for_update()
    )
    if attempt and attempt.blocked_until:
        blocked_until = attempt.blocked_until.replace(tzinfo=attempt.blocked_until.tzinfo or UTC)
        if blocked_until > now:
            raise HTTPException(status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail="Try again later")
    admin = db.scalar(select(AdminUserModel).where(AdminUserModel.email == payload.email.casefold()))
    password_is_valid = verify_password(
        payload.password,
        admin.password_hash if admin else dummy_password_hash,
    )
    if admin is None or not admin.is_active or not password_is_valid:
        if attempt is None:
            attempt = AdminLoginAttemptModel(key_hash=login_key, failed_count=0, window_started_at=now)
            db.add(attempt)
        window_started = attempt.window_started_at.replace(tzinfo=attempt.window_started_at.tzinfo or UTC)
        if window_started < now - timedelta(minutes=15):
            attempt.failed_count = 0
            attempt.window_started_at = now
        attempt.failed_count += 1
        if attempt.failed_count >= 5:
            attempt.blocked_until = now + timedelta(minutes=15)
        db.commit()
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    if attempt:
        db.delete(attempt)
    raw_token, token_hash = new_session_token()
    db.add(
        AdminSessionModel(
            token_hash=token_hash,
            admin_user_id=admin.id,
            expires_at=session_expiry(settings.session_hours),
        )
    )
    db.commit()
    response.set_cookie(
        "prerna_session",
        raw_token,
        httponly=True,
        secure=settings.secure_cookies,
        samesite="lax",
        max_age=settings.session_hours * 60 * 60,
        path="/",
    )
    return AdminOutput(id=admin.id, name=admin.name, email=admin.email)


@app.post("/api/v1/admin/auth/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout(
    response: Response,
    prerna_session: str | None = Cookie(default=None),
    db: Session = Depends(get_db),
) -> None:
    if prerna_session:
        session = db.get(AdminSessionModel, hash_session_token(prerna_session))
        if session:
            session.revoked_at = datetime.now(UTC)
            db.commit()
    response.delete_cookie("prerna_session", path="/")


@app.get("/api/v1/admin/auth/me", response_model=AdminOutput)
def me(admin: AdminUserModel = Depends(current_admin)) -> AdminOutput:
    return AdminOutput(id=admin.id, name=admin.name, email=admin.email)


MASTER_CATEGORIES = {
    "programmes",
    "donation-modes",
    "communication-templates",
    "receipt-series",
    "financial-years",
    "lookups",
}


def validate_master_category(category: str) -> None:
    if category not in MASTER_CATEGORIES:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Unknown master category")


def programme_output(row: ProgrammeModel) -> MasterOutput:
    return MasterOutput(
        id=row.id,
        category="programmes",
        code=row.code,
        name=row.name,
        wordpress_slug=row.wordpress_slug,
        configuration={},
        is_active=row.is_active,
        updated_by=row.updated_by,
    )


@app.get("/api/v1/programmes", response_model=list[MasterOutput])
def list_public_programmes(db: Session = Depends(get_db)) -> list[MasterOutput]:
    """Published programme mappings used by WordPress and the donation journey."""
    return [
        programme_output(row)
        for row in db.scalars(
            select(ProgrammeModel).where(ProgrammeModel.is_active.is_(True)).order_by(ProgrammeModel.name)
        )
    ]


@app.get("/api/v1/admin/masters/{category}", response_model=list[MasterOutput])
def list_masters(
    category: str,
    _: AdminUserModel = Depends(current_admin),
    db: Session = Depends(get_db),
) -> list[MasterOutput]:
    validate_master_category(category)
    if category == "programmes":
        return [programme_output(row) for row in db.scalars(select(ProgrammeModel).order_by(ProgrammeModel.name))]
    return [
        MasterOutput(
            id=row.id,
            category=row.category,
            code=row.code,
            name=row.name,
            wordpress_slug=None,
            configuration=row.configuration,
            is_active=row.is_active,
            updated_by=row.updated_by,
        )
        for row in db.scalars(
            select(MasterRecordModel).where(MasterRecordModel.category == category).order_by(MasterRecordModel.name)
        )
    ]


@app.post("/api/v1/admin/masters/{category}", response_model=MasterOutput, status_code=status.HTTP_201_CREATED)
def create_master(
    category: str,
    payload: MasterInput,
    admin: AdminUserModel = Depends(current_admin),
    db: Session = Depends(get_db),
) -> MasterOutput:
    validate_master_category(category)
    if category == "programmes":
        row = ProgrammeModel(
            code=payload.code,
            name=payload.name.strip(),
            wordpress_slug=payload.wordpress_slug,
            updated_by=admin.id,
        )
    else:
        row = MasterRecordModel(
            category=category,
            code=payload.code,
            name=payload.name.strip(),
            configuration=payload.configuration,
            updated_by=admin.id,
        )
    try:
        db.add(row)
        db.commit()
        db.refresh(row)
    except IntegrityError as error:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT, detail="Master code or slug already exists"
        ) from error
    if isinstance(row, ProgrammeModel):
        return programme_output(row)
    return MasterOutput(
        id=row.id,
        category=row.category,
        code=row.code,
        name=row.name,
        wordpress_slug=None,
        configuration=row.configuration,
        is_active=row.is_active,
        updated_by=row.updated_by,
    )


@app.patch("/api/v1/admin/masters/{category}/{record_id}", response_model=MasterOutput)
def update_master(
    category: str,
    record_id: str,
    payload: MasterUpdateInput,
    admin: AdminUserModel = Depends(current_admin),
    db: Session = Depends(get_db),
) -> MasterOutput:
    validate_master_category(category)
    row = db.get(ProgrammeModel if category == "programmes" else MasterRecordModel, record_id)
    if row is None or (isinstance(row, MasterRecordModel) and row.category != category):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Master record not found")
    values = payload.model_dump(exclude_unset=True)
    for field in ("name", "is_active"):
        if field in values:
            setattr(row, field, values[field])
    if isinstance(row, ProgrammeModel) and "wordpress_slug" in values:
        row.wordpress_slug = values["wordpress_slug"]
    if isinstance(row, MasterRecordModel) and "configuration" in values:
        row.configuration = values["configuration"]
    row.updated_by = admin.id
    try:
        db.commit()
        db.refresh(row)
    except IntegrityError as error:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Master value already exists") from error
    if isinstance(row, ProgrammeModel):
        return programme_output(row)
    return MasterOutput(
        id=row.id,
        category=row.category,
        code=row.code,
        name=row.name,
        wordpress_slug=None,
        configuration=row.configuration,
        is_active=row.is_active,
        updated_by=row.updated_by,
    )


@app.get("/api/v1/admin/settings", response_model=list[SettingOutput])
def list_settings(_: AdminUserModel = Depends(current_admin), db: Session = Depends(get_db)) -> list[SettingOutput]:
    return [
        SettingOutput(key=row.key, value=row.value, updated_by=row.updated_by)
        for row in db.scalars(select(BusinessSettingModel).order_by(BusinessSettingModel.key))
    ]


@app.put("/api/v1/admin/settings/{key}", response_model=SettingOutput)
def update_setting(
    key: str,
    payload: SettingInput,
    admin: AdminUserModel = Depends(current_admin),
    db: Session = Depends(get_db),
) -> SettingOutput:
    row = db.get(BusinessSettingModel, key)
    if row is None:
        row = BusinessSettingModel(key=key, value=payload.value, updated_by=admin.id)
        db.add(row)
    else:
        row.value = payload.value
        row.updated_by = admin.id
    db.commit()
    return SettingOutput(key=row.key, value=row.value, updated_by=row.updated_by)


@app.get("/api/v1/admin/users", response_model=list[AdminListOutput])
def list_admin_users(
    _: AdminUserModel = Depends(current_admin), db: Session = Depends(get_db)
) -> list[AdminListOutput]:
    return [
        AdminListOutput(id=row.id, name=row.name, email=row.email, is_active=row.is_active)
        for row in db.scalars(select(AdminUserModel).order_by(AdminUserModel.name))
    ]


@app.post("/api/v1/admin/users", response_model=AdminListOutput, status_code=status.HTTP_201_CREATED)
def create_admin_user(
    payload: AdminCreateInput,
    _: AdminUserModel = Depends(current_admin),
    db: Session = Depends(get_db),
) -> AdminListOutput:
    row = AdminUserModel(
        name=payload.name.strip(),
        email=payload.email.casefold().strip(),
        password_hash=hash_password(payload.password),
    )
    try:
        db.add(row)
        db.commit()
        db.refresh(row)
    except IntegrityError as error:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Admin email already exists") from error
    return AdminListOutput(id=row.id, name=row.name, email=row.email, is_active=row.is_active)


@app.post("/api/v1/admin/users/{user_id}/deactivate", response_model=AdminListOutput)
def deactivate_admin_user(
    user_id: str,
    admin: AdminUserModel = Depends(current_admin),
    db: Session = Depends(get_db),
) -> AdminListOutput:
    if user_id == admin.id:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="You cannot deactivate your own account")
    row = db.get(AdminUserModel, user_id)
    if row is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Admin user not found")
    row.is_active = False
    for session in db.scalars(select(AdminSessionModel).where(AdminSessionModel.admin_user_id == user_id)):
        session.revoked_at = datetime.now(UTC)
    db.commit()
    return AdminListOutput(id=row.id, name=row.name, email=row.email, is_active=row.is_active)


@app.get("/api/v1/admin/dashboard", response_model=DashboardOutput)
def dashboard(
    _: AdminUserModel = Depends(current_admin),
    db: Session = Depends(get_db),
) -> DashboardOutput:
    requests = approval_service(db).list_requests()
    return DashboardOutput(
        total_requests=len(requests),
        pending_approvals=sum(item.status == "PENDING_APPROVAL" for item in requests),
        approved_requests=sum(item.status == "APPROVED" for item in requests),
        rejected_requests=sum(item.status == "REJECTED" for item in requests),
        total_requested_amount=sum((item.amount for item in requests), Decimal("0")),
    )


@app.get("/api/v1/admin/donation-requests", response_model=list[DonationRequestOutput])
def list_donation_requests(
    _: AdminUserModel = Depends(current_admin),
    db: Session = Depends(get_db),
) -> list[DonationRequestOutput]:
    return [DonationRequestOutput.from_domain(item) for item in approval_service(db).list_requests()]


@app.get("/api/v1/admin/donation-requests/{request_id}", response_model=DonationRequestOutput)
def get_donation_request(
    request_id: str,
    _: AdminUserModel = Depends(current_admin),
    db: Session = Depends(get_db),
) -> DonationRequestOutput:
    try:
        return DonationRequestOutput.from_domain(approval_service(db).get_request(request_id))
    except RequestNotFound as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Request not found") from error


@app.get("/api/v1/admin/donation-requests/{request_id}/context", response_model=RequestContextOutput)
def get_donation_request_context(
    request_id: str,
    _: AdminUserModel = Depends(current_admin),
    db: Session = Depends(get_db),
) -> RequestContextOutput:
    row = db.get(DonationRequestModel, request_id)
    if row is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Request not found")
    related = (
        list(
            db.scalars(
                select(DonationRequestModel)
                .where(DonationRequestModel.donor_id == row.donor_id)
                .order_by(DonationRequestModel.submitted_at.desc())
            )
        )
        if row.donor_id
        else [row]
    )
    now = datetime.now(UTC)
    submitted = row.submitted_at.replace(tzinfo=row.submitted_at.tzinfo or UTC)
    active_link = db.scalar(
        select(PaymentLinkModel)
        .where(
            PaymentLinkModel.donation_request_id == request_id,
            PaymentLinkModel.used_at.is_(None),
            PaymentLinkModel.expires_at > now,
        )
        .order_by(PaymentLinkModel.created_at.desc())
    )
    return RequestContextOutput(
        request=DonationRequestOutput.model_validate(row),
        waiting_minutes=max(0, int((now - submitted).total_seconds() // 60)),
        donor_request_count=len(related),
        previous_statuses=[item.status for item in related if item.id != row.id][:5],
        active_payment_link_expires_at=active_link.expires_at if active_link else None,
    )


def decide(
    request_id: str,
    action: str,
    payload: DecisionInput,
    admin: AdminUserModel,
    db: Session,
) -> DonationRequestOutput:
    try:
        service = approval_service(db)
        method = service.approve if action == "approve" else service.reject
        return DonationRequestOutput.from_domain(method(request_id, admin_id=admin.id, note=payload.internal_note))
    except RequestNotFound as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Request not found") from error
    except (InvalidDecision, IntegrityError) as error:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Only a pending donation request can be decided",
        ) from error


@app.post(
    "/api/v1/admin/donation-requests/{request_id}/approve",
    response_model=DonationRequestOutput,
)
def approve_donation_request(
    request_id: str,
    payload: DecisionInput,
    admin: AdminUserModel = Depends(current_admin),
    db: Session = Depends(get_db),
) -> DonationRequestOutput:
    return decide(request_id, "approve", payload, admin, db)


@app.post(
    "/api/v1/admin/donation-requests/{request_id}/reject",
    response_model=DonationRequestOutput,
)
def reject_donation_request(
    request_id: str,
    payload: DecisionInput,
    admin: AdminUserModel = Depends(current_admin),
    db: Session = Depends(get_db),
) -> DonationRequestOutput:
    return decide(request_id, "reject", payload, admin, db)


@app.post(
    "/api/v1/admin/donation-requests/{request_id}/payment-link",
    response_model=PaymentLinkOutput,
    status_code=status.HTTP_201_CREATED,
)
def create_payment_link(
    request_id: str,
    admin: AdminUserModel = Depends(current_admin),
    db: Session = Depends(get_db),
) -> PaymentLinkOutput:
    try:
        row, url, created = issue_or_recover_payment_link(db, request_id, admin.id, settings)
    except LookupError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Request not found") from error
    except InvariantViolation as error:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(error)) from error
    return PaymentLinkOutput(
        id=row.id,
        provider=row.provider,
        provider_reference=row.provider_link_id or "",
        url=url,
        expires_at=row.expires_at,
        created=created,
    )


@app.post("/api/v1/payment-links/consume", response_model=PaymentLinkConsumeOutput)
def consume_link(payload: PaymentLinkConsumeInput, db: Session = Depends(get_db)) -> PaymentLinkConsumeOutput:
    try:
        row = consume_payment_link(db, hash_token(payload.token))
    except InvariantViolation as error:
        raise HTTPException(status_code=status.HTTP_410_GONE, detail=str(error)) from error
    return PaymentLinkConsumeOutput(
        valid=True,
        provider=row.provider,
        provider_reference=row.provider_link_id or "",
    )


@app.post("/api/v1/webhooks/payment/razorpay", status_code=status.HTTP_202_ACCEPTED)
async def razorpay_webhook(request: Request, db: Session = Depends(get_db)) -> dict[str, bool]:
    body = await request.body()
    secret = settings.razorpay_webhook_secret
    if not secret or not verify_razorpay_signature(body, request.headers.get("x-razorpay-signature"), secret):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid webhook signature")
    try:
        _, created = ingest_event(db, "razorpay", body)
    except (ValueError, InvariantViolation) as error:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(error)) from error
    return {"accepted": created}


@app.post("/api/v1/admin/provider-events/{event_id}/process")
def process_provider_event(
    event_id: str, _: AdminUserModel = Depends(current_admin), db: Session = Depends(get_db)
) -> dict[str, str | None]:
    try:
        event = process_event(db, event_id, settings)
    except LookupError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Provider event not found") from error
    return {"id": event.id, "error": event.processing_error}


@app.get("/api/v1/admin/payments", response_model=list[FinancialRecordOutput])
def list_payments(_: AdminUserModel = Depends(current_admin), db: Session = Depends(get_db)) -> list[PaymentModel]:
    return list(db.scalars(select(PaymentModel).order_by(PaymentModel.created_at.desc())))


@app.get("/api/v1/admin/receipts", response_model=list[ReceiptOutput])
def list_receipts(_: AdminUserModel = Depends(current_admin), db: Session = Depends(get_db)) -> list[ReceiptModel]:
    return list(db.scalars(select(ReceiptModel).order_by(ReceiptModel.issued_at.desc())))


@app.get("/api/v1/admin/receipts/{receipt_id}/download")
def download_receipt(
    receipt_id: str,
    _: AdminUserModel = Depends(current_admin),
    db: Session = Depends(get_db),
) -> FileResponse:
    receipt = db.get(ReceiptModel, receipt_id)
    if receipt is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Receipt not found")
    path = Path(receipt.document_key).resolve()
    storage = Path(settings.receipt_storage_path).resolve()
    if storage not in path.parents or not path.is_file():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Receipt document is unavailable")
    return FileResponse(path, media_type="application/pdf", filename=f"{receipt.receipt_number.replace('/', '-')}.pdf")


@app.get("/api/v1/admin/offline-donations", response_model=list[OfflineOutput])
def list_offline_donations(
    _: AdminUserModel = Depends(current_admin), db: Session = Depends(get_db)
) -> list[OfflineCollectionModel]:
    return list(db.scalars(select(OfflineCollectionModel).order_by(OfflineCollectionModel.received_on.desc())))


@app.get("/api/v1/admin/communications", response_model=list[CommunicationOutput])
def list_communications(
    _: AdminUserModel = Depends(current_admin), db: Session = Depends(get_db)
) -> list[CommunicationModel]:
    return list(db.scalars(select(CommunicationModel).order_by(CommunicationModel.id.desc())))


@app.post("/api/v1/admin/communications/{communication_id}/retry", response_model=CommunicationOutput)
def retry_communication(
    communication_id: str,
    _: AdminUserModel = Depends(current_admin),
    db: Session = Depends(get_db),
) -> CommunicationModel:
    try:
        return deliver_communication(db, communication_id)
    except LookupError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Communication not found") from error


@app.post("/api/v1/admin/offline-donations/{request_id}/record-collection", status_code=status.HTTP_201_CREATED)
def record_offline_collection(
    request_id: str,
    payload: OfflineCollectionInput,
    admin: AdminUserModel = Depends(current_admin),
    db: Session = Depends(get_db),
) -> dict[str, str]:
    try:
        row = record_offline(
            db, request_id, admin.id, payload.mode, payload.reference, payload.received_at, payload.amount
        )
    except LookupError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Request not found") from error
    except (InvariantViolation, IntegrityError) as error:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(error)) from error
    return {"id": row.id, "status": "OFFLINE_RECORDED"}


@app.post("/api/v1/admin/offline-donations/{request_id}/confirm-finance", response_model=ReceiptOutput)
def confirm_offline_collection(
    request_id: str, admin: AdminUserModel = Depends(current_admin), db: Session = Depends(get_db)
) -> ReceiptModel:
    try:
        return confirm_offline(db, request_id, admin.id, settings)
    except InvariantViolation as error:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(error)) from error
