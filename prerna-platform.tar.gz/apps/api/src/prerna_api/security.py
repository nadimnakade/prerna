from datetime import UTC, datetime, timedelta
from hashlib import sha256
from secrets import token_urlsafe

from pwdlib import PasswordHash

password_hash = PasswordHash.recommended()


def hash_password(password: str) -> str:
    return password_hash.hash(password)


def verify_password(password: str, encoded: str) -> bool:
    return password_hash.verify(password, encoded)


def new_session_token() -> tuple[str, str]:
    raw = token_urlsafe(32)
    return raw, hash_session_token(raw)


def hash_session_token(raw: str) -> str:
    return sha256(raw.encode("utf-8")).hexdigest()


def hash_login_key(email: str, client_ip: str) -> str:
    return sha256(f"{email.casefold()}|{client_ip}".encode()).hexdigest()


def session_expiry(hours: int) -> datetime:
    return datetime.now(UTC) + timedelta(hours=hours)
