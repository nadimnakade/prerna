from functools import lru_cache
from typing import Literal

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_prefix="PRERNA_",
        extra="ignore",
    )

    environment: Literal["development", "test", "production"] = "development"
    database_url: str = "sqlite+pysqlite:///./.data/prerna.db"
    allowed_origins: str = "http://localhost:3000"
    allowed_hosts: str = "localhost,127.0.0.1,testserver"
    session_hours: int = Field(default=8, ge=1, le=168)
    redis_url: str = "redis://localhost:6379/0"
    object_storage_endpoint: str = "http://localhost:9000"
    identifier_encryption_key: str = "local-development-encryption-key"
    identifier_matching_key: str = "local-development-matching-key"
    verification_provider: Literal["local"] = "local"
    verification_otp_minutes: int = Field(default=10, ge=2, le=30)
    payment_gateway: Literal["local", "razorpay"] = "local"
    razorpay_key_id: str | None = None
    razorpay_key_secret: str | None = None
    razorpay_webhook_secret: str | None = None
    local_payment_base_url: str = "http://donate.localhost:8088/payment"
    receipt_storage_path: str = ".data/receipts"
    bootstrap_admin_email: str | None = None
    bootstrap_admin_password: str | None = None

    @property
    def origins(self) -> list[str]:
        return [origin.strip().rstrip("/") for origin in self.allowed_origins.split(",") if origin.strip()]

    @property
    def secure_cookies(self) -> bool:
        return self.environment == "production"

    @property
    def hosts(self) -> list[str]:
        return [host.strip() for host in self.allowed_hosts.split(",") if host.strip()]

    @model_validator(mode="after")
    def validate_production(self) -> "Settings":
        if self.environment == "production":
            if not self.database_url.startswith("postgresql+psycopg://"):
                raise ValueError("Production requires a PostgreSQL psycopg database URL")
            if any(origin.startswith("http://") for origin in self.origins):
                raise ValueError("Production origins must use HTTPS")
            if self.bootstrap_admin_password:
                raise ValueError("Bootstrap credentials must not remain configured in production")
            if self.identifier_encryption_key.startswith("local-development"):
                raise ValueError("Production requires a dedicated identifier encryption key")
            if self.identifier_matching_key.startswith("local-development"):
                raise ValueError("Production requires a dedicated identifier matching key")
            if self.payment_gateway == "razorpay" and (not self.razorpay_key_id or not self.razorpay_key_secret):
                raise ValueError("Razorpay credentials are required when the Razorpay gateway is selected")
            if self.payment_gateway == "razorpay" and not self.razorpay_webhook_secret:
                raise ValueError("A Razorpay webhook secret is required when the Razorpay gateway is selected")
        return self


@lru_cache
def get_settings() -> Settings:
    return Settings()
