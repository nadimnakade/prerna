from celery import Celery

from .settings import get_settings

settings = get_settings()

celery_app = Celery("prerna", broker=settings.redis_url, backend=settings.redis_url)
celery_app.conf.update(
    broker_connection_retry_on_startup=True,
    task_acks_late=True,
    task_reject_on_worker_lost=True,
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="Asia/Kolkata",
    enable_utc=True,
)


@celery_app.task(name="prerna.healthcheck")
def healthcheck() -> str:
    return "ok"
