from dataclasses import dataclass, replace
from datetime import UTC, datetime
from decimal import Decimal
from enum import StrEnum


class DonationRequestStatus(StrEnum):
    PENDING_APPROVAL = "PENDING_APPROVAL"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    PAYMENT_LINK_SENT = "PAYMENT_LINK_SENT"
    OFFLINE_RECORDED = "OFFLINE_RECORDED"
    MANDATE_PENDING = "MANDATE_PENDING"
    MANDATE_ACTIVE = "MANDATE_ACTIVE"
    PAID = "PAID"
    RECEIPTED = "RECEIPTED"
    FAILED_OR_LAPSED = "FAILED_OR_LAPSED"
    MANDATE_CANCELLED = "MANDATE_CANCELLED"


class InvalidDecision(RuntimeError):
    """Raised when an admin decision would violate the approval workflow."""


@dataclass(frozen=True, slots=True)
class DonationRequest:
    id: str
    donor_name: str
    donor_email: str
    donor_mobile: str
    amount: Decimal
    programmes: tuple[str, ...]
    frequency: str
    verification_status: str
    returning_donor: bool
    submitted_at: datetime
    status: DonationRequestStatus = DonationRequestStatus.PENDING_APPROVAL
    decided_at: datetime | None = None
    decided_by: str | None = None
    internal_note: str | None = None

    def __post_init__(self) -> None:
        if isinstance(self.status, str):
            object.__setattr__(self, "status", DonationRequestStatus(self.status))

    def approve(self, *, admin_id: str, note: str | None = None) -> "DonationRequest":
        return self._decide(DonationRequestStatus.APPROVED, admin_id, note)

    def reject(self, *, admin_id: str, note: str | None = None) -> "DonationRequest":
        return self._decide(DonationRequestStatus.REJECTED, admin_id, note)

    def _decide(
        self,
        decision: DonationRequestStatus,
        admin_id: str,
        note: str | None,
    ) -> "DonationRequest":
        if self.status is not DonationRequestStatus.PENDING_APPROVAL:
            raise InvalidDecision("Only a pending donation request can be decided")
        return replace(
            self,
            status=decision,
            decided_at=datetime.now(UTC),
            decided_by=admin_id,
            internal_note=note.strip() if note and note.strip() else None,
        )
