from datetime import datetime
from decimal import Decimal
from uuid import uuid4

from sqlalchemy import (
    JSON,
    Boolean,
    CheckConstraint,
    Date,
    DateTime,
    ForeignKey,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from .database import Base
from .models import utc_now


def new_id() -> str:
    return str(uuid4())


class DonorModel(Base):
    __tablename__ = "donors"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    donor_type: Mapped[str] = mapped_column(String(24), default="INDIVIDUAL")
    display_name: Mapped[str] = mapped_column(String(200))
    email: Mapped[str] = mapped_column(String(320), index=True)
    mobile: Mapped[str] = mapped_column(String(40), index=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now, onupdate=utc_now)


class ProtectedIdentifierModel(Base):
    __tablename__ = "protected_identifiers"
    __table_args__ = (UniqueConstraint("identifier_type", "matching_digest", name="uq_identifier_match"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    donor_id: Mapped[str] = mapped_column(ForeignKey("donors.id", ondelete="CASCADE"), index=True)
    identifier_type: Mapped[str] = mapped_column(String(24))
    encrypted_value: Mapped[str] = mapped_column(Text)
    matching_digest: Mapped[str] = mapped_column(String(64))
    masked_value: Mapped[str] = mapped_column(String(64))
    verification_status: Mapped[str] = mapped_column(String(24), default="PENDING")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)


class DonorAddressModel(Base):
    __tablename__ = "donor_addresses"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    donor_id: Mapped[str] = mapped_column(ForeignKey("donors.id", ondelete="CASCADE"), index=True)
    address_type: Mapped[str] = mapped_column(String(24), default="PRIMARY")
    line1: Mapped[str] = mapped_column(String(240))
    line2: Mapped[str | None] = mapped_column(String(240), nullable=True)
    city: Mapped[str] = mapped_column(String(120))
    state: Mapped[str] = mapped_column(String(120))
    postal_code: Mapped[str] = mapped_column(String(20))
    country_code: Mapped[str] = mapped_column(String(2), default="IN")


class DonorPreferenceModel(Base):
    __tablename__ = "donor_preferences"
    __table_args__ = (UniqueConstraint("donor_id", name="uq_donor_preferences_donor"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    donor_id: Mapped[str] = mapped_column(ForeignKey("donors.id", ondelete="CASCADE"), index=True)
    email_opt_in: Mapped[bool] = mapped_column(Boolean, default=True)
    sms_opt_in: Mapped[bool] = mapped_column(Boolean, default=True)
    whatsapp_opt_in: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now, onupdate=utc_now)


class ProgrammeModel(Base):
    __tablename__ = "programmes"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    code: Mapped[str] = mapped_column(String(40), unique=True)
    name: Mapped[str] = mapped_column(String(160))
    wordpress_slug: Mapped[str | None] = mapped_column(String(160), unique=True, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")
    updated_by: Mapped[str | None] = mapped_column(ForeignKey("admin_users.id", ondelete="RESTRICT"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now, onupdate=utc_now)


class MasterRecordModel(Base):
    __tablename__ = "master_records"
    __table_args__ = (UniqueConstraint("category", "code", name="uq_master_category_code"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    category: Mapped[str] = mapped_column(String(40), index=True)
    code: Mapped[str] = mapped_column(String(60))
    name: Mapped[str] = mapped_column(String(180))
    configuration: Mapped[dict] = mapped_column(JSON, default=dict)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")
    updated_by: Mapped[str] = mapped_column(ForeignKey("admin_users.id", ondelete="RESTRICT"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now, onupdate=utc_now)


class RequestProgrammeModel(Base):
    __tablename__ = "request_programmes"
    __table_args__ = (UniqueConstraint("donation_request_id", "programme_id", name="uq_request_programme"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    donation_request_id: Mapped[str] = mapped_column(ForeignKey("donation_requests.id", ondelete="CASCADE"))
    programme_id: Mapped[str] = mapped_column(ForeignKey("programmes.id", ondelete="RESTRICT"))


class VerificationAttemptModel(Base):
    __tablename__ = "verification_attempts"
    __table_args__ = (UniqueConstraint("provider", "provider_reference", name="uq_verification_provider_ref"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    donation_request_id: Mapped[str] = mapped_column(ForeignKey("donation_requests.id", ondelete="CASCADE"), index=True)
    verification_type: Mapped[str] = mapped_column(String(24))
    provider: Mapped[str] = mapped_column(String(60))
    provider_reference: Mapped[str] = mapped_column(String(160))
    status: Mapped[str] = mapped_column(String(24))
    response_code: Mapped[str | None] = mapped_column(String(80), nullable=True)
    attempted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)


class VerificationSessionModel(Base):
    __tablename__ = "verification_sessions"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    provider: Mapped[str] = mapped_column(String(60))
    target_digest: Mapped[str] = mapped_column(String(64), index=True)
    code_digest: Mapped[str] = mapped_column(String(64))
    send_count: Mapped[int] = mapped_column(Integer, default=1)
    failed_attempts: Mapped[int] = mapped_column(Integer, default=0)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)


class PaymentLinkModel(Base):
    __tablename__ = "payment_links"
    __table_args__ = (
        UniqueConstraint("token_hash", name="uq_payment_link_token"),
        CheckConstraint("expires_at > created_at", name="ck_payment_link_expiry"),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    donation_request_id: Mapped[str] = mapped_column(
        ForeignKey("donation_requests.id", ondelete="RESTRICT"), index=True
    )
    provider: Mapped[str] = mapped_column(String(60))
    provider_link_id: Mapped[str | None] = mapped_column(String(160), unique=True, nullable=True)
    token_hash: Mapped[str] = mapped_column(String(64))
    encrypted_token: Mapped[str] = mapped_column(Text)
    provider_link_url: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class PaymentModel(Base):
    __tablename__ = "payments"
    __table_args__ = (
        UniqueConstraint("provider", "provider_payment_id", name="uq_payment_provider_id"),
        CheckConstraint("amount > 0", name="ck_payment_positive_amount"),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    donation_request_id: Mapped[str] = mapped_column(
        ForeignKey("donation_requests.id", ondelete="RESTRICT"), index=True
    )
    payment_link_id: Mapped[str | None] = mapped_column(
        ForeignKey("payment_links.id", ondelete="RESTRICT"), nullable=True
    )
    mandate_transaction_id: Mapped[str | None] = mapped_column(
        ForeignKey("mandate_transactions.id", ondelete="RESTRICT"), nullable=True
    )
    provider: Mapped[str] = mapped_column(String(60))
    provider_payment_id: Mapped[str] = mapped_column(String(160))
    amount: Mapped[Decimal] = mapped_column(Numeric(14, 2))
    currency: Mapped[str] = mapped_column(String(3), default="INR")
    status: Mapped[str] = mapped_column(String(24))
    paid_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)


class ProviderEventModel(Base):
    __tablename__ = "provider_events"
    __table_args__ = (UniqueConstraint("provider", "provider_event_id", name="uq_provider_event"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    provider: Mapped[str] = mapped_column(String(60))
    provider_event_id: Mapped[str] = mapped_column(String(160))
    event_type: Mapped[str] = mapped_column(String(80))
    payload: Mapped[dict] = mapped_column(JSON)
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    processed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    processing_error: Mapped[str | None] = mapped_column(Text, nullable=True)


class OfflineCollectionModel(Base):
    __tablename__ = "offline_collections"
    __table_args__ = (CheckConstraint("amount > 0", name="ck_offline_positive_amount"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    donation_request_id: Mapped[str] = mapped_column(
        ForeignKey("donation_requests.id", ondelete="RESTRICT"), unique=True
    )
    mode: Mapped[str] = mapped_column(String(30))
    reference: Mapped[str] = mapped_column(String(160))
    amount: Mapped[Decimal] = mapped_column(Numeric(14, 2))
    received_on: Mapped[datetime] = mapped_column(Date)
    recorded_by: Mapped[str] = mapped_column(ForeignKey("admin_users.id", ondelete="RESTRICT"))
    confirmed_by: Mapped[str | None] = mapped_column(ForeignKey("admin_users.id", ondelete="RESTRICT"), nullable=True)
    confirmed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class MandateModel(Base):
    __tablename__ = "mandates"
    __table_args__ = (UniqueConstraint("provider", "provider_mandate_id", name="uq_provider_mandate"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    donation_request_id: Mapped[str] = mapped_column(
        ForeignKey("donation_requests.id", ondelete="RESTRICT"), unique=True
    )
    donor_id: Mapped[str] = mapped_column(ForeignKey("donors.id", ondelete="RESTRICT"), index=True)
    provider: Mapped[str] = mapped_column(String(60))
    provider_mandate_id: Mapped[str | None] = mapped_column(String(160), nullable=True)
    amount: Mapped[Decimal] = mapped_column(Numeric(14, 2))
    status: Mapped[str] = mapped_column(String(24))
    approved_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    activated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    cancelled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class MandateTransactionModel(Base):
    __tablename__ = "mandate_transactions"
    __table_args__ = (UniqueConstraint("mandate_id", "provider_transaction_id", name="uq_mandate_transaction"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    mandate_id: Mapped[str] = mapped_column(ForeignKey("mandates.id", ondelete="RESTRICT"), index=True)
    provider_transaction_id: Mapped[str] = mapped_column(String(160))
    due_on: Mapped[datetime] = mapped_column(Date)
    amount: Mapped[Decimal] = mapped_column(Numeric(14, 2))
    status: Mapped[str] = mapped_column(String(24))
    processed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class ReceiptSequenceModel(Base):
    __tablename__ = "receipt_sequences"
    financial_year: Mapped[str] = mapped_column(String(9), primary_key=True)
    next_value: Mapped[int] = mapped_column(Integer, default=1)


class ReceiptModel(Base):
    __tablename__ = "receipts"
    __table_args__ = (UniqueConstraint("payment_id", name="uq_receipt_payment"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    payment_id: Mapped[str] = mapped_column(ForeignKey("payments.id", ondelete="RESTRICT"))
    donor_id: Mapped[str] = mapped_column(ForeignKey("donors.id", ondelete="RESTRICT"), index=True)
    receipt_number: Mapped[str] = mapped_column(String(80), unique=True)
    financial_year: Mapped[str] = mapped_column(String(9))
    sequence_value: Mapped[int] = mapped_column(Integer)
    issued_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    document_key: Mapped[str] = mapped_column(String(500))
    __table_args__ = (
        UniqueConstraint("payment_id", name="uq_receipt_payment"),
        UniqueConstraint("financial_year", "sequence_value", name="uq_receipt_sequence_value"),
    )


class CommunicationModel(Base):
    __tablename__ = "communications"
    __table_args__ = (UniqueConstraint("provider", "provider_message_id", name="uq_communication_provider_id"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    donor_id: Mapped[str] = mapped_column(ForeignKey("donors.id", ondelete="RESTRICT"), index=True)
    donation_request_id: Mapped[str | None] = mapped_column(ForeignKey("donation_requests.id"), nullable=True)
    channel: Mapped[str] = mapped_column(String(24))
    template_key: Mapped[str] = mapped_column(String(100))
    provider: Mapped[str] = mapped_column(String(60))
    provider_message_id: Mapped[str | None] = mapped_column(String(160), nullable=True)
    status: Mapped[str] = mapped_column(String(24))
    sent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    attempt_count: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)


class BusinessSettingModel(Base):
    __tablename__ = "business_settings"
    key: Mapped[str] = mapped_column(String(120), primary_key=True)
    value: Mapped[dict] = mapped_column(JSON)
    updated_by: Mapped[str | None] = mapped_column(ForeignKey("admin_users.id", ondelete="RESTRICT"), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now, onupdate=utc_now)


class WorkflowHistoryModel(Base):
    __tablename__ = "workflow_history"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    donation_request_id: Mapped[str] = mapped_column(
        ForeignKey("donation_requests.id", ondelete="RESTRICT"), index=True
    )
    from_state: Mapped[str | None] = mapped_column(String(40), nullable=True)
    action: Mapped[str] = mapped_column(String(40))
    to_state: Mapped[str] = mapped_column(String(40))
    actor_type: Mapped[str] = mapped_column(String(24))
    actor_id: Mapped[str | None] = mapped_column(String(80), nullable=True)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)


class ReconciliationRunModel(Base):
    __tablename__ = "reconciliation_runs"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    provider: Mapped[str] = mapped_column(String(60))
    period_start: Mapped[datetime] = mapped_column(Date)
    period_end: Mapped[datetime] = mapped_column(Date)
    status: Mapped[str] = mapped_column(String(24))
    summary: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)


class ReconciliationItemModel(Base):
    __tablename__ = "reconciliation_items"
    __table_args__ = (UniqueConstraint("run_id", "provider_payment_id", name="uq_reconciliation_item"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    run_id: Mapped[str] = mapped_column(ForeignKey("reconciliation_runs.id", ondelete="CASCADE"), index=True)
    provider_payment_id: Mapped[str] = mapped_column(String(160))
    payment_id: Mapped[str | None] = mapped_column(ForeignKey("payments.id"), nullable=True)
    status: Mapped[str] = mapped_column(String(24))
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)


class ExportModel(Base):
    __tablename__ = "exports"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    export_type: Mapped[str] = mapped_column(String(60))
    requested_by: Mapped[str] = mapped_column(ForeignKey("admin_users.id", ondelete="RESTRICT"))
    parameters: Mapped[dict] = mapped_column(JSON)
    status: Mapped[str] = mapped_column(String(24))
    object_key: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)


class CertificateDispatchModel(Base):
    __tablename__ = "certificate_dispatches"
    __table_args__ = (UniqueConstraint("financial_year", "donor_id", name="uq_certificate_dispatch"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    financial_year: Mapped[str] = mapped_column(String(9))
    donor_id: Mapped[str | None] = mapped_column(ForeignKey("donors.id", ondelete="RESTRICT"), nullable=True)
    certificate_reference: Mapped[str] = mapped_column(String(160))
    object_key: Mapped[str] = mapped_column(String(500))
    status: Mapped[str] = mapped_column(String(24))
    dispatched_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
