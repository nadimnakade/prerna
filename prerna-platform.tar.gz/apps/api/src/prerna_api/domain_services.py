from datetime import UTC, datetime

from sqlalchemy import insert, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .models import DonationRequestModel
from .records import PaymentLinkModel, ProviderEventModel, ReceiptSequenceModel


class InvariantViolation(RuntimeError):
    """Raised when persistence would violate a financial workflow invariant."""


def issue_payment_link(session: Session, link: PaymentLinkModel) -> PaymentLinkModel:
    request = session.scalar(
        select(DonationRequestModel).where(DonationRequestModel.id == link.donation_request_id).with_for_update()
    )
    if request is None or request.status != "APPROVED":
        raise InvariantViolation("A payment link requires an approved donation request")
    request.status = "PAYMENT_LINK_SENT"
    session.add(link)
    session.commit()
    return link


def consume_payment_link(session: Session, token_hash: str, *, now: datetime | None = None) -> PaymentLinkModel:
    consumed_at = now or datetime.now(UTC)
    link_id = session.scalar(
        update(PaymentLinkModel)
        .where(
            PaymentLinkModel.token_hash == token_hash,
            PaymentLinkModel.used_at.is_(None),
            PaymentLinkModel.expires_at > consumed_at,
        )
        .values(used_at=consumed_at)
        .returning(PaymentLinkModel.id)
    )
    if link_id is None:
        session.rollback()
        raise InvariantViolation("Payment link is invalid, expired, or already used")
    session.commit()
    return session.get(PaymentLinkModel, link_id)  # type: ignore[return-value]


def record_provider_event(session: Session, event: ProviderEventModel) -> bool:
    try:
        session.add(event)
        session.commit()
        return True
    except IntegrityError:
        session.rollback()
        return False


def allocate_receipt_number(session: Session, financial_year: str) -> tuple[int, str]:
    sequence = session.scalar(
        select(ReceiptSequenceModel).where(ReceiptSequenceModel.financial_year == financial_year).with_for_update()
    )
    if sequence is None:
        try:
            session.execute(insert(ReceiptSequenceModel).values(financial_year=financial_year, next_value=2))
            value = 1
        except IntegrityError:
            session.rollback()
            return allocate_receipt_number(session, financial_year)
    else:
        value = sequence.next_value
        sequence.next_value += 1
    session.commit()
    return value, f"PRERNA/{financial_year}/{value:06d}"
