from dataclasses import dataclass, replace
from enum import StrEnum


class WorkflowViolation(RuntimeError):
    """Raised when an action would bypass the approved donation workflow."""


class RequestState(StrEnum):
    PENDING_APPROVAL = "PENDING_APPROVAL"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    PAYMENT_LINK_SENT = "PAYMENT_LINK_SENT"
    OFFLINE_RECORDED = "OFFLINE_RECORDED"
    MANDATE_PENDING = "MANDATE_PENDING"
    MANDATE_ACTIVE = "MANDATE_ACTIVE"
    PAID = "PAID"
    RECEIPTED = "RECEIPTED"
    FAILED_OR_LAPSED = "FAILED_OR_LAPSED"
    MANDATE_CANCELLED = "MANDATE_CANCELLED"


class WorkflowAction(StrEnum):
    APPROVE = "APPROVE"
    REJECT = "REJECT"
    ISSUE_PAYMENT_LINK = "ISSUE_PAYMENT_LINK"
    RECORD_OFFLINE = "RECORD_OFFLINE"
    START_MANDATE = "START_MANDATE"
    ACTIVATE_MANDATE = "ACTIVATE_MANDATE"
    CONFIRM_PAYMENT = "CONFIRM_PAYMENT"
    CONFIRM_OFFLINE = "CONFIRM_OFFLINE"
    ISSUE_RECEIPT = "ISSUE_RECEIPT"
    FAIL_OR_LAPSE = "FAIL_OR_LAPSE"
    CANCEL_MANDATE = "CANCEL_MANDATE"


TRANSITIONS: dict[tuple[RequestState, WorkflowAction], RequestState] = {
    (RequestState.PENDING_APPROVAL, WorkflowAction.APPROVE): RequestState.APPROVED,
    (RequestState.PENDING_APPROVAL, WorkflowAction.REJECT): RequestState.REJECTED,
    (RequestState.APPROVED, WorkflowAction.ISSUE_PAYMENT_LINK): RequestState.PAYMENT_LINK_SENT,
    (RequestState.APPROVED, WorkflowAction.RECORD_OFFLINE): RequestState.OFFLINE_RECORDED,
    (RequestState.APPROVED, WorkflowAction.START_MANDATE): RequestState.MANDATE_PENDING,
    (RequestState.PAYMENT_LINK_SENT, WorkflowAction.CONFIRM_PAYMENT): RequestState.PAID,
    (RequestState.PAYMENT_LINK_SENT, WorkflowAction.FAIL_OR_LAPSE): RequestState.FAILED_OR_LAPSED,
    (RequestState.OFFLINE_RECORDED, WorkflowAction.CONFIRM_OFFLINE): RequestState.PAID,
    (RequestState.MANDATE_PENDING, WorkflowAction.ACTIVATE_MANDATE): RequestState.MANDATE_ACTIVE,
    (RequestState.MANDATE_PENDING, WorkflowAction.FAIL_OR_LAPSE): RequestState.FAILED_OR_LAPSED,
    (RequestState.MANDATE_ACTIVE, WorkflowAction.CONFIRM_PAYMENT): RequestState.PAID,
    (RequestState.MANDATE_ACTIVE, WorkflowAction.CANCEL_MANDATE): RequestState.MANDATE_CANCELLED,
    (RequestState.PAID, WorkflowAction.ISSUE_RECEIPT): RequestState.RECEIPTED,
}


@dataclass(frozen=True, slots=True)
class DonationWorkflow:
    state: RequestState = RequestState.PENDING_APPROVAL

    def apply(self, action: WorkflowAction) -> "DonationWorkflow":
        target = TRANSITIONS.get((self.state, action))
        if target is None:
            raise WorkflowViolation(f"{action} is not allowed while request is {self.state}")
        return replace(self, state=target)
