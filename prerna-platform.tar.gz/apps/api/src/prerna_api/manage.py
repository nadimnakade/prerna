import argparse
import getpass

from sqlalchemy import select

from .database import SessionLocal
from .models import AdminUserModel
from .security import hash_password


def create_admin(email: str, name: str) -> None:
    password = getpass.getpass("New administrator password: ")
    confirmation = getpass.getpass("Confirm password: ")
    if password != confirmation:
        raise SystemExit("Passwords do not match")
    if len(password) < 14:
        raise SystemExit("Password must be at least 14 characters")
    normalized_email = email.casefold().strip()
    with SessionLocal() as session:
        if session.scalar(select(AdminUserModel).where(AdminUserModel.email == normalized_email)):
            raise SystemExit("An administrator with that email already exists")
        session.add(
            AdminUserModel(
                name=name.strip(),
                email=normalized_email,
                password_hash=hash_password(password),
            )
        )
        session.commit()
    print(f"Created administrator {normalized_email}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Prerna administration commands")
    subparsers = parser.add_subparsers(dest="command", required=True)
    create = subparsers.add_parser("create-admin")
    create.add_argument("--email", required=True)
    create.add_argument("--name", required=True)
    args = parser.parse_args()
    if args.command == "create-admin":
        create_admin(args.email, args.name)


if __name__ == "__main__":
    main()
