from datetime import UTC, datetime
from decimal import Decimal
from uuid import uuid4

from sqlalchemy import JSON, Boolean, CheckConstraint, DateTime, ForeignKey, Numeric, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base


def utc_now() -> datetime:
    return datetime.now(UTC)


class AdminUserModel(Base):
    __tablename__ = "admin_users"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    name: Mapped[str] = mapped_column(String(160))
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)


class AdminSessionModel(Base):
    __tablename__ = "admin_sessions"

    token_hash: Mapped[str] = mapped_column(String(64), primary_key=True)
    admin_user_id: Mapped[str] = mapped_column(ForeignKey("admin_users.id", ondelete="CASCADE"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    admin_user: Mapped[AdminUserModel] = relationship()


class AdminLoginAttemptModel(Base):
    __tablename__ = "admin_login_attempts"

    key_hash: Mapped[str] = mapped_column(String(64), primary_key=True)
    failed_count: Mapped[int] = mapped_column(default=0)
    window_started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    blocked_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class DonationRequestModel(Base):
    __tablename__ = "donation_requests"
    __table_args__ = (
        CheckConstraint(
            "status IN ('PENDING_APPROVAL','APPROVED','REJECTED','PAYMENT_LINK_SENT',"
            "'OFFLINE_RECORDED','MANDATE_PENDING','MANDATE_ACTIVE','PAID','RECEIPTED',"
            "'FAILED_OR_LAPSED','MANDATE_CANCELLED')",
            name="ck_donation_request_status",
        ),
    )

    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    client_submission_id: Mapped[str | None] = mapped_column(String(64), unique=True, nullable=True)
    donor_id: Mapped[str | None] = mapped_column(
        ForeignKey("donors.id", ondelete="RESTRICT"), nullable=True, index=True
    )
    donor_name: Mapped[str] = mapped_column(String(200))
    donor_email: Mapped[str] = mapped_column(String(320))
    donor_mobile: Mapped[str] = mapped_column(String(40))
    amount: Mapped[Decimal] = mapped_column(Numeric(14, 2))
    programmes: Mapped[list[str]] = mapped_column(JSON)
    frequency: Mapped[str] = mapped_column(String(30))
    source: Mapped[str] = mapped_column(String(24), default="ONLINE", server_default="ONLINE")
    purpose: Mapped[str | None] = mapped_column(String(500), nullable=True)
    verification_status: Mapped[str] = mapped_column(String(40))
    returning_donor: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    submitted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    status: Mapped[str] = mapped_column(String(40), index=True)
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    decided_by: Mapped[str | None] = mapped_column(ForeignKey("admin_users.id"), nullable=True)
    internal_note: Mapped[str | None] = mapped_column(Text, nullable=True)


class ApprovalActionModel(Base):
    __tablename__ = "approval_actions"
    __table_args__ = (UniqueConstraint("donation_request_id", name="uq_approval_actions_request"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    donation_request_id: Mapped[str] = mapped_column(
        ForeignKey("donation_requests.id", ondelete="RESTRICT"), index=True
    )
    decision: Mapped[str] = mapped_column(String(20))
    admin_user_id: Mapped[str] = mapped_column(ForeignKey("admin_users.id", ondelete="RESTRICT"))
    internal_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)


# Import the broader record model after the foundational tables are declared so
# SQLAlchemy registers every table without introducing a circular dependency.
from . import records as records  # noqa: E402,F401
