import pytest
from prerna_api.database import Base, SessionLocal, engine
from prerna_api.main import seed_development_data


@pytest.fixture(autouse=True)
def reset_database(request):
    if request.node.get_closest_marker("no_db"):
        yield
        return
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    with SessionLocal() as session:
        seed_development_data(session)
    yield
    Base.metadata.drop_all(engine)
