from datetime import UTC, datetime
from decimal import Decimal

import pytest
from prerna_api.domain import DonationRequest, DonationRequestStatus, InvalidDecision


def pending_request() -> DonationRequest:
    return DonationRequest(
        id="DR-1",
        donor_name="Test Donor",
        donor_email="donor@example.org",
        donor_mobile="+91 98••• ••001",
        amount=Decimal("2500"),
        programmes=("Education",),
        frequency="One-time",
        verification_status="Verified",
        returning_donor=False,
        submitted_at=datetime(2026, 10, 10, tzinfo=UTC),
    )


def test_pending_request_can_be_approved_with_workflow_metadata() -> None:
    approved = pending_request().approve(admin_id="admin-1", note="Verified documents")

    assert approved.status is DonationRequestStatus.APPROVED
    assert approved.decided_by == "admin-1"
    assert approved.internal_note == "Verified documents"
    assert approved.decided_at is not None


def test_decided_request_cannot_be_decided_again() -> None:
    approved = pending_request().approve(admin_id="admin-1")

    with pytest.raises(InvalidDecision, match="Only a pending donation request"):
        approved.reject(admin_id="admin-2")
