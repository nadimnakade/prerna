from fastapi.testclient import TestClient
from prerna_api.main import app


def authenticated_client() -> TestClient:
    client = TestClient(app)
    response = client.post(
        "/api/v1/admin/auth/login",
        json={"email": "admin@prerna.org", "password": "PrernaDemo!2026"},
    )
    assert response.status_code == 200
    return client


def test_programme_master_crud_persists_wordpress_mapping_and_actor() -> None:
    client = authenticated_client()
    created = client.post(
        "/api/v1/admin/masters/programmes",
        json={"code": "NUTRITION", "name": "Nutrition", "wordpress_slug": "nutrition-programme"},
    )

    assert created.status_code == 201
    assert created.json()["wordpress_slug"] == "nutrition-programme"
    assert created.json()["updated_by"] == "admin-001"
    record_id = created.json()["id"]

    duplicate = client.post(
        "/api/v1/admin/masters/programmes",
        json={"code": "NUTRITION", "name": "Duplicate", "wordpress_slug": "duplicate"},
    )
    assert duplicate.status_code == 409

    deactivated = client.patch(
        f"/api/v1/admin/masters/programmes/{record_id}",
        json={"is_active": False, "name": "Nutrition and Food Security"},
    )
    assert deactivated.status_code == 200
    assert deactivated.json()["is_active"] is False

    public = client.get("/api/v1/programmes")
    assert public.status_code == 200
    assert all(item["is_active"] for item in public.json())
    assert "nutrition-programme" not in {item["wordpress_slug"] for item in public.json()}


def test_generic_master_and_settings_are_audited() -> None:
    client = authenticated_client()
    master = client.post(
        "/api/v1/admin/masters/donation-modes",
        json={"code": "CHEQUE", "name": "Cheque", "configuration": {"reference_required": True}},
    )
    setting = client.put(
        "/api/v1/admin/settings/payment_link_validity_hours",
        json={"value": {"hours": 48}},
    )

    assert master.status_code == 201
    assert master.json()["updated_by"] == "admin-001"
    assert setting.status_code == 200
    assert setting.json() == {
        "key": "payment_link_validity_hours",
        "value": {"hours": 48},
        "updated_by": "admin-001",
    }


def test_deactivated_admin_cannot_continue_or_start_a_session() -> None:
    owner = authenticated_client()
    created = owner.post(
        "/api/v1/admin/users",
        json={"name": "Operations User", "email": "ops@prerna.org", "password": "Operations!2026"},
    )
    assert created.status_code == 201

    operator = TestClient(app)
    assert (
        operator.post(
            "/api/v1/admin/auth/login",
            json={"email": "ops@prerna.org", "password": "Operations!2026"},
        ).status_code
        == 200
    )

    assert owner.post(f"/api/v1/admin/users/{created.json()['id']}/deactivate").status_code == 200
    assert operator.get("/api/v1/admin/auth/me").status_code == 401
    assert (
        operator.post(
            "/api/v1/admin/auth/login",
            json={"email": "ops@prerna.org", "password": "Operations!2026"},
        ).status_code
        == 401
    )
