import os
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime, timedelta

import pytest
from prerna_api.application import ApprovalService
from prerna_api.database import Base
from prerna_api.domain import InvalidDecision
from prerna_api.domain_services import (
    InvariantViolation,
    allocate_receipt_number,
    consume_payment_link,
    record_provider_event,
)
from prerna_api.infrastructure import SqlAlchemyDonationRequestRepository
from prerna_api.models import AdminUserModel, DonationRequestModel
from prerna_api.payment_links import issue_or_recover_payment_link
from prerna_api.records import DonorModel, PaymentLinkModel, ProviderEventModel
from prerna_api.settings import Settings
from sqlalchemy import create_engine, func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import sessionmaker

POSTGRES_TEST_URL = os.getenv("PRERNA_POSTGRES_TEST_URL")
pytestmark = [
    pytest.mark.no_db,
    pytest.mark.skipif(not POSTGRES_TEST_URL, reason="requires a disposable PostgreSQL database"),
]


@pytest.fixture
def postgres_sessions():
    engine = create_engine(POSTGRES_TEST_URL, pool_size=25, max_overflow=0, pool_pre_ping=True)
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    sessions = sessionmaker(bind=engine, expire_on_commit=False)
    with sessions() as session:
        session.add(AdminUserModel(id="admin-concurrency", name="Test", email="test@example.org", password_hash="x"))
        session.add(
            DonationRequestModel(
                id="DR-CONCURRENT",
                donor_name="Concurrency Test",
                donor_email="donor@example.org",
                donor_mobile="+910000000000",
                amount=100,
                programmes=["Any"],
                frequency="One-time",
                verification_status="Verified",
                returning_donor=False,
                submitted_at=datetime.now(UTC),
                status="PAYMENT_LINK_SENT",
            )
        )
        donor = DonorModel(
            id="donor-concurrency", display_name="Concurrent Donor", email="c@example.org", mobile="+919999999999"
        )
        session.add(donor)
        session.add(
            DonationRequestModel(
                id="DR-APPROVAL-CONCURRENT",
                donor_id=donor.id,
                donor_name=donor.display_name,
                donor_email="c***@example.org",
                donor_mobile="+91••••••9999",
                amount=500,
                programmes=["Education"],
                frequency="ONE_TIME",
                verification_status="VERIFIED",
                returning_donor=False,
                submitted_at=datetime.now(UTC),
                status="PENDING_APPROVAL",
            )
        )
        session.add(
            DonationRequestModel(
                id="DR-LINK-CONCURRENT",
                donor_id=donor.id,
                donor_name=donor.display_name,
                donor_email="c***@example.org",
                donor_mobile="+91••••••9999",
                amount=500,
                programmes=["Education"],
                frequency="ONE_TIME",
                verification_status="VERIFIED",
                returning_donor=False,
                submitted_at=datetime.now(UTC),
                status="APPROVED",
            )
        )
        now = datetime.now(UTC)
        session.add(
            PaymentLinkModel(
                donation_request_id="DR-CONCURRENT",
                provider="razorpay",
                token_hash="c" * 64,
                encrypted_token="encrypted",
                provider_link_url="https://example.test/pay",
                created_at=now,
                expires_at=now + timedelta(hours=1),
            )
        )
        session.commit()
    yield sessions
    Base.metadata.drop_all(engine)
    engine.dispose()


def test_single_use_payment_link_has_one_concurrent_winner(postgres_sessions) -> None:
    def consume() -> bool:
        with postgres_sessions() as session:
            try:
                consume_payment_link(session, "c" * 64)
                return True
            except InvariantViolation:
                return False

    with ThreadPoolExecutor(max_workers=8) as executor:
        results = list(executor.map(lambda _: consume(), range(8)))

    assert results.count(True) == 1


def test_duplicate_provider_event_has_one_concurrent_winner(postgres_sessions) -> None:
    def record(index: int) -> bool:
        with postgres_sessions() as session:
            return record_provider_event(
                session,
                ProviderEventModel(
                    provider="razorpay",
                    provider_event_id="evt_concurrent",
                    event_type="payment.captured",
                    payload={"attempt": index},
                ),
            )

    with ThreadPoolExecutor(max_workers=8) as executor:
        results = list(executor.map(record, range(8)))

    assert results.count(True) == 1
    with postgres_sessions() as session:
        assert session.scalar(select(func.count()).select_from(ProviderEventModel)) == 1


def test_receipt_sequence_allocation_is_gap_free_under_concurrency(postgres_sessions) -> None:
    def allocate(_: int) -> int:
        with postgres_sessions() as session:
            return allocate_receipt_number(session, "2026-2027")[0]

    with ThreadPoolExecutor(max_workers=16) as executor:
        values = list(executor.map(allocate, range(40)))

    assert sorted(values) == list(range(1, 41))


def test_parallel_approval_has_one_winner(postgres_sessions) -> None:
    def approve(_: int) -> bool:
        with postgres_sessions() as session:
            service = ApprovalService(SqlAlchemyDonationRequestRepository(session))
            try:
                service.approve("DR-APPROVAL-CONCURRENT", admin_id="admin-concurrency", note=None)
                return True
            except (InvalidDecision, IntegrityError):
                session.rollback()
                return False

    with ThreadPoolExecutor(max_workers=2) as executor:
        results = list(executor.map(approve, range(2)))

    assert results.count(True) == 1


def test_parallel_link_issue_creates_one_link(postgres_sessions) -> None:
    local_settings = Settings(environment="test", local_payment_base_url="http://local.test/payment")

    def issue(_: int) -> bool:
        with postgres_sessions() as session:
            _, _, created = issue_or_recover_payment_link(
                session, "DR-LINK-CONCURRENT", "admin-concurrency", local_settings
            )
            return created

    with ThreadPoolExecutor(max_workers=2) as executor:
        results = list(executor.map(issue, range(2)))

    assert results.count(True) == 1
    with postgres_sessions() as session:
        assert (
            session.scalar(
                select(func.count())
                .select_from(PaymentLinkModel)
                .where(PaymentLinkModel.donation_request_id == "DR-LINK-CONCURRENT")
            )
            == 1
        )
