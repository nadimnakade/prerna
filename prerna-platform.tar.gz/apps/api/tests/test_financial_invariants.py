from datetime import UTC, datetime, timedelta

import pytest
from prerna_api.database import SessionLocal
from prerna_api.domain_services import (
    InvariantViolation,
    allocate_receipt_number,
    consume_payment_link,
    issue_payment_link,
    record_provider_event,
)
from prerna_api.models import DonationRequestModel
from prerna_api.records import PaymentLinkModel, ProviderEventModel


def payment_link(request_id: str, token_hash: str = "a" * 64) -> PaymentLinkModel:
    now = datetime.now(UTC)
    return PaymentLinkModel(
        donation_request_id=request_id,
        provider="razorpay",
        token_hash=token_hash,
        encrypted_token="encrypted",
        provider_link_url="https://example.test/pay",
        created_at=now,
        expires_at=now + timedelta(hours=24),
    )


def test_payment_link_requires_approved_request_and_is_single_use() -> None:
    with SessionLocal() as session:
        pending = session.get(DonationRequestModel, "DR-2026-0042")
        assert pending is not None
        with pytest.raises(InvariantViolation, match="approved"):
            issue_payment_link(session, payment_link(pending.id))

        pending.status = "APPROVED"
        session.commit()
        issued = issue_payment_link(session, payment_link(pending.id))
        assert issued.id

    with SessionLocal() as session:
        assert consume_payment_link(session, "a" * 64).used_at is not None
    with SessionLocal() as session, pytest.raises(InvariantViolation, match="already used"):
        consume_payment_link(session, "a" * 64)


def test_provider_event_delivery_is_idempotent() -> None:
    with SessionLocal() as session:
        first = record_provider_event(
            session,
            ProviderEventModel(
                provider="razorpay",
                provider_event_id="evt_same",
                event_type="payment.captured",
                payload={"id": "evt_same"},
            ),
        )
    with SessionLocal() as session:
        duplicate = record_provider_event(
            session,
            ProviderEventModel(
                provider="razorpay",
                provider_event_id="evt_same",
                event_type="payment.captured",
                payload={"id": "evt_same"},
            ),
        )

    assert first is True
    assert duplicate is False


def test_receipt_sequence_is_unique_and_monotonic() -> None:
    with SessionLocal() as session:
        first = allocate_receipt_number(session, "2026-2027")
    with SessionLocal() as session:
        second = allocate_receipt_number(session, "2026-2027")

    assert first == (1, "PRERNA/2026-2027/000001")
    assert second == (2, "PRERNA/2026-2027/000002")
