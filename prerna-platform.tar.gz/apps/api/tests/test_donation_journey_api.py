from datetime import UTC, datetime, timedelta

from fastapi.testclient import TestClient
from prerna_api.database import SessionLocal
from prerna_api.main import app
from prerna_api.models import DonationRequestModel
from prerna_api.records import (
    DonorModel,
    DonorPreferenceModel,
    PaymentModel,
    ProtectedIdentifierModel,
    VerificationSessionModel,
)
from sqlalchemy import func, select


def start_and_confirm(client: TestClient, email: str = "asha@example.org", mobile: str = "9876543210") -> str:
    started = client.post("/api/v1/donations/verification/start", json={"email": email, "mobile": mobile})
    assert started.status_code == 201
    body = started.json()
    confirmed = client.post(
        "/api/v1/donations/verification/confirm",
        json={"verification_token": body["verification_token"], "code": body["development_code"]},
    )
    assert confirmed.status_code == 200
    return body["verification_token"]


def submission(token: str, *, frequency: str = "ONE_TIME") -> dict:
    return {
        "verification_token": token,
        "name": "Asha Nair",
        "email": "asha@example.org",
        "mobile": "9876543210",
        "address": {
            "line1": "12 Community Road",
            "city": "Mumbai",
            "state": "Maharashtra",
            "postal_code": "400001",
            "country_code": "IN",
        },
        "identifier_type": "PAN",
        "protected_identifier": "ABCDE1234F",
        "programme_slugs": ["education"],
        "frequency": frequency,
        "amount": "1500.00",
        "terms_accepted": True,
        "preferences": {"consent_confirmed": True, "email": True, "sms": False, "whatsapp": False},
    }


def test_new_donor_submission_is_idempotent_and_never_creates_payment() -> None:
    client = TestClient(app)
    token = start_and_confirm(client)
    headers = {"Idempotency-Key": "browser-submission-0001"}

    first = client.post("/api/v1/donations/requests", json=submission(token), headers=headers)
    duplicate = client.post("/api/v1/donations/requests", json=submission(token), headers=headers)

    assert first.status_code == 201
    assert duplicate.status_code == 201
    assert duplicate.json() == first.json()
    assert first.json()["masked_identifier"] == "••••••234F"
    assert first.json()["masked_email"] == "a***@example.org"
    with SessionLocal() as db:
        assert db.scalar(select(func.count()).select_from(DonorModel)) == 1
        assert db.scalar(select(func.count()).select_from(DonationRequestModel)) == 4
        assert db.scalar(select(func.count()).select_from(PaymentModel)) == 0
        assert db.scalar(select(func.count()).select_from(DonorPreferenceModel)) == 1
        protected = db.scalar(select(ProtectedIdentifierModel))
        assert protected is not None
        assert "ABCDE1234F" not in protected.encrypted_value


def test_returning_donor_and_monthly_intent_match_without_exposing_identifier() -> None:
    client = TestClient(app)
    first_token = start_and_confirm(client)
    client.post(
        "/api/v1/donations/requests",
        json=submission(first_token),
        headers={"Idempotency-Key": "browser-submission-0002"},
    )
    second_token = start_and_confirm(client)
    response = client.post(
        "/api/v1/donations/requests",
        json=submission(second_token, frequency="MONTHLY"),
        headers={"Idempotency-Key": "browser-submission-0003"},
    )

    assert response.status_code == 201
    assert response.json()["returning_donor"] is True
    assert "ABCDE1234F" not in response.text
    with SessionLocal() as db:
        row = db.scalar(
            select(DonationRequestModel).where(DonationRequestModel.client_submission_id == "browser-submission-0003")
        )
        assert row is not None and row.frequency == "MONTHLY"


def test_invalid_identity_wrong_otp_and_expired_otp_fail_safely() -> None:
    client = TestClient(app)
    started = client.post(
        "/api/v1/donations/verification/start", json={"email": "asha@example.org", "mobile": "9876543210"}
    ).json()
    wrong = client.post(
        "/api/v1/donations/verification/confirm",
        json={"verification_token": started["verification_token"], "code": "999999"},
    )
    assert wrong.status_code == 422

    with SessionLocal() as db:
        row = db.get(VerificationSessionModel, started["verification_token"])
        assert row is not None
        row.expires_at = datetime.now(UTC) - timedelta(seconds=1)
        db.commit()
    expired = client.post(
        "/api/v1/donations/verification/confirm",
        json={"verification_token": started["verification_token"], "code": "123456"},
    )
    assert expired.status_code == 410

    token = start_and_confirm(client)
    invalid = submission(token)
    invalid["protected_identifier"] = "ABCDE0000"
    rejected = client.post(
        "/api/v1/donations/requests",
        json=invalid,
        headers={"Idempotency-Key": "browser-submission-0004"},
    )
    assert rejected.status_code == 422
    assert rejected.json()["detail"] == "Identity verification failed"
