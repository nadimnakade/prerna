import hashlib
import hmac
import json
from datetime import UTC, datetime
from decimal import Decimal

from prerna_api.database import SessionLocal
from prerna_api.models import DonationRequestModel
from prerna_api.payments import (
    confirm_offline,
    deliver_communication,
    ingest_event,
    process_event,
    record_offline,
    verify_razorpay_signature,
)
from prerna_api.records import (
    CommunicationModel,
    DonorModel,
    DonorPreferenceModel,
    PaymentLinkModel,
    PaymentModel,
    ReceiptModel,
)
from prerna_api.settings import Settings
from sqlalchemy import func, select


def prepared_request(request_id: str) -> str:
    with SessionLocal() as db:
        donor = DonorModel(display_name="Payment Donor", email="pay@example.org", mobile="+919876543210")
        db.add(donor)
        db.flush()
        request = DonationRequestModel(
            id=request_id,
            donor_id=donor.id,
            donor_name=donor.display_name,
            donor_email="p***@example.org",
            donor_mobile="+91••••••3210",
            amount=Decimal("2500"),
            programmes=["Education"],
            frequency="ONE_TIME",
            source="ONLINE",
            verification_status="VERIFIED",
            returning_donor=False,
            submitted_at=datetime.now(UTC),
            status="PAYMENT_LINK_SENT",
        )
        link = PaymentLinkModel(
            donation_request_id=request_id,
            provider="razorpay",
            provider_link_id=f"plink-{request_id}",
            token_hash=hashlib.sha256(request_id.encode()).hexdigest(),
            encrypted_token="encrypted",
            provider_link_url="https://example.test/pay",
            expires_at=datetime.now(UTC).replace(year=datetime.now(UTC).year + 1),
        )
        db.add_all([request, link])
        db.commit()
        return link.provider_link_id or ""


def captured_event(event_id: str, link_ref: str, amount: int = 250000) -> bytes:
    return json.dumps(
        {
            "id": event_id,
            "event": "payment.captured",
            "payload": {
                "payment": {
                    "entity": {
                        "id": f"pay-{event_id}",
                        "amount": amount,
                        "currency": "INR",
                        "payment_link_id": link_ref,
                    }
                }
            },
        }
    ).encode()


def test_signature_and_duplicate_event_are_safe(tmp_path) -> None:
    body = captured_event("evt-1", "unknown")
    signature = hmac.new(b"secret", body, hashlib.sha256).hexdigest()
    assert verify_razorpay_signature(body, signature, "secret")
    assert not verify_razorpay_signature(body, "wrong", "secret")
    with SessionLocal() as db:
        first, created = ingest_event(db, "razorpay", body)
        repeated, repeated_created = ingest_event(db, "razorpay", body)
        assert created is True
        assert repeated_created is False
        assert repeated.id == first.id


def test_capture_creates_one_payment_receipt_and_communication(tmp_path) -> None:
    link_ref = prepared_request("DR-PAY-1")
    settings = Settings(receipt_storage_path=str(tmp_path))
    with SessionLocal() as db:
        event, _ = ingest_event(db, "razorpay", captured_event("evt-capture", link_ref))
        process_event(db, event.id, settings)
        process_event(db, event.id, settings)
        assert db.scalar(select(func.count()).select_from(PaymentModel)) == 1
        assert db.scalar(select(func.count()).select_from(ReceiptModel)) == 1
        assert (
            db.scalar(
                select(func.count())
                .select_from(CommunicationModel)
                .where(CommunicationModel.template_key == "receipt_issued")
            )
            == 1
        )
        receipt = db.scalar(select(ReceiptModel))
        assert (
            receipt
            and (tmp_path / receipt.financial_year / receipt.document_key.split("\\")[-1].split("/")[-1]).exists()
        )


def test_amount_mismatch_is_audited_without_payment(tmp_path) -> None:
    link_ref = prepared_request("DR-PAY-2")
    with SessionLocal() as db:
        event, _ = ingest_event(db, "razorpay", captured_event("evt-mismatch", link_ref, 100))
        processed = process_event(db, event.id, Settings(receipt_storage_path=str(tmp_path)))
        assert processed.processing_error == "Payment amount mismatch"
        assert db.scalar(select(func.count()).select_from(PaymentModel)) == 0


def test_offline_requires_finance_confirmation_before_receipt(tmp_path) -> None:
    prepared_request("DR-OFF-1")
    with SessionLocal() as db:
        request = db.get(DonationRequestModel, "DR-OFF-1")
        request.status = "APPROVED"
        db.commit()
        record_offline(db, request.id, "admin-001", "CHEQUE", "CH-42", datetime.now(UTC), Decimal("2500"))
        assert db.scalar(select(func.count()).select_from(ReceiptModel)) == 0
        receipt = confirm_offline(db, request.id, "admin-001", Settings(receipt_storage_path=str(tmp_path)))
        assert receipt.receipt_number.startswith("PRERNA/")
        assert db.get(DonationRequestModel, request.id).source == "OFFLINE"


def test_communication_delivery_enforces_consent_and_retries_safely() -> None:
    prepared_request("DR-COMMS-1")
    with SessionLocal() as db:
        request = db.get(DonationRequestModel, "DR-COMMS-1")
        db.add(
            DonorPreferenceModel(
                donor_id=request.donor_id,
                email_opt_in=True,
                sms_opt_in=True,
                whatsapp_opt_in=False,
            )
        )
        email = CommunicationModel(
            donor_id=request.donor_id,
            donation_request_id=request.id,
            channel="EMAIL",
            template_key="receipt_issued",
            provider="pending",
            status="PENDING",
        )
        whatsapp = CommunicationModel(
            donor_id=request.donor_id,
            donation_request_id=request.id,
            channel="WHATSAPP",
            template_key="receipt_issued",
            provider="pending",
            status="PENDING",
        )
        db.add_all([email, whatsapp])
        db.commit()
        delivered = deliver_communication(db, email.id)
        same = deliver_communication(db, email.id)
        suppressed = deliver_communication(db, whatsapp.id)
        assert delivered.status == "SENT" and same.attempt_count == 1
        assert suppressed.status == "SUPPRESSED"
        assert suppressed.last_error == "Donor has not consented to this channel"
