import pytest
from prerna_api.protected_identifiers import IdentifierProtector, ProtectedIdentifierError

pytestmark = pytest.mark.no_db


def test_identifier_is_encrypted_matched_and_masked_without_plaintext_storage() -> None:
    protector = IdentifierProtector("test encryption material", "test matching material")

    encrypted, digest, masked = protector.protected_values("abcde1234f")

    assert "ABCDE1234F" not in encrypted
    assert protector.decrypt(encrypted) == "ABCDE1234F"
    assert digest == protector.matching_digest("abcde-1234-f")
    assert masked == "••••••234F"


def test_identifier_ciphertext_cannot_be_opened_with_another_key() -> None:
    encrypted = IdentifierProtector("first key", "matching").encrypt("ABCDE1234F")

    with pytest.raises(ProtectedIdentifierError):
        IdentifierProtector("second key", "matching").decrypt(encrypted)
