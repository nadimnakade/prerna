import pytest
from prerna_api.domain_services import InvariantViolation
from prerna_api.payment_links import gateway
from prerna_api.settings import Settings
from pydantic import ValidationError


def test_production_rejects_non_postgres_database() -> None:
    with pytest.raises(ValidationError, match="PostgreSQL"):
        Settings(
            environment="production",
            database_url="sqlite+pysqlite:///prerna.db",
            allowed_origins="https://admin.prerna.example",
        )


def test_production_rejects_insecure_browser_origin() -> None:
    with pytest.raises(ValidationError, match="HTTPS"):
        Settings(
            environment="production",
            database_url="postgresql+psycopg://prerna:secret@db/prerna",
            allowed_origins="http://admin.prerna.example",
        )


def production_settings(**overrides: object) -> Settings:
    values: dict[str, object] = {
        "environment": "production",
        "database_url": "postgresql+psycopg://prerna:secret@db/prerna",
        "allowed_origins": "https://admin.prerna.example",
        "identifier_encryption_key": "production-encryption-key-from-secret-store",
        "identifier_matching_key": "production-matching-key-from-secret-store",
    }
    values.update(overrides)
    return Settings(**values)


def test_production_razorpay_requires_both_credentials() -> None:
    with pytest.raises(ValidationError, match="Razorpay credentials"):
        production_settings(payment_gateway="razorpay", razorpay_key_id="rzp_live_example")


def test_real_razorpay_adapter_is_disabled_outside_production() -> None:
    settings = Settings(
        environment="test",
        payment_gateway="razorpay",
        razorpay_key_id="rzp_test_example",
        razorpay_key_secret="secret",
    )

    with pytest.raises(InvariantViolation, match="disabled outside production"):
        gateway(settings)


def test_production_razorpay_adapter_accepts_complete_configuration() -> None:
    settings = production_settings(
        payment_gateway="razorpay",
        razorpay_key_id="rzp_live_example",
        razorpay_key_secret="secret",
        razorpay_webhook_secret="webhook-secret",
    )

    assert gateway(settings).name == "razorpay"
