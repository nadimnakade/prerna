from fastapi.testclient import TestClient
from prerna_api.database import SessionLocal
from prerna_api.main import app
from prerna_api.models import AdminSessionModel, ApprovalActionModel
from sqlalchemy import func, select


def authenticated_client() -> TestClient:
    client = TestClient(app)
    response = client.post(
        "/api/v1/admin/auth/login",
        json={"email": "admin@prerna.org", "password": "PrernaDemo!2026"},
    )
    assert response.status_code == 200
    return client


def test_approval_queue_requires_authentication() -> None:
    response = TestClient(app).get("/api/v1/admin/donation-requests")

    assert response.status_code == 401


def test_admin_can_list_and_approve_a_pending_request() -> None:
    client = authenticated_client()
    queue = client.get("/api/v1/admin/donation-requests")
    request_id = next(item["id"] for item in queue.json() if item["status"] == "PENDING_APPROVAL")

    response = client.post(
        f"/api/v1/admin/donation-requests/{request_id}/approve",
        json={"internal_note": "Identity and intent reviewed"},
    )

    assert response.status_code == 200
    assert response.json()["status"] == "APPROVED"
    assert response.json()["internal_note"] == "Identity and intent reviewed"
    with SessionLocal() as session:
        assert session.scalar(select(func.count()).select_from(ApprovalActionModel)) == 1


def test_admin_cannot_decide_the_same_request_twice() -> None:
    client = authenticated_client()
    queue = client.get("/api/v1/admin/donation-requests")
    request_id = next(item["id"] for item in queue.json() if item["status"] == "PENDING_APPROVAL")
    first = client.post(
        f"/api/v1/admin/donation-requests/{request_id}/reject",
        json={"internal_note": "Unable to validate request"},
    )

    second = client.post(
        f"/api/v1/admin/donation-requests/{request_id}/approve",
        json={"internal_note": "Changed mind"},
    )

    assert first.status_code == 200
    assert second.status_code == 409


def test_logout_revokes_the_persisted_session() -> None:
    client = authenticated_client()

    assert client.get("/api/v1/admin/auth/me").status_code == 200
    assert client.post("/api/v1/admin/auth/logout").status_code == 204
    assert client.get("/api/v1/admin/auth/me").status_code == 401
    with SessionLocal() as session:
        stored_session = session.scalar(select(AdminSessionModel))
        assert stored_session is not None
        assert stored_session.revoked_at is not None


def test_mutating_admin_request_rejects_an_untrusted_origin() -> None:
    response = TestClient(app).post(
        "/api/v1/admin/auth/login",
        headers={"Origin": "https://attacker.example"},
        json={"email": "admin@prerna.org", "password": "PrernaDemo!2026"},
    )

    assert response.status_code == 403


def test_login_is_rate_limited_after_five_failures() -> None:
    client = TestClient(app)
    for _ in range(5):
        response = client.post(
            "/api/v1/admin/auth/login",
            json={"email": "admin@prerna.org", "password": "wrong-password"},
        )
        assert response.status_code == 401

    blocked = client.post(
        "/api/v1/admin/auth/login",
        json={"email": "admin@prerna.org", "password": "PrernaDemo!2026"},
    )

    assert blocked.status_code == 429
