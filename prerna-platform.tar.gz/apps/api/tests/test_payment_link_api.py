from datetime import UTC, datetime, timedelta
from urllib.parse import parse_qs, urlparse

from fastapi.testclient import TestClient
from prerna_api.database import SessionLocal
from prerna_api.main import app
from prerna_api.models import DonationRequestModel
from prerna_api.records import CommunicationModel, DonorModel, PaymentLinkModel
from sqlalchemy import func, select


def authenticated_client() -> TestClient:
    client = TestClient(app)
    response = client.post(
        "/api/v1/admin/auth/login",
        json={"email": "admin@prerna.org", "password": "PrernaDemo!2026"},
    )
    assert response.status_code == 200
    return client


def create_request(request_id: str, status: str = "PENDING_APPROVAL") -> None:
    with SessionLocal() as db:
        donor = DonorModel(display_name="Link Test", email="link@example.org", mobile="+919876543210")
        db.add(donor)
        db.flush()
        db.add(
            DonationRequestModel(
                id=request_id,
                donor_id=donor.id,
                donor_name=donor.display_name,
                donor_email="l***@example.org",
                donor_mobile="+91••••••3210",
                amount=2500,
                programmes=["Education"],
                frequency="ONE_TIME",
                verification_status="VERIFIED",
                returning_donor=False,
                submitted_at=datetime.now(UTC),
                status=status,
            )
        )
        db.commit()


def token_from(url: str) -> str:
    return parse_qs(urlparse(url).fragment)["token"][0]


def test_link_requires_approval_and_retry_recovers_same_secure_link() -> None:
    create_request("DR-LINK-001")
    client = authenticated_client()

    blocked = client.post("/api/v1/admin/donation-requests/DR-LINK-001/payment-link")
    assert blocked.status_code == 409
    assert client.post("/api/v1/admin/donation-requests/DR-LINK-001/approve", json={}).status_code == 200

    issued = client.post("/api/v1/admin/donation-requests/DR-LINK-001/payment-link")
    recovered = client.post("/api/v1/admin/donation-requests/DR-LINK-001/payment-link")
    assert issued.status_code == 201
    assert issued.json()["created"] is True
    assert recovered.json()["created"] is False
    assert recovered.json()["url"] == issued.json()["url"]
    raw_token = token_from(issued.json()["url"])

    with SessionLocal() as db:
        row = db.scalar(select(PaymentLinkModel).where(PaymentLinkModel.donation_request_id == "DR-LINK-001"))
        assert row is not None
        assert raw_token not in row.token_hash
        assert raw_token not in row.encrypted_token
        assert db.scalar(select(func.count()).select_from(CommunicationModel)) == 1

    consumed = client.post("/api/v1/payment-links/consume", json={"token": raw_token})
    repeated = client.post("/api/v1/payment-links/consume", json={"token": raw_token})
    assert consumed.status_code == 200
    assert repeated.status_code == 410


def test_expired_link_can_be_reissued_but_rejected_request_cannot() -> None:
    create_request("DR-LINK-002", status="APPROVED")
    create_request("DR-LINK-003", status="REJECTED")
    client = authenticated_client()

    first = client.post("/api/v1/admin/donation-requests/DR-LINK-002/payment-link").json()
    with SessionLocal() as db:
        row = db.get(PaymentLinkModel, first["id"])
        assert row is not None
        row.created_at = datetime.now(UTC) - timedelta(days=2)
        row.expires_at = datetime.now(UTC) - timedelta(seconds=1)
        db.commit()
    reissued = client.post("/api/v1/admin/donation-requests/DR-LINK-002/payment-link")
    rejected = client.post("/api/v1/admin/donation-requests/DR-LINK-003/payment-link")

    assert reissued.status_code == 201
    assert reissued.json()["id"] != first["id"]
    assert token_from(reissued.json()["url"]) != token_from(first["url"])
    assert rejected.status_code == 409
