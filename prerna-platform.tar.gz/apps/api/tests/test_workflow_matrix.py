import itertools

import pytest
from prerna_api.workflow import (
    TRANSITIONS,
    DonationWorkflow,
    RequestState,
    WorkflowAction,
    WorkflowViolation,
)

pytestmark = pytest.mark.no_db


@pytest.mark.parametrize(
    ("state", "action"),
    list(itertools.product(RequestState, WorkflowAction)),
)
def test_exhaustive_transition_matrix(state: RequestState, action: WorkflowAction) -> None:
    workflow = DonationWorkflow(state)
    expected = TRANSITIONS.get((state, action))

    if expected is None:
        with pytest.raises(WorkflowViolation):
            workflow.apply(action)
    else:
        assert workflow.apply(action).state is expected


@pytest.mark.parametrize(
    "action",
    [
        WorkflowAction.ISSUE_PAYMENT_LINK,
        WorkflowAction.CONFIRM_PAYMENT,
        WorkflowAction.RECORD_OFFLINE,
        WorkflowAction.CONFIRM_OFFLINE,
        WorkflowAction.START_MANDATE,
        WorkflowAction.ACTIVATE_MANDATE,
    ],
)
def test_financial_actions_cannot_precede_approval(action: WorkflowAction) -> None:
    with pytest.raises(WorkflowViolation):
        DonationWorkflow().apply(action)
