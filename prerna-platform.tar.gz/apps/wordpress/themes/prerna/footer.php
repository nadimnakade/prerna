</main><footer class="site-footer"><div class="shell"><strong>Prerna</strong><p>Education, healthcare and sports opportunities built with communities.</p><?php
$legal_pages = [];
foreach (['privacy-policy', 'terms-of-use', 'donation-terms'] as $slug) {
    $page = get_page_by_path($slug, OBJECT, 'page');
    if ($page instanceof WP_Post && $page->post_status === 'publish') { $legal_pages[] = $page; }
}
if ($legal_pages) : ?><nav aria-label="Legal"><ul><?php foreach ($legal_pages as $page) : ?><li><a href="<?php echo esc_url(get_permalink($page)); ?>"><?php echo esc_html(get_the_title($page)); ?></a></li><?php endforeach; ?></ul></nav><?php endif; ?></div></footer><?php wp_footer(); ?></body></html>
