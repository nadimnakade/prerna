<?php get_header(); ?>
<?php while (have_posts()): the_post(); ?><div class="shell content"><h1><?php the_title(); ?></h1><?php the_content(); ?>
<section class="collection"><h2>Reports and disclosures</h2><?php $documents=new WP_Query(['post_type'=>'prerna_document','post_status'=>'publish','posts_per_page'=>20]); ?>
<?php if ($documents->have_posts()): while ($documents->have_posts()): $documents->the_post(); ?><article><h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3><p><?php echo esc_html(get_the_excerpt()); ?></p></article><?php endwhile; else: ?><p>Approved reports and disclosures will appear here when published.</p><?php endif; wp_reset_postdata(); ?></section></div><?php endwhile; ?>
<?php get_footer(); ?>
