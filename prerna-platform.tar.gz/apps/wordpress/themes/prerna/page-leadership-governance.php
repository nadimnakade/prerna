<?php get_header(); ?>
<?php while (have_posts()): the_post(); ?><div class="shell content"><h1><?php the_title(); ?></h1><?php the_content(); ?>
<section class="people-grid"><?php $people=new WP_Query(['post_type'=>'prerna_person','post_status'=>'publish','posts_per_page'=>30,'orderby'=>'menu_order title','order'=>'ASC']); ?>
<?php if ($people->have_posts()): while ($people->have_posts()): $people->the_post(); ?><article><?php if(has_post_thumbnail()){the_post_thumbnail('medium');} ?><h2><?php the_title(); ?></h2><p><?php echo esc_html(get_the_excerpt()); ?></p><a href="<?php the_permalink(); ?>">Read profile</a></article><?php endwhile; else: ?><p>Approved board and team profiles will appear here when published.</p><?php endif; wp_reset_postdata(); ?></section></div><?php endwhile; ?>
<?php get_footer(); ?>
