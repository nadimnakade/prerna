<?php
if (!defined('ABSPATH')) { exit; }
add_action('wp_enqueue_scripts', static function (): void {
    wp_enqueue_style('prerna', get_stylesheet_uri(), [], wp_get_theme()->get('Version'));
});
