<?php get_header(); ?>
<?php while (have_posts()): the_post(); ?>
<div class="shell hero">
  <div><h1><?php the_title(); ?></h1><div class="hero-copy"><?php the_content(); ?></div><a class="button" href="<?php echo prerna_donate_url(); ?>">Start a donation request</a></div>
  <div class="hero-panel"><h2>Give where it matters to you</h2><p>Choose one programme, several, or let Prerna direct support where it is needed most.</p></div>
</div>
<?php endwhile; ?>
<section class="section" id="programmes"><div class="shell"><h2>Three paths to stronger communities</h2><div class="programme-grid">
<?php $programmes = new WP_Query(['post_type'=>'prerna_programme','post_status'=>'publish','posts_per_page'=>3,'orderby'=>'menu_order title','order'=>'ASC']); ?>
<?php while ($programmes->have_posts()): $programmes->the_post(); ?><article class="programme"><h3><?php the_title(); ?></h3><p><?php echo esc_html(get_the_excerpt()); ?></p><a href="<?php the_permalink(); ?>">Explore <?php the_title(); ?></a></article><?php endwhile; wp_reset_postdata(); ?>
</div></div></section>
<?php get_footer(); ?>
