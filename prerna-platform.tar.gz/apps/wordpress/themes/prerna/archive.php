<?php get_header(); ?>
<div class="shell content archive-list">
  <h1><?php the_archive_title(); ?></h1>
  <?php if (have_posts()): while (have_posts()): the_post(); ?>
    <article><p class="entry-date"><?php echo esc_html(get_the_date()); ?></p><h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2><p><?php echo esc_html(get_the_excerpt()); ?></p></article>
  <?php endwhile; the_posts_pagination(); else: ?><p>No published items are available yet.</p><?php endif; ?>
</div>
<?php get_footer(); ?>
