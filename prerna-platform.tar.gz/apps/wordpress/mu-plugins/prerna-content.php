<?php
/**
 * Plugin Name: Prerna Content Model
 * Description: Version-controlled public content types and editor safeguards.
 */

if (!defined('ABSPATH')) { exit; }

add_action('init', static function (): void {
    $types = [
        'prerna_programme' => ['Programme', 'Programmes', 'dashicons-heart'],
        'prerna_story' => ['Story', 'Stories', 'dashicons-format-quote'],
        'prerna_document' => ['Document', 'Reports & documents', 'dashicons-media-document'],
        'prerna_person' => ['Profile', 'Leadership & governance', 'dashicons-groups'],
    ];
    foreach ($types as $type => [$singular, $plural, $icon]) {
        $archive_slug = ['prerna_story' => 'stories', 'prerna_document' => 'reports'][$type] ?? false;
        register_post_type($type, [
            'labels' => ['name' => $plural, 'singular_name' => $singular, 'add_new_item' => "Add $singular", 'edit_item' => "Edit $singular"],
            'public' => true,
            'show_in_rest' => true,
            'menu_icon' => $icon,
            'supports' => ['title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'custom-fields'],
            'has_archive' => $archive_slug,
            'rewrite' => ['slug' => $archive_slug ?: str_replace('prerna_', '', $type)],
        ]);
    }
});

add_action('after_setup_theme', static function (): void {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('responsive-embeds');
    add_theme_support('editor-styles');
    add_theme_support('html5', ['search-form', 'gallery', 'caption', 'style', 'script']);
    register_nav_menus(['primary' => 'Primary navigation', 'footer' => 'Footer navigation']);
});

add_action('init', static function (): void {
    foreach (['post', 'page', 'prerna_programme', 'prerna_story', 'prerna_document', 'prerna_person'] as $type) {
        foreach (['prerna_seo_title', 'prerna_seo_description'] as $key) {
            register_post_meta($type, $key, [
                'type' => 'string', 'single' => true, 'show_in_rest' => true,
                'sanitize_callback' => 'sanitize_text_field',
                'auth_callback' => static fn (): bool => current_user_can('edit_posts'),
            ]);
        }
    }
});

add_action('add_meta_boxes', static function (): void {
    foreach (['post', 'page', 'prerna_programme', 'prerna_story', 'prerna_document', 'prerna_person'] as $type) {
        add_meta_box('prerna-seo', 'Search and social metadata', 'prerna_render_seo_box', $type, 'normal', 'default');
    }
});

function prerna_render_seo_box(WP_Post $post): void {
    wp_nonce_field('prerna_save_seo', 'prerna_seo_nonce');
    $title = get_post_meta($post->ID, 'prerna_seo_title', true);
    $description = get_post_meta($post->ID, 'prerna_seo_description', true);
    echo '<p><label for="prerna-seo-title"><strong>SEO title</strong></label><br>';
    echo '<input class="widefat" id="prerna-seo-title" name="prerna_seo_title" maxlength="60" value="' . esc_attr($title) . '"></p>';
    echo '<p><label for="prerna-seo-description"><strong>Meta description</strong></label><br>';
    echo '<textarea class="widefat" id="prerna-seo-description" name="prerna_seo_description" maxlength="160" rows="3">' . esc_textarea($description) . '</textarea></p>';
}

add_action('save_post', static function (int $post_id): void {
    if (!isset($_POST['prerna_seo_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['prerna_seo_nonce'])), 'prerna_save_seo')) { return; }
    if (!current_user_can('edit_post', $post_id) || wp_is_post_revision($post_id)) { return; }
    foreach (['prerna_seo_title', 'prerna_seo_description'] as $key) {
        if (isset($_POST[$key])) { update_post_meta($post_id, $key, sanitize_text_field(wp_unslash($_POST[$key]))); }
    }
});

add_filter('pre_get_document_title', static function (string $title): string {
    if (!is_singular()) { return $title; }
    $custom = get_post_meta(get_queried_object_id(), 'prerna_seo_title', true);
    return $custom !== '' ? $custom : $title;
});

add_action('wp_head', static function (): void {
    if (is_admin()) { return; }
    $custom_description = is_singular() ? get_post_meta(get_queried_object_id(), 'prerna_seo_description', true) : '';
    $description = $custom_description !== '' ? $custom_description : (is_singular() && has_excerpt() ? get_the_excerpt() : get_bloginfo('description'));
    echo '<meta name="description" content="' . esc_attr(wp_strip_all_tags($description)) . '">' . "\n";
    echo '<meta property="og:title" content="' . esc_attr(wp_get_document_title()) . '">' . "\n";
    echo '<meta property="og:description" content="' . esc_attr(wp_strip_all_tags($description)) . '">' . "\n";
    if (is_singular() && has_post_thumbnail()) {
        $image = wp_get_attachment_image_url(get_post_thumbnail_id(), 'large');
        if ($image) { echo '<meta property="og:image" content="' . esc_url($image) . '">' . "\n"; }
    }
}, 1);

add_action('init', static function (): void {
    foreach (['post', 'page'] as $type) { remove_post_type_support($type, 'comments'); }
});

add_shortcode('prerna_contact_form', static function (array $attributes): string {
    $attributes = shortcode_atts(['topic' => 'general'], $attributes, 'prerna_contact_form');
    $topic = in_array($attributes['topic'], ['general', 'csr', 'volunteer'], true) ? $attributes['topic'] : 'general';
    $state = isset($_GET['enquiry']) ? sanitize_key(wp_unslash($_GET['enquiry'])) : '';
    ob_start();
    if ($state === 'sent') { echo '<p class="form-notice success" role="status">Thank you. Your message has been sent to the Prerna team.</p>'; }
    if ($state === 'error') { echo '<p class="form-notice error" role="alert">We could not send your message. Please try again later.</p>'; }
    ?>
    <form class="contact-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="prerna_contact">
        <input type="hidden" name="topic" value="<?php echo esc_attr($topic); ?>">
        <?php wp_nonce_field('prerna_contact', 'prerna_contact_nonce'); ?>
        <div class="form-field"><label for="prerna-name">Name</label><input id="prerna-name" name="name" required maxlength="100" autocomplete="name"></div>
        <div class="form-field"><label for="prerna-email">Email</label><input id="prerna-email" name="email" type="email" required maxlength="254" autocomplete="email"></div>
        <div class="form-field"><label for="prerna-phone">Phone <span>(optional)</span></label><input id="prerna-phone" name="phone" type="tel" maxlength="30" autocomplete="tel"></div>
        <div class="form-field"><label for="prerna-message">Message</label><textarea id="prerna-message" name="message" required maxlength="3000" rows="6"></textarea></div>
        <div class="form-trap" aria-hidden="true"><label for="prerna-company">Company</label><input id="prerna-company" name="company" tabindex="-1" autocomplete="off"></div>
        <button class="button" type="submit">Send message</button>
    </form>
    <?php
    return (string) ob_get_clean();
});

function prerna_handle_contact(): void {
    $fallback = wp_get_referer() ?: home_url('/contact/');
    if (!isset($_POST['prerna_contact_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['prerna_contact_nonce'])), 'prerna_contact')) {
        wp_safe_redirect(add_query_arg('enquiry', 'error', $fallback)); exit;
    }
    if (!empty($_POST['company'])) { wp_safe_redirect(add_query_arg('enquiry', 'sent', $fallback)); exit; }
    $name = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
    $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
    $phone = isset($_POST['phone']) ? sanitize_text_field(wp_unslash($_POST['phone'])) : '';
    $message = isset($_POST['message']) ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';
    $topic = isset($_POST['topic']) ? sanitize_key(wp_unslash($_POST['topic'])) : 'general';
    $topic = in_array($topic, ['general', 'csr', 'volunteer'], true) ? $topic : 'general';
    if ($name === '' || !is_email($email) || $message === '') { wp_safe_redirect(add_query_arg('enquiry', 'error', $fallback)); exit; }
    $body = "Name: $name\nEmail: $email\nPhone: $phone\n\n$message";
    $sent = wp_mail(get_option('admin_email'), 'Prerna website enquiry: ' . $topic, $body, ['Reply-To: ' . $name . ' <' . $email . '>']);
    wp_safe_redirect(add_query_arg('enquiry', $sent ? 'sent' : 'error', $fallback)); exit;
}
add_action('admin_post_nopriv_prerna_contact', 'prerna_handle_contact');
add_action('admin_post_prerna_contact', 'prerna_handle_contact');

function prerna_donate_url(?string $slug = null): string {
    $base = defined('PRERNA_DONATE_URL') ? PRERNA_DONATE_URL : 'http://donate.localhost:8088';
    $slug = sanitize_title((string) $slug);
    if ($slug === '' || !prerna_is_active_programme_slug($slug)) {
        return esc_url($base);
    }
    return esc_url(add_query_arg('programme', $slug, $base));
}

function prerna_is_active_programme_slug(string $slug): bool {
    $cache_key = 'prerna_active_programme_slugs';
    $slugs = get_transient($cache_key);
    if (!is_array($slugs)) {
        $api = defined('PRERNA_API_URL') ? PRERNA_API_URL : 'http://api:8000/api/v1';
        $response = wp_remote_get($api . '/programmes', ['timeout' => 2]);
        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            return false;
        }
        $payload = json_decode(wp_remote_retrieve_body($response), true);
        $slugs = [];
        foreach (is_array($payload) ? $payload : [] as $programme) {
            if (!empty($programme['is_active']) && !empty($programme['wordpress_slug'])) {
                $slugs[] = sanitize_title($programme['wordpress_slug']);
            }
        }
        set_transient($cache_key, $slugs, 5 * MINUTE_IN_SECONDS);
    }
    return in_array($slug, $slugs, true);
}
