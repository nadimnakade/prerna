<?php
/** Idempotent local content bootstrap. Run with: wp eval-file bootstrap.php */

if (!defined('ABSPATH')) { exit(1); }

$sample = get_page_by_path('hello-world', OBJECT, 'post');
if ($sample && $sample->post_title === 'Hello world!') { wp_delete_post($sample->ID, true); }
$sample_page = get_page_by_path('sample-page', OBJECT, 'page');
if ($sample_page && $sample_page->post_title === 'Sample Page') { wp_delete_post($sample_page->ID, true); }
foreach (get_comments(['post_id' => 1]) as $comment) { wp_delete_comment($comment->comment_ID, true); }

$pages = [
    'home' => ['Opportunity should not depend on circumstance.', 'Prerna brings people together around education, healthcare and sport so communities can build lasting possibility.', 'publish'],
    'about' => ['About Prerna', 'Prerna works across education, healthcare and sports. Replace this draft with Prerna-approved founding story, vision and approach.', 'publish'],
    'leadership-governance' => ['Leadership and governance', 'Publish board and team profiles from the Leadership and governance menu.', 'publish'],
    'impact-transparency' => ['Impact and transparency', 'Publish approved annual reports, audited financials and fund-utilisation documents here.', 'publish'],
    'ways-to-give' => ['Ways to give', 'Learn about one-time giving, monthly giving, gifts in memory, corporate CSR and volunteering.', 'publish'],
    'corporate-csr' => ['Corporate and CSR partnerships', "Contact Prerna to discuss an approved partnership route.\n\n[prerna_contact_form topic=\"csr\"]", 'publish'],
    'volunteer' => ['Volunteer with Prerna', "Tell the Prerna team how you would like to help.\n\n[prerna_contact_form topic=\"volunteer\"]", 'publish'],
    'contact' => ['Contact and grievance', "Send the Prerna team a message using the form below.\n\n[prerna_contact_form topic=\"general\"]", 'publish'],
    'privacy-policy' => ['Privacy policy', 'Prerna-approved privacy text is required before this page can be published.', 'draft'],
    'terms-of-use' => ['Terms of use', 'Prerna-approved terms of use are required before this page can be published.', 'draft'],
    'donation-terms' => ['Donation terms', 'Prerna-approved donation terms are required before this page can be published.', 'draft'],
];

$page_ids = [];
foreach ($pages as $slug => [$title, $content, $status]) {
    $existing = get_page_by_path($slug, OBJECT, 'page');
    $legal_placeholder = $existing && (
        str_contains($existing->post_content, 'privacy-policy-tutorial') ||
        str_starts_with(trim($existing->post_content), 'Draft placeholder.') ||
        str_starts_with(trim($existing->post_content), 'Prerna-approved ')
    );
    if ($legal_placeholder && in_array($slug, ['privacy-policy', 'terms-of-use', 'donation-terms'], true)) {
        wp_update_post(['ID' => $existing->ID, 'post_title' => $title, 'post_name' => $slug,
            'post_content' => $content, 'post_status' => 'draft']);
    }
    $replaceable = [
        'corporate-csr' => 'Contact Prerna to discuss an approved partnership route.',
        'contact' => 'Replace this draft with Prerna-approved contact and grievance details before public launch.',
    ];
    if ($existing && isset($replaceable[$slug]) && trim($existing->post_content) === $replaceable[$slug]) {
        wp_update_post(['ID' => $existing->ID, 'post_content' => $content]);
    }
    $page_ids[$slug] = $existing ? $existing->ID : wp_insert_post([
        'post_type' => 'page', 'post_status' => $status, 'post_name' => $slug,
        'post_title' => $title, 'post_content' => $content,
    ]);
}
update_option('show_on_front', 'page');
update_option('page_on_front', $page_ids['home']);
update_option('blogname', 'Prerna');
update_option('blogdescription', 'Education, healthcare and sports opportunities built with communities.');
update_option('permalink_structure', '/%postname%/');

foreach (['education' => 'Education', 'healthcare' => 'Healthcare', 'sports' => 'Sports'] as $slug => $title) {
    if (!get_page_by_path($slug, OBJECT, 'prerna_programme')) {
        wp_insert_post(['post_type' => 'prerna_programme', 'post_status' => 'publish', 'post_name' => $slug,
            'post_title' => $title, 'post_excerpt' => "Support Prerna's $title programme.",
            'post_content' => 'Replace this draft with Prerna-approved programme narrative, outcomes and imagery.']);
    }
}

$menu_name = 'Primary navigation';
$menu = wp_get_nav_menu_object($menu_name);
$menu_id = $menu ? $menu->term_id : wp_create_nav_menu($menu_name);
if (!is_wp_error($menu_id)) {
    $primary_items = wp_get_nav_menu_items($menu_id) ?: [];
    $labels = ['about' => 'About', 'leadership-governance' => 'Leadership', 'ways-to-give' => 'Ways to give',
        'impact-transparency' => 'Transparency', 'corporate-csr' => 'CSR', 'contact' => 'Contact'];
    foreach ($labels as $slug => $label) {
        $match = array_values(array_filter($primary_items, static fn ($item) => (int) $item->object_id === (int) $page_ids[$slug]));
        wp_update_nav_menu_item($menu_id, $match ? $match[0]->ID : 0, ['menu-item-title' => $label,
            'menu-item-object-id' => $page_ids[$slug], 'menu-item-object' => 'page',
            'menu-item-type' => 'post_type', 'menu-item-status' => 'publish']);
    }
    $stories_url = home_url('/stories/');
    $has_stories = array_filter(wp_get_nav_menu_items($menu_id) ?: [], static fn ($item) => $item->url === $stories_url);
    if (!$has_stories) {
        wp_update_nav_menu_item($menu_id, 0, ['menu-item-title' => 'Stories', 'menu-item-url' => $stories_url,
            'menu-item-type' => 'custom', 'menu-item-status' => 'publish']);
    }
}
$locations = get_theme_mod('nav_menu_locations', []);
$locations['primary'] = (int) $menu_id;

set_theme_mod('nav_menu_locations', $locations);
flush_rewrite_rules();
