import { FormEvent, useEffect, useMemo, useState } from "react";

type Programme = { id: string; name: string; wordpress_slug: string | null };
type FormData = {
  programme: string; frequency: "ONE_TIME" | "MONTHLY"; amount: string; name: string; email: string;
  mobile: string; line1: string; line2: string; city: string; state: string; postalCode: string;
  identifier: string; emailOptIn: boolean; smsOptIn: boolean; whatsappOptIn: boolean;
  consentConfirmed: boolean; termsAccepted: boolean;
};

function initialForm(): FormData {
  const search = typeof window === "undefined" ? "" : window.location.search;
  return {
    programme: new URLSearchParams(search).get("programme") ?? "", frequency: "ONE_TIME",
    amount: "", name: "", email: "", mobile: "", line1: "", line2: "", city: "", state: "",
    postalCode: "", identifier: "", emailOptIn: false, smsOptIn: false, whatsappOptIn: false,
    consentConfirmed: false, termsAccepted: false,
  };
}
const steps = ["Your gift", "Your details", "Verification", "Preferences", "Review"];

async function api<T>(path: string, options?: RequestInit): Promise<T> {
  const response = await fetch(`/api/v1${path}`, { ...options, headers: { "Content-Type": "application/json", ...options?.headers } });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.detail ?? "Something went wrong. Please try again.");
  return body as T;
}

export function App() {
  const [step, setStep] = useState(0);
  const [form, setForm] = useState(initialForm);
  const [programmes, setProgrammes] = useState<Programme[]>([]);
  const [verificationToken, setVerificationToken] = useState("");
  const [otp, setOtp] = useState("");
  const [developmentCode, setDevelopmentCode] = useState("");
  const [verified, setVerified] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [confirmation, setConfirmation] = useState<{ request_id: string; status: string } | null>(null);
  const [submissionId] = useState(() => `web-${crypto.randomUUID()}`);

  useEffect(() => {
    api<Programme[]>("/programmes").then((items) => {
      const mapped = items.filter((item) => item.wordpress_slug);
      setProgrammes(mapped);
      setForm((current) => ({ ...current, programme: mapped.some((item) => item.wordpress_slug === current.programme) ? current.programme : mapped[0]?.wordpress_slug ?? "" }));
    }).catch((reason: Error) => setError(reason.message));
  }, []);

  const selectedProgramme = useMemo(() => programmes.find((item) => item.wordpress_slug === form.programme), [form.programme, programmes]);
  function update<K extends keyof FormData>(key: K, value: FormData[K]) { setForm((current) => ({ ...current, [key]: value })); setError(""); }
  function next(event: FormEvent<HTMLFormElement>) { event.preventDefault(); setError(""); setStep((current) => Math.min(current + 1, steps.length - 1)); window.scrollTo({ top: 0, behavior: "smooth" }); }

  async function sendCode() {
    setBusy(true); setError("");
    try {
      const result = await api<{ verification_token: string; development_code?: string }>("/donations/verification/start", { method: "POST", body: JSON.stringify({ email: form.email, mobile: form.mobile }) });
      setVerificationToken(result.verification_token); setDevelopmentCode(result.development_code ?? "");
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Could not send the code."); }
    finally { setBusy(false); }
  }

  async function confirmCode(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError("");
    try {
      await api("/donations/verification/confirm", { method: "POST", body: JSON.stringify({ verification_token: verificationToken, code: otp }) });
      setVerified(true); setStep(3);
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Verification failed."); }
    finally { setBusy(false); }
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!verified) { setError("Please verify your contact details first."); return; }
    setBusy(true); setError("");
    try {
      const result = await api<{ request_id: string; status: string }>("/donations/requests", {
        method: "POST", headers: { "Idempotency-Key": submissionId },
        body: JSON.stringify({
          verification_token: verificationToken, name: form.name, email: form.email, mobile: form.mobile,
          address: { line1: form.line1, line2: form.line2 || null, city: form.city, state: form.state, postal_code: form.postalCode, country_code: "IN" },
          identifier_type: "PAN", protected_identifier: form.identifier, programme_slugs: [form.programme],
          frequency: form.frequency, amount: form.amount, terms_accepted: form.termsAccepted,
          preferences: form.consentConfirmed ? { consent_confirmed: true, email: form.emailOptIn, sms: form.smsOptIn, whatsapp: form.whatsappOptIn } : null,
        }),
      });
      setConfirmation(result);
    } catch (reason) { setError(reason instanceof Error ? reason.message : "Submission failed."); }
    finally { setBusy(false); }
  }

  if (confirmation) return <main className="donation-shell"><section className="confirmation" aria-labelledby="confirmation-title"><p className="eyebrow">Request received</p><h1 id="confirmation-title">Thank you for choosing to help.</h1><p>Your donation request is awaiting Prerna review. No payment has been taken.</p><dl><dt>Request reference</dt><dd>{confirmation.request_id}</dd><dt>Status</dt><dd>Pending approval</dd></dl><a href="http://prerna.localhost:8088">Return to the Prerna website</a></section></main>;

  return <main className="donation-shell">
    <header className="journey-header"><a className="brand" href="http://prerna.localhost:8088">Prerna</a><span>Secure donation request</span></header>
    <div className="journey-layout">
      <aside aria-label="Donation progress"><p className="eyebrow">Prerna donation journey</p><ol>{steps.map((label, index) => <li key={label} className={index === step ? "current" : index < step ? "complete" : ""}><span>{index + 1}</span>{label}</li>)}</ol><p className="privacy-note">Your PAN is encrypted and never returned in full.</p></aside>
      <section className="form-card"><p className="step-label">Step {step + 1} of {steps.length}</p>{error && <div className="error" role="alert">{error}</div>}
        {step === 0 && <form onSubmit={next}><h1>Shape your contribution.</h1><p className="lede">Choose where your support goes and whether it is a one-time or monthly commitment.</p><label>Programme<select required value={form.programme} onChange={(e) => update("programme", e.target.value)}><option value="" disabled>Select a programme</option>{programmes.map((item) => <option key={item.id} value={item.wordpress_slug ?? ""}>{item.name}</option>)}</select></label><fieldset><legend>Frequency</legend><div className="choice-row"><label><input type="radio" name="frequency" checked={form.frequency === "ONE_TIME"} onChange={() => update("frequency", "ONE_TIME")} /> One time</label><label><input type="radio" name="frequency" checked={form.frequency === "MONTHLY"} onChange={() => update("frequency", "MONTHLY")} /> Monthly</label></div></fieldset><label>Amount in INR<input required type="number" min="1" step="0.01" inputMode="decimal" value={form.amount} onChange={(e) => update("amount", e.target.value)} /></label><Navigation step={step} busy={busy} /></form>}
        {step === 1 && <form onSubmit={next}><h1>Tell us about you.</h1><div className="field-grid"><label>Full name<input required autoComplete="name" value={form.name} onChange={(e) => update("name", e.target.value)} /></label><label>Email address<input required type="email" autoComplete="email" value={form.email} onChange={(e) => update("email", e.target.value)} /></label><label>Mobile number<input required type="tel" autoComplete="tel" pattern="[0-9+ ()-]{10,40}" value={form.mobile} onChange={(e) => update("mobile", e.target.value)} /></label><label className="wide">Address line 1<input required autoComplete="address-line1" value={form.line1} onChange={(e) => update("line1", e.target.value)} /></label><label className="wide">Address line 2 <small>Optional</small><input autoComplete="address-line2" value={form.line2} onChange={(e) => update("line2", e.target.value)} /></label><label>City<input required autoComplete="address-level2" value={form.city} onChange={(e) => update("city", e.target.value)} /></label><label>State<input required autoComplete="address-level1" value={form.state} onChange={(e) => update("state", e.target.value)} /></label><label>PIN code<input required inputMode="numeric" pattern="[1-9][0-9]{5}" autoComplete="postal-code" value={form.postalCode} onChange={(e) => update("postalCode", e.target.value)} /></label></div><Navigation step={step} busy={busy} back={() => setStep(0)} /></form>}
        {step === 2 && <form onSubmit={confirmCode}><h1>Verify securely.</h1><p className="lede">We verify your contact details and PAN before creating a request.</p><label>PAN or approved identifier<input required autoCapitalize="characters" minLength={4} maxLength={40} value={form.identifier} onChange={(e) => update("identifier", e.target.value.toUpperCase())} /></label>{!verificationToken ? <button className="primary" type="button" disabled={busy || !form.identifier} onClick={sendCode}>{busy ? "Sending…" : "Send verification code"}</button> : <><label>Six-digit code<input required inputMode="numeric" pattern="[0-9]{6}" maxLength={6} value={otp} onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))} /></label>{developmentCode && <p className="dev-code" role="status">Local test code: <strong>{developmentCode}</strong></p>}<p><button className="text-button" type="button" onClick={sendCode} disabled={busy}>Send a new code</button></p></>}<Navigation step={step} busy={busy || !verificationToken} back={() => setStep(1)} nextLabel="Verify and continue" /></form>}
        {step === 3 && <form onSubmit={next}><h1>Choose how we stay in touch.</h1><p className="lede">These preferences are optional and recorded only with your explicit consent.</p><div className="check-list"><label><input type="checkbox" checked={form.emailOptIn} onChange={(e) => update("emailOptIn", e.target.checked)} /> Email updates</label><label><input type="checkbox" checked={form.smsOptIn} onChange={(e) => update("smsOptIn", e.target.checked)} /> SMS updates</label><label><input type="checkbox" checked={form.whatsappOptIn} onChange={(e) => update("whatsappOptIn", e.target.checked)} /> WhatsApp updates</label></div>{(form.emailOptIn || form.smsOptIn || form.whatsappOptIn) && <label className="consent"><input required type="checkbox" checked={form.consentConfirmed} onChange={(e) => update("consentConfirmed", e.target.checked)} /> I explicitly consent to the communication choices selected above.</label>}<Navigation step={step} busy={busy} back={() => setStep(2)} /></form>}
        {step === 4 && <form onSubmit={submit}><h1>Review your request.</h1><dl className="review"><dt>Programme</dt><dd>{selectedProgramme?.name}</dd><dt>Frequency</dt><dd>{form.frequency === "MONTHLY" ? "Monthly" : "One time"}</dd><dt>Amount</dt><dd>₹{Number(form.amount).toLocaleString("en-IN")}</dd><dt>Donor</dt><dd>{form.name}</dd><dt>Contact</dt><dd>{form.email}<br />{form.mobile}</dd><dt>Identifier</dt><dd>••••{form.identifier.slice(-4)}</dd></dl><label className="consent"><input required type="checkbox" checked={form.termsAccepted} onChange={(e) => update("termsAccepted", e.target.checked)} /> I confirm these details and accept Prerna's donation terms.</label><p className="review-note">Submitting creates a request for Prerna review. It does not take payment.</p><Navigation step={step} busy={busy} back={() => setStep(3)} nextLabel={busy ? "Submitting…" : "Submit request"} /></form>}
      </section>
    </div>
  </main>;
}

function Navigation({ step, busy, back, nextLabel = "Continue" }: { step: number; busy: boolean; back?: () => void; nextLabel?: string }) {
  return <div className="actions">{step > 0 && <button className="secondary" type="button" onClick={back}>Back</button>}<button className="primary" type="submit" disabled={busy}>{nextLabel}</button></div>;
}
