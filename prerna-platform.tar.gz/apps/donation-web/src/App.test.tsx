import { renderToStaticMarkup } from "react-dom/server";
import { afterEach, describe, expect, it, vi } from "vitest";

import { App } from "./App";

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("donation journey", () => {
  it("renders the five-step accessible donor journey without payment language", () => {
    vi.stubGlobal("window", { location: { search: "?programme=education" } });
    vi.stubGlobal("crypto", { randomUUID: () => "test-submission" });
    const markup = renderToStaticMarkup(<App />);

    expect(markup).toContain("Prerna donation journey");
    expect(markup).toContain("Step 1 of 5");
    expect(markup).toContain("Shape your contribution");
    expect(markup).toContain("Monthly");
    expect(markup).not.toContain("card number");
  });
});
