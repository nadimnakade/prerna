export type Admin = { id: string; name: string; email: string };

export type RequestStatus = "PENDING_APPROVAL" | "APPROVED" | "REJECTED" | "PAYMENT_LINK_SENT" | "OFFLINE_RECORDED" | "PAID" | "RECEIPTED" | "FAILED_OR_LAPSED";

export type DonationRequest = {
  id: string;
  donor_name: string;
  donor_email: string;
  donor_mobile: string;
  amount: string;
  programmes: string[];
  frequency: string;
  verification_status: string;
  returning_donor: boolean;
  submitted_at: string;
  status: RequestStatus;
  decided_at: string | null;
  decided_by: string | null;
  internal_note: string | null;
};

export type Dashboard = {
  total_requests: number;
  pending_approvals: number;
  approved_requests: number;
  rejected_requests: number;
  total_requested_amount: string;
};

export type MasterRecord = {
  id: string;
  category: string;
  code: string;
  name: string;
  wordpress_slug: string | null;
  configuration: Record<string, unknown>;
  is_active: boolean;
  updated_by: string | null;
};

export type Setting = { key: string; value: Record<string, unknown>; updated_by: string | null };
export type AdminUser = Admin & { is_active: boolean };
export type RequestContext = {
  request: DonationRequest;
  waiting_minutes: number;
  donor_request_count: number;
  previous_statuses: string[];
  active_payment_link_expires_at: string | null;
};
export type PaymentLink = {
  id: string;
  provider: string;
  provider_reference: string;
  url: string;
  expires_at: string;
  created: boolean;
};
export type Payment = { id: string; donation_request_id: string; amount: string; status: string; provider: string; provider_payment_id: string };
export type Receipt = { id: string; payment_id: string; receipt_number: string; financial_year: string; issued_at: string; document_key: string };
export type OfflineCollection = { id: string; donation_request_id: string; mode: string; reference: string; amount: string; received_on: string; confirmed_at: string | null };
export type Communication = { id: string; donation_request_id: string | null; channel: string; template_key: string; provider: string; status: string; attempt_count: number; last_error: string | null; sent_at: string | null };

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`/api/v1${path}`, {
    credentials: "include",
    ...init,
    headers: { "Content-Type": "application/json", ...init?.headers },
  });
  if (!response.ok) {
    const payload = await response.json().catch(() => ({ detail: "Request failed" }));
    throw new Error(payload.detail ?? "Request failed");
  }
  return response.status === 204 ? (undefined as T) : response.json();
}

export const adminApi = {
  login: (email: string, password: string) =>
    request<Admin>("/admin/auth/login", { method: "POST", body: JSON.stringify({ email, password }) }),
  logout: () => request<void>("/admin/auth/logout", { method: "POST" }),
  me: () => request<Admin>("/admin/auth/me"),
  dashboard: () => request<Dashboard>("/admin/dashboard"),
  requests: () => request<DonationRequest[]>("/admin/donation-requests"),
  decide: (id: string, action: "approve" | "reject", internal_note: string) =>
    request<DonationRequest>(`/admin/donation-requests/${id}/${action}`, {
      method: "POST",
      body: JSON.stringify({ internal_note: internal_note || null }),
    }),
  requestContext: (id: string) => request<RequestContext>(`/admin/donation-requests/${id}/context`),
  issuePaymentLink: (id: string) => request<PaymentLink>(`/admin/donation-requests/${id}/payment-link`, { method: "POST" }),
  payments: () => request<Payment[]>("/admin/payments"),
  receipts: () => request<Receipt[]>("/admin/receipts"),
  offline: () => request<OfflineCollection[]>("/admin/offline-donations"),
  recordOffline: (id: string, payload: { mode: string; reference: string; received_at: string; amount: string }) => request<{ id: string; status: string }>(`/admin/offline-donations/${id}/record-collection`, { method: "POST", body: JSON.stringify(payload) }),
  confirmOffline: (id: string) => request<Receipt>(`/admin/offline-donations/${id}/confirm-finance`, { method: "POST" }),
  communications: () => request<Communication[]>("/admin/communications"),
  retryCommunication: (id: string) => request<Communication>(`/admin/communications/${id}/retry`, { method: "POST" }),
  masters: (category: string) => request<MasterRecord[]>(`/admin/masters/${category}`),
  createMaster: (category: string, payload: { code: string; name: string; wordpress_slug?: string | null }) =>
    request<MasterRecord>(`/admin/masters/${category}`, { method: "POST", body: JSON.stringify(payload) }),
  updateMaster: (category: string, id: string, payload: Partial<MasterRecord>) =>
    request<MasterRecord>(`/admin/masters/${category}/${id}`, { method: "PATCH", body: JSON.stringify(payload) }),
  settings: () => request<Setting[]>("/admin/settings"),
  updateSetting: (key: string, value: Record<string, unknown>) =>
    request<Setting>(`/admin/settings/${key}`, { method: "PUT", body: JSON.stringify({ value }) }),
  users: () => request<AdminUser[]>("/admin/users"),
  createUser: (payload: { name: string; email: string; password: string }) =>
    request<AdminUser>("/admin/users", { method: "POST", body: JSON.stringify(payload) }),
  deactivateUser: (id: string) => request<AdminUser>(`/admin/users/${id}/deactivate`, { method: "POST" }),
};
