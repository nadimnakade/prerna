import { afterEach, describe, expect, it, vi } from "vitest";

import { adminApi } from "./api";

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("admin API client", () => {
  it("sends login credentials through the same-origin API", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ id: "admin-001", name: "Admin", email: "admin@prerna.org" }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      }),
    );
    vi.stubGlobal("fetch", fetchMock);

    await adminApi.login("admin@prerna.org", "secret");

    expect(fetchMock).toHaveBeenCalledWith(
      "/api/v1/admin/auth/login",
      expect.objectContaining({ method: "POST", credentials: "include" }),
    );
  });

  it("surfaces rejected dashboard requests", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response("forbidden", { status: 403 })));

    await expect(adminApi.dashboard()).rejects.toThrow("Request failed");
  });
});
