You are the Lead Solution Architect and Senior Full-Stack Engineer responsible for building the Prerna Website and Basic Donor Management Application.

IMPORTANT:
The attached project documents are the source of truth:
1. Prerna BRD v1.1 – Website and Basic Donor Management Application
2. Prerna Scope of Work v2.0 – Website and Basic Donor Management Application

Read and understand both documents before writing implementation code.

Do NOT invent business rules.
Do NOT silently change requirements.
If a requirement is ambiguous or an open decision exists in the BRD/SOW, identify it clearly and do not make an irreversible assumption.

==================================================
PROJECT OBJECTIVE
==================================================

Build a complete digital platform for Prerna, a Section 8 organisation working across:

- Education
- Healthcare
- Sports

The platform has two major areas:

1. Public Website
2. Donor Management Application

The platform must allow Prerna to manage website content, receive donation requests, verify donors, approve/reject requests, collect online/offline donations, support recurring monthly donations, generate receipts, communicate with donors and produce reports.

IMPORTANT BUSINESS RULE:

A donation request is NOT an immediate payment.

The mandatory flow is:

Donor
→ Donation Request
→ Mobile OTP Verification
→ Identity/PAN Verification
→ Pending Approval
→ Prerna Approval
→ Secure Payment Link
→ Gateway Hosted Checkout
→ Payment Confirmation
→ Receipt Generation
→ Donor Communication

Every donation request requires Prerna approval before payment.

Returning donors also require approval for every new donation.

==================================================
TECHNOLOGY STACK
==================================================

Frontend:
- Next.js
- React
- TypeScript
- Tailwind CSS
- shadcn/ui
- React Hook Form
- Zod
- TanStack Query
- Playwright

Backend:
- Python
- FastAPI
- Pydantic
- SQLAlchemy
- Alembic
- PostgreSQL
- Celery
- Redis

Authentication:
- Secure admin authentication
- HttpOnly secure cookies or equivalent secure session mechanism
- Password hashing using a modern password hashing algorithm

Storage:
- PostgreSQL for application data
- S3-compatible object storage for documents and generated files

Infrastructure:
- Docker
- Docker Compose for local development
- CI/CD
- Development
- Staging
- Production

Payment:
- Razorpay or the gateway selected by Prerna
- MUST use an abstraction/interface so the business layer is not directly coupled to Razorpay

==================================================
HIGH LEVEL ARCHITECTURE
==================================================

Use this architecture:

Next.js
    ↓
FastAPI
    ↓
Application/Domain Services
    ↓
PostgreSQL

External integrations:

FastAPI
 ├── Payment Gateway
 ├── OTP/SMS Provider
 ├── Identity/PAN Verification Provider
 ├── Email Provider
 └── WhatsApp Business Provider

Do NOT put business logic inside React components.

Do NOT put financial/business logic inside the frontend.

Do NOT use WordPress.

The entire public website, CMS and admin system must be implemented using Next.js + FastAPI.

==================================================
APPLICATION AREAS
==================================================

Create:

1. Public Website
2. Donation Portal
3. Admin Dashboard
4. Custom CMS
5. Reporting
6. Payment/Reconciliation
7. Communication System

==================================================
PUBLIC WEBSITE
==================================================

Create these sections:

1. Home
2. About Prerna
3. Leadership and Governance
4. Education
5. Healthcare
6. Sports
7. Impact and Transparency
8. Ways to Give
9. Corporate / CSR Partnerships
10. News / Stories / Updates
11. Contact and Grievance
12. Legal Pages
13. Donation Page

The public website must be:

- Mobile-first
- Responsive
- Fast
- SEO-friendly
- Accessible
- Professional
- Easy to maintain

Implement:

- Page titles
- Meta descriptions
- XML sitemap
- robots.txt
- Open Graph metadata
- Structured metadata where appropriate
- Analytics integration placeholder
- Optimized images
- Proper loading/error states

==================================================
CUSTOM CMS
==================================================

Prerna staff must be able to update website content without developer involvement.

Build a CMS inside the Admin application.

CMS modules:

Pages
Programmes
News
Stories
Leadership
Impact Figures
Reports/Documents
Media
Legal Content
Contact Information
CSR Content

Support:

- Create
- Edit
- Draft
- Publish
- Unpublish
- Delete where appropriate
- Image upload
- Document upload
- Preview
- SEO metadata

Create reusable content components instead of hardcoding website content.

==================================================
PROGRAMMES
==================================================

Create:

Education
Healthcare
Sports

A programme must support:

- Name
- Slug
- Description
- Images
- Content
- Impact information
- Status
- Sort order

Each programme page must have a Donate action.

When a donor clicks Donate from a programme page, that programme should be pre-selected in the donation form.

==================================================
DONATION REQUEST
==================================================

The donor submits a request, not a payment.

Donation form must support:

- Programme selection
- Multiple programme selection
- "Any" programme
- One-time donation
- Monthly donation
- Name
- Email
- Mobile
- PAN or agreed identifier
- Address
- Amount in INR
- Purpose/message
- Communication preferences
- Optional WhatsApp opt-in

Multiple programme selection records donor intent only.

NEVER automatically split the donation amount between programmes.

Perform client-side and server-side validation.

Provide clear validation messages.

Design the form primarily for mobile users.

==================================================
DONATION VERIFICATION
==================================================

Every request requires mobile OTP verification.

Implement:

- OTP generation
- OTP expiry
- OTP retry limits
- Rate limiting
- OTP verification
- Verification status
- Provider abstraction

Identity/PAN verification must also use a provider abstraction.

Create:

IOtpProvider
IIdentityVerificationProvider

Do not hard-code any provider.

Store only the information required by the agreed business requirements.

Aadhaar must NOT be collected unless separately approved.

Returning donors:

- Identify using mobile/email
- Require OTP
- Prefill permitted saved details
- Mask sensitive identifiers
- Still require approval for every donation

==================================================
APPROVAL WORKFLOW
==================================================

Every request must enter:

PENDING_APPROVAL

Admin sees:

- Donor
- Verification status
- Amount
- Programme(s)
- Frequency
- Returning donor indicator
- Submission date
- Waiting time
- 48-hour review target

Admin actions:

- Approve
- Reject
- Add internal note

Store:

- Decision
- Admin user
- Timestamp
- Internal note

Rejection should send the configured standard rejection message.

Do not expose a specific rejection reason to the donor unless explicitly required.

There is no automatic approval.

==================================================
DONATION STATE MACHINE
==================================================

Implement a controlled state machine.

States:

SUBMITTED
VERIFIED
PENDING_APPROVAL
APPROVED
REJECTED
LINK_ISSUED
RECORDED_OFFLINE
MANDATE_ACTIVE
PAID
RECEIPT_CONFIRMED
EXPIRED
FAILED
RECEIPTED
MANDATE_CANCELLED

Only valid transitions should be permitted.

Do not allow arbitrary status changes from the API.

==================================================
ONLINE PAYMENT
==================================================

After approval:

1. Generate secure payment token/link
2. Link is tied to exactly one approved request
3. Link is single-use
4. Link has configurable expiry
5. Proposed default is 72 hours
6. Donor is redirected to hosted gateway checkout
7. Gateway sends webhook
8. Verify webhook signature
9. Process event idempotently
10. Update payment
11. Generate receipt
12. Send communication

NEVER store card/payment credentials.

Payment processing must be idempotent.

Duplicate gateway events must never create duplicate:

- Donations
- Payments
- Receipts

Use unique constraints and idempotency mechanisms.

==================================================
PAYMENT ADAPTER
==================================================

Create:

IPaymentGateway

Example implementation:

RazorpayPaymentGateway

Methods should cover:

- Create payment link
- Get payment status
- Verify webhook
- Process payment event
- Create recurring mandate where supported
- Cancel mandate where supported

Business logic must depend on the interface, not Razorpay.

==================================================
OFFLINE DONATIONS
==================================================

Admin can create donation requests for:

- Walk-in donors
- Phone donors
- Cheque donors
- Bank transfer donors
- Cash
- DD

Flow:

Admin creates request
→ Verification according to approved policy
→ Approval
→ Physical collection OR payment link

For physical collection:

Record:

- Collection mode
- Reference
- Date
- Amount
- Notes

Finance confirms receipt/deposit.

Only after finance confirmation should the receipt be generated.

Offline-origin online payments must remain identifiable.

==================================================
RECURRING DONATIONS
==================================================

Support monthly donations where the selected gateway supports them.

Flow:

Donor selects monthly
→ Verification
→ Approval
→ Mandate authorization
→ Mandate active
→ Monthly debit
→ Donation transaction
→ Receipt

The initial mandate requires approval.

Subsequent debits do NOT require another approval or OTP.

Track:

- Mandate ID
- Donor
- Amount
- Start date
- Status
- Gateway reference
- Last successful debit
- Next debit
- Failed debit
- Cancellation

==================================================
RECEIPTS
==================================================

Generate PDF donation receipts after:

1. Successful online payment confirmation
OR
2. Finance-confirmed offline receipt

Receipt number must be:

- Sequential
- Unique
- Never reused

Receipt content must be configurable according to Prerna/CA-approved format.

IMPORTANT:

The immediate donation receipt is NOT Form 10BE.

The system does NOT generate Form 10BE.

Prerna/CA supplies Form 10BE certificates.

The system only:

- Uploads certificates
- Maps certificates to donors
- Dispatches certificates
- Flags unmatched certificates

==================================================
COMMUNICATION SYSTEM
==================================================

Create communication abstraction:

IEmailProvider
ISmsProvider
IWhatsAppProvider

Support:

Email
SMS
WhatsApp

WhatsApp MUST only be sent when the donor has explicitly opted in.

Create configurable templates.

Potential events:

- Donation request received
- New request notification to Prerna
- Donation approved
- Payment link issued
- Donation rejected
- Payment successful
- Receipt generated
- Mandate confirmed
- Recurring donation
- Form 10BE dispatch

Do not implement marketing campaigns or newsletters.

==================================================
BACKGROUND JOBS
==================================================

Use Celery + Redis.

Create jobs for:

- Email sending
- SMS sending
- WhatsApp sending
- Receipt generation
- Payment processing
- Recurring payment processing
- Certificate dispatch
- Report generation
- Gateway reconciliation
- Retry failed communications

All jobs should support:

- Retry
- Idempotency
- Logging
- Failure tracking

==================================================
DONOR MANAGEMENT
==================================================

Donor profile:

- Name
- Email
- Mobile
- Address
- Masked identification
- Communication preferences
- WhatsApp opt-in
- Donation history
- Request history
- Receipts
- Mandates

Support returning donor recognition.

Do NOT implement a full CRM.

Do NOT implement:

- Lead pipelines
- Sales pipelines
- Marketing campaigns
- Complex donor segmentation
- CRM relationship management
- Donor self-service accounts

unless explicitly added later.

==================================================
ADMIN DASHBOARD
==================================================

Create:

Dashboard
Donation Requests
Approval Queue
Donors
Donations
Payments
Mandates
Offline Donations
Receipts
Communications
Reports
Reconciliation
CMS
Settings
Admin Users

Dashboard should show:

- Total donation requests
- Pending approvals
- Approved requests
- Rejected requests
- Successful donations
- Monthly donations
- Failed payments
- Pending reconciliation
- Programme totals

Use charts only where they improve understanding.

==================================================
REPORTS
==================================================

Implement:

1. Donation Register
2. Pending Approvals
3. Programme Summary
4. Donor History Statement
5. Recurring Mandates Register
6. CSR Contribution Report
7. Reconciliation Exceptions
8. Form 10BD Supporting Export
9. Form 10BE Dispatch

Exports:

CSV
XLSX

Reports must support appropriate filtering:

- Date
- Programme
- Donation mode
- Status
- Donor
- Origin
- Frequency

==================================================
GATEWAY RECONCILIATION
==================================================

Import or retrieve gateway transactions/settlements.

Compare:

Application records
vs
Gateway records

Identify:

- Matched
- Missing in application
- Missing in gateway
- Amount mismatch
- Status mismatch
- Settlement mismatch

Do not automatically overwrite financial records during reconciliation.

Allow Admin/Finance to review and resolve exceptions.

==================================================
CONFIGURATION
==================================================

Create a database-backed configuration system.

Values must be changeable without code deployment where required.

Examples:

- Payment link validity
- Approval review target
- OTP expiry
- OTP retry limit
- Receipt numbering format
- Minimum monthly donation
- Communication templates
- Rejection message
- Programme settings
- Gateway settings
- Provider settings

Secrets must NOT be stored as normal editable CMS settings.

Secrets belong in environment variables/secrets manager.

==================================================
DATABASE
==================================================

Create PostgreSQL schema with migrations.

Core tables should include:

admin_users
admin_sessions
donors
donor_identifiers
donor_preferences
programmes
cms_pages
cms_page_versions
cms_media
cms_news
cms_stories
cms_leadership
cms_impact_figures
cms_documents
donation_requests
donation_request_programmes
verification_records
approval_actions
payment_links
payments
payment_events
mandates
mandate_transactions
offline_donations
receipts
receipt_sequences
communication_events
communication_templates
gateway_transactions
gateway_settlements
reconciliation_exceptions
form_10bd_exports
form_10be_certificates
configuration_settings
workflow_events

Use:

- UUIDs where appropriate
- Foreign keys
- Unique constraints
- Check constraints
- Indexes
- Created/updated timestamps
- Soft delete where appropriate

==================================================
AUDIT / WORKFLOW HISTORY
==================================================

Implement an internal workflow history:

workflow_events

Store:

- Entity
- Entity ID
- Event
- Previous status
- New status
- Performed by
- Timestamp
- Metadata

Example:

SUBMITTED
VERIFIED
PENDING_APPROVAL
APPROVED
LINK_ISSUED
PAID
RECEIPTED

This must make donation lifecycle troubleshooting easy.

==================================================
SECURITY
==================================================

Implement:

- HTTPS
- Secure authentication
- Secure password hashing
- HttpOnly cookies where applicable
- CSRF protection where applicable
- Rate limiting
- API validation
- SQL injection protection
- XSS protection
- CORS restrictions
- Security headers
- Secure file upload validation
- File type validation
- File size limits
- Sensitive-data masking
- Encryption for sensitive data where required
- Secrets outside source code
- Payment webhook verification
- Secure payment tokens
- Single-use payment links
- Authorization checks

Never log:

- Passwords
- OTPs
- Card data
- Payment credentials
- Full sensitive identifiers

==================================================
API DESIGN
==================================================

Use versioned REST APIs:

/api/v1/auth

/api/v1/programmes

/api/v1/cms

/api/v1/donors

/api/v1/donation-requests

/api/v1/verifications

/api/v1/approvals

/api/v1/payments

/api/v1/mandates

/api/v1/offline-donations

/api/v1/receipts

/api/v1/communications

/api/v1/reports

/api/v1/reconciliation

/api/v1/settings

/api/v1/admin-users

/api/v1/webhooks/payment

/api/v1/webhooks/recurring

Generate OpenAPI documentation.

==================================================
FRONTEND ARCHITECTURE
==================================================

Use feature-based organization.

Example:

src/
  app/
  features/
    website/
    donation/
    authentication/
    admin/
    approvals/
    donors/
    payments/
    mandates/
    receipts/
    reports/
    reconciliation/
    cms/
    settings/
  components/
  lib/
  hooks/
  services/
  types/

Do not create giant components.

Use reusable UI components.

Keep API calls in service/query layers.

Use proper loading, empty, error and success states.

==================================================
BACKEND ARCHITECTURE
==================================================

Use:

app/
  api/
  core/
  domain/
  application/
  infrastructure/
  integrations/
  models/
  repositories/
  services/
  workers/
  schemas/
  tests/

Keep:

API layer
→ Application service
→ Domain logic
→ Repository/infrastructure

Separate provider integrations from core business logic.

==================================================
TESTING
==================================================

Implement:

Unit tests
Integration tests
API tests
Database tests
Provider adapter tests
Webhook tests
Idempotency tests
Security tests
E2E tests

Use:

Pytest
Playwright

Critical scenarios:

1. New one-time donation
2. OTP failure
3. PAN verification failure
4. Approval
5. Rejection
6. Expired payment link
7. Failed payment
8. Successful payment
9. Duplicate payment webhook
10. Offline donation
11. Finance confirmation
12. Monthly mandate
13. Recurring debit
14. Failed recurring debit
15. Returning donor
16. Receipt generation
17. Form 10BE dispatch
18. Gateway reconciliation

==================================================
SEO / PERFORMANCE
==================================================

Public website must have:

- SSR/SSG where appropriate
- Optimized images
- Lazy loading
- Metadata
- Sitemap
- robots.txt
- Canonical URLs
- Open Graph
- Mobile-first responsive design

Avoid unnecessary JavaScript on public content pages.

==================================================
DEVOPS
==================================================

Create:

Dockerfiles
docker-compose.yml
Environment configuration
Database migration process
CI pipeline
CD pipeline

Environments:

Development
Staging
Production

Never commit:

.env
API keys
Gateway secrets
Database passwords
JWT secrets
Provider credentials

==================================================
DOCUMENTATION
==================================================

Create:

README.md
Architecture document
Database ERD
API documentation
Environment setup guide
Deployment guide
Integration guide
Security guide
Testing guide
Admin user guide
CMS user guide
Troubleshooting guide

==================================================
IMPLEMENTATION PROCESS
==================================================

DO NOT immediately generate the entire application.

First perform analysis.

STEP 1:
Read both project documents completely.

STEP 2:
Create a requirements traceability matrix.

Columns:

Requirement ID
Requirement
Source
Priority
Module
Acceptance Criteria
Implementation Status
Test Status

STEP 3:
Identify every open decision.

Create:

OPEN_DECISIONS.md

Do not invent answers for unresolved business decisions.

STEP 4:
Create:

ARCHITECTURE.md

Include:

- System architecture
- Module architecture
- Integration architecture
- Security architecture
- Deployment architecture

STEP 5:
Create database ERD.

STEP 6:
Create API specification.

STEP 7:
Create UI sitemap and screen list.

STEP 8:
Create implementation backlog.

Group into:

EPIC
→ FEATURE
→ STORY
→ TASK
→ ACCEPTANCE CRITERIA

STEP 9:
Create the repository structure.

STEP 10:
Implement incrementally.

After each feature:

1. Code
2. Unit tests
3. Integration tests
4. Update documentation
5. Update traceability matrix

==================================================
14-WEEK TARGET
==================================================

Week 1-2:
Requirements
Architecture
UX/UI
Database design
API design

Week 3:
Infrastructure
Authentication
Database
CMS foundation

Week 4-6:
Public website
CMS
Content management

Week 7:
Donation form
OTP
Verification

Week 8:
Approval workflow

Week 9:
Payment gateway
Payment links
Webhooks
Receipts

Week 10:
Offline donations
Donor records

Week 11:
Recurring donations
Communication system

Week 12:
Reports
10BD support
10BE dispatch
Reconciliation

Week 13:
Integration testing
UAT
Bug fixing

Week 14:
Training
Documentation
Production deployment

==================================================
IMPORTANT DEVELOPMENT RULES
==================================================

1. Never invent a business rule.
2. Never bypass the approval workflow.
3. Never store card/payment credentials.
4. Never process payment before approval.
5. Never automatically split an amount between programmes.
6. Never send WhatsApp without explicit opt-in.
7. Never generate Form 10BE.
8. Never silently change financial records during reconciliation.
9. Never hard-code third-party providers into business logic.
10. Never commit secrets.
11. Never mark a feature complete without tests.
12. Never ignore an unresolved requirement.
13. Keep the system modular and maintainable.
14. Do not over-engineer with unnecessary microservices.
15. Prefer a modular monolith for the initial implementation.

==================================================
FIRST TASK
==================================================

DO NOT START CODING YET.

First produce:

1. Executive Project Summary
2. Complete Requirement Traceability Matrix
3. Open Decisions List
4. Proposed Architecture
5. Technology Stack
6. Module Breakdown
7. Database ERD
8. API Route Map
9. Frontend Route Map
10. Admin Screen List
11. Integration Architecture
12. Security Architecture
13. 14-Week Development Plan
14. Sprint Backlog
15. Repository Structure
16. Testing Strategy
17. Deployment Architecture

Then wait for approval before beginning implementation.