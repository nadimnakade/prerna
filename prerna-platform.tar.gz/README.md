# Prerna Platform

Prerna is a local-first, production-shaped donor-management platform:

- WordPress public website and CMS
- React operational admin application
- React donation journey
- FastAPI application interface and Celery worker
- PostgreSQL transactional database
- Redis queue/coordination store
- S3-compatible document storage (SeaweedFS locally)
- MariaDB for WordPress content only

The approved architecture is documented in [`docs/superpowers/specs/2026-10-11-production-platform-design.md`](docs/superpowers/specs/2026-10-11-production-platform-design.md). Delivery status lives under [`.scratch/prerna-production-platform/`](.scratch/prerna-production-platform/).

## Prerequisites

- Docker Desktop with the Linux container engine running
- Node.js 24 and Python 3.12 for development outside containers
- These development host entries, added once with administrator rights:

```text
127.0.0.1 www.prerna.local
127.0.0.1 donate.prerna.local
127.0.0.1 admin.prerna.local
127.0.0.1 api.prerna.local
```

## Start the complete local stack

From a clean checkout:

```powershell
Copy-Item .env.example .env
docker compose up --build -d
```

Then open:

- WordPress: `http://www.prerna.local:8088`
- Donation journey: `http://donate.prerna.local:8088`
- Admin application: `http://admin.prerna.local:8088`
- API readiness: `http://api.prerna.local:8088/health/ready`

The development admin account is `admin@prerna.org` / `PrernaDemo!2026`. It is seeded only in development and test environments.

Inspect health with `docker compose ps` and stop without deleting data with `docker compose down`. Named volumes preserve PostgreSQL, MariaDB, Redis, WordPress, and object-storage data across restarts.

The PostgreSQL baseline includes donors, protected identifiers, addresses, preferences, programmes,
verification attempts, approval history, payment links, payments, offline collections, mandates, receipts,
communications, reconciliation, exports, and certificate dispatches. Financial state changes are action-based:
no payment link, offline confirmation, or mandate activation is valid before approval.

PAN and similar identifiers are encrypted separately from their deterministic matching digest, and only a
masked value is intended for display. Set unique `IDENTIFIER_ENCRYPTION_KEY` and `IDENTIFIER_MATCHING_KEY`
values in every non-local environment; production mode rejects the local defaults.

## Development without containers

```powershell
.\.venv\Scripts\python.exe -m uvicorn prerna_api.main:app --app-dir apps/api/src --reload --port 8000
npm run dev:admin
npm run dev:donation
```

The admin Vite server proxies `/api` to port 8000. Donation submission is scheduled for delivery ticket 05 and is not represented as complete.

## Verification

```powershell
.\.venv\Scripts\python.exe -m ruff check apps/api
.\.venv\Scripts\python.exe -m pytest -q
npm audit
npm run typecheck:web
npm run lint:web
npm run test:web
npm run build:web
docker compose config --quiet
```

## Provider and deployment status

Razorpay is the selected payment gateway, but its live credentials and merchant capabilities are not configured yet. OTP, identity verification, email, SMS, and WhatsApp vendors remain parked behind provider interfaces. Cloud hosting, public DNS, and TLS are also parked while delivery remains local.

Never treat simulated providers as a live production launch. Ticket 12 requires explicit activation checks for every required external provider.
