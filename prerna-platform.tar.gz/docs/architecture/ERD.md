# Prerna Platform — Database ERD

**Source table list:** requirement.md §DATABASE (35 tables) — used verbatim.
**Engine:** PostgreSQL 16 · two schemas: `cms`, `donations`
**Migrations:** Alembic

---

## 0. Modelling note (read first)

`requirement.md` lists no `donations` table. To honour the supplied list exactly:

- **`donation_requests`** = donor *intent* + lifecycle state.
- **`payments`** = every money-movement record, and **the donation register source** (`payments WHERE status = 'succeeded'`).
- **`offline_donations`** = physical-collection detail for Option A.

A failed attempt then a successful retry = two `payments` rows on one request; the receipt keys to the succeeded row. Recurring: one `donation_requests` (the mandate request) → N `payments` (one per debit).

This is a data-modelling decision, **not** a business rule. Flag if it should be otherwise.

---

## 1. Relational map

```mermaid
erDiagram
    admin_users ||--o{ admin_sessions : "logs in"
    admin_users ||--o{ approval_actions : decides
    admin_users ||--o{ offline_donations : records
    admin_users ||--o{ configuration_settings : edits

    donors ||--o{ donor_identifiers : has
    donors ||--o{ donor_preferences : has
    donors ||--o{ donation_requests : submits
    donors ||--o{ receipts : receives

    programmes ||--o{ donation_request_programmes : "intent only"
    donation_requests ||--o{ donation_request_programmes : has
    donation_requests ||--o{ verification_records : has
    donation_requests ||--o{ approval_actions : has
    donation_requests ||--|| payment_links : "single-use"
    donation_requests ||--o{ payments : money movements
    donation_requests ||--o| offline_donations : "Option A"
    donation_requests ||--o{ workflow_events : lifecycle

    payment_links ||--o{ payment_events : "gateway events"
    payments ||--o{ payment_events : "gateway events"
    payments ||--o| receipts : "unique"
    mandates ||--o{ payments : "recurring debits"
    mandates ||--o{ mandate_transactions : debits
    donation_requests ||--o| mandates : "monthly only"

    gateway_transactions ||--o{ reconciliation_exceptions : "mismatch"
    payments ||--o{ reconciliation_exceptions : "mismatch"
    gateway_settlements ||--o{ reconciliation_exceptions : "mismatch"

    receipts ||--o{ communication_events : dispatched via
    communication_templates ||--o{ communication_events : renders
    form_10be_certificates ||--o{ communication_events : dispatched via
    form_10bd_exports ||--o{ form_10be_certificates : maps to

    cms_pages ||--o{ cms_page_versions : history
    cms_media ||--o{ cms_documents : "uploads"
```

---

## 2. Schema `donations`

### 2.1 Access

**`admin_users`**
| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| email | CITEXT UNIQUE | login identity |
| password_hash | TEXT | **argon2id** — never a reversible hash |
| full_name | TEXT | |
| is_active | BOOLEAN | `ADM-04` deactivate, never delete |
| last_login_at | TIMESTAMPTZ NULL | |
| created_at / updated_at | TIMESTAMPTZ | |

**`admin_sessions`**
| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| admin_user_id | UUID FK → admin_users | ON DELETE CASCADE |
| token_hash | TEXT UNIQUE | SHA-256 of cookie token; raw token never stored |
| created_at | TIMESTAMPTZ | |
| expires_at | TIMESTAMPTZ | absolute expiry |
| last_seen_at | TIMESTAMPTZ | idle expiry base |
| revoked_at | TIMESTAMPTZ NULL | |

### 2.2 Donors

**`donors`**
| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| full_name | TEXT | |
| email | CITEXT NULL | |
| mobile | VARCHAR(15) | E.164; returning-donor match key |
| donor_type | ENUM(`individual`,`corporate`) | CSR report grouping (`RPT-06`) |
| address_line1 / line2 / city / state / pincode | TEXT | field list provisional — open decision 3 |
| is_returning | BOOLEAN DEFAULT false | denormalised for queue badge (`APR-02`) |
| first_seen_at / last_seen_at | TIMESTAMPTZ | |
| created_at / updated_at | | |
| deleted_at | TIMESTAMPTZ NULL | soft delete |

**`donor_identifiers`**
| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| donor_id | UUID FK → donors | |
| kind | ENUM(`pan`,`other`) | **no Aadhaar — BRL-17** |
| value_encrypted | BYTEA | AES-GCM, app-level key from env |
| value_hash | TEXT | HMAC for equality match without decrypting |
| value_masked | VARCHAR(20) | e.g. `ABCDE*****1234` — only value ever rendered |
| verified_at | TIMESTAMPTZ NULL | |
| created_at / updated_at | | |

**`donor_preferences`**
| Column | Type | Notes |
|---|---|---|
| donor_id | UUID PK/FK → donors | |
| email_enabled | BOOLEAN DEFAULT true | |
| sms_enabled | BOOLEAN DEFAULT true | |
| whatsapp_opt_in | BOOLEAN DEFAULT **false** | **BRL-11 — never default true, never pre-ticked** |
| whatsapp_opt_in_at | TIMESTAMPTZ NULL | consent evidence |
| updated_at | TIMESTAMPTZ | |

### 2.3 Request lifecycle

**`donation_requests`** — the central entity
| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| reference | VARCHAR(20) UNIQUE | human-readable, e.g. `PRN-2026-000123` |
| donor_id | UUID FK → donors | |
| origin | ENUM(`online`,`offline`) | **BRL-16 — offline-origin must stay identifiable** |
| channel | ENUM(`web`,`walk_in`,`phone`,`cheque`,`bank_transfer`) | |
| frequency | ENUM(`one_time`,`monthly`) | `REQ-02` |
| amount_inr | NUMERIC(12,2) CHECK > 0 | never split — `BRL-09` |
| purpose | TEXT NULL | optional message `REQ-04` |
| status | ENUM — **14 values** | CHECK constrained |
| status_reason | TEXT NULL | internal only; **never exposed to donor** (`BRL-06`) |
| submitted_at | TIMESTAMPTZ | |
| verified_at | TIMESTAMPTZ NULL | |
| pending_approval_at | TIMESTAMPTZ NULL | ageing base (`APR-04`) |
| decided_at | TIMESTAMPTZ NULL | |
| decided_by | UUID FK → admin_users NULL | `APR-09` |
| waiting_seconds | INT NULL | cached ageing snapshot |
| verification_failure_policy | TEXT NULL | effective value of open decision 6 |
| created_at / updated_at | | |
| deleted_at | TIMESTAMPTZ NULL | |

*Status CHECK:* `submitted, verified, pending_approval, approved, rejected, link_issued, recorded_offline, mandate_active, paid, receipt_confirmed, expired, failed, receipted, mandate_cancelled`

**`donation_request_programmes`** — intent only, **no amount column, ever**
| Column | Type | Notes |
|---|---|---|
| donation_request_id | UUID FK → donation_requests | PK part |
| programme_id | UUID FK → `cms.programmes` | cross-schema FK |
| | | PK (`donation_request_id`,`programme_id`) |

**`verification_records`**
| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| donation_request_id | UUID FK | |
| kind | ENUM(`otp`,`identity`) | |
| provider | TEXT | adapter name used |
| provider_ref | TEXT NULL | challenge/verification id |
| outcome | ENUM(`pending`,`passed`,`failed`,`error`) | |
| failure_code | TEXT NULL | shown to approver, not donor |
| attempted_at | INT DEFAULT 0 | retry counter vs `otp_retry_limit` |
| expires_at | TIMESTAMPTZ NULL | `otp_expiry` |
| created_at / updated_at | | |

**`approval_actions`**
| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| donation_request_id | UUID FK | |
| decision | ENUM(`approved`,`rejected`) | |
| admin_user_id | UUID FK → admin_users | `APR-09` |
| internal_note | TEXT NULL | never surfaced to donor |
| created_at | TIMESTAMPTZ | |

### 2.4 Payment

**`payment_links`**
| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| donation_request_id | UUID FK **UNIQUE** | one link per request |
| token_hash | TEXT UNIQUE | SHA-256 — **raw token never stored** |
| gateway_link_ref | TEXT NULL | provider reference |
| issued_by | UUID FK → admin_users NULL | system-initiated → NULL |
| expires_at | TIMESTAMPTZ | `payment_link_validity` (default 72h) |
| used_at | TIMESTAMPTZ NULL | single-use: consumption is `UPDATE … WHERE used_at IS NULL AND expires_at > now()` |
| created_at | | |

**`payments`** — money movement; **donation register source**
| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| donation_request_id | UUID FK | |
| mandate_id | UUID FK → mandates NULL | set for recurring debits |
| payment_link_id | UUID FK → payment_links NULL | |
| origin | ENUM(`online`,`offline`) | `BRL-16` |
| mode | ENUM(`upi`,`card`,`netbanking`,`cash`,`cheque`,`dd`,`bank_transfer`) | |
| amount_inr | NUMERIC(12,2) | |
| status | ENUM(`created`,`processing`,`succeeded`,`failed`,`refunded`) | |
| gateway | TEXT | adapter name |
| gateway_payment_id | TEXT NULL | |
| failure_code / failure_message | TEXT NULL | |
| occurred_at | TIMESTAMPTZ | |
| created_at / updated_at | | |

**`payment_events`** — webhook idempotency ledger
| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| gateway | TEXT | |
| event_id | TEXT | **UNIQUE (`gateway`,`event_id`) — insert-first, conflict = already processed** |
| event_type | TEXT | |
| signature_valid | BOOLEAN | |
| raw_payload | JSONB | |
| processing_status | ENUM(`received`,`processing`,`processed`,`failed`) | |
| received_at / processed_at | TIMESTAMPTZ | |

**`offline_donations`**
| Column | Type | Notes |
|---|---|---|
| donation_request_id | UUID PK/FK | |
| mode | ENUM(`cash`,`cheque`,`dd`,`bank_transfer`) | `OFF-03` |
| reference | TEXT NULL | cheque/DD number, UTR |
| collected_at | TIMESTAMPTZ | |
| collected_by | UUID FK → admin_users | |
| notes | TEXT NULL | |
| finance_confirmed_by | UUID FK → admin_users NULL | **`OFF-04` / `BRL-13` — receipt blocked until set** |
| finance_confirmed_at | TIMESTAMPTZ NULL | |
| created_at / updated_at | | |

**`mandates`**
| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| donation_request_id | UUID FK UNIQUE | mandate approved once — `BRL-08` |
| donor_id | UUID FK | |
| amount_inr | NUMERIC(12,2) | |
| frequency | TEXT DEFAULT `monthly` | |
| status | ENUM(`pending_authorization`,`active`,`paused`,`cancelled`,`failed`) | |
| gateway_mandate_ref | TEXT NULL | |
| start_date | DATE | |
| last_successful_debit_at | TIMESTAMPTZ NULL | |
| next_debit_due | DATE NULL | |
| consecutive_failures | INT DEFAULT 0 | drives open decision 2 policy |
| cancelled_at | TIMESTAMPTZ NULL | |
| created_at / updated_at | | |

**`mandate_transactions`**
| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| mandate_id | UUID FK | |
| payment_id | UUID FK → payments NULL | |
| scheduled_for | DATE | |
| attempted_at | TIMESTAMPTZ | |
| status | ENUM(`success`,`failed`,`skipped`) | |
| failure_code | TEXT NULL | |
| attempt_no | INT | vs retry policy |

**`gateway_transactions` / `gateway_settlements`** — reconciliation input
| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| gateway | TEXT | |
| external_id | TEXT UNIQUE | payment/settlement id from gateway |
| amount_inr | NUMERIC(12,2) | |
| status | TEXT | |
| settlement_reference | TEXT NULL | settlements only |
| occurred_at | TIMESTAMPTZ | |
| payload | JSONB | |
| imported_at | TIMESTAMPTZ | |

### 2.5 Receipt and tax

**`receipts`**
| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| receipt_number | TEXT **UNIQUE** | `BRL-14` — sequential, unique, never reused |
| payment_id | UUID FK → payments **UNIQUE** | exactly one receipt per succeeded payment |
| donation_request_id | UUID FK | |
| donor_id | UUID FK | |
| financial_year | TEXT | `2026-27` |
| amount_inr | NUMERIC(12,2) | |
| template_version | TEXT | open decision 4 |
| pdf_object_key | TEXT NULL | MinIO key |
| status | ENUM(`generating`,`generated`,`dispatched`,`failed`,`voided`) | |
| void_reason | TEXT NULL | voided receipts keep their number forever |
| generated_at / dispatched_at | TIMESTAMPTZ | |
| created_at / updated_at | | |

**`receipt_sequences`**
| Column | Type | Notes |
|---|---|---|
| financial_year | TEXT PK | |
| next_value | BIGINT | **allocated under `SELECT … FOR UPDATE`** — serial, race-free |
| format | TEXT | `PRN/{FY}/{SEQ:06d}` — configurable (open decision 4) |
| updated_at | TIMESTAMPTZ | |

**`form_10bd_exports`**
| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| financial_year | TEXT | |
| generated_by | UUID FK → admin_users | |
| row_count | INT | |
| object_key | TEXT | CSV/XLSX in MinIO |
| created_at | | |

**`form_10be_certificates`** — **ingested only; never generated (BRL-10)**
| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| donor_id | UUID FK NULL | NULL = unmatched |
| financial_year | TEXT | |
| pan_masked | TEXT | mapping key |
| object_key | TEXT | uploaded PDF |
| mapping_status | ENUM(`matched`,`unmatched`) | **`RPT-09` — unmatched flagged for manual handling** |
| dispatched_at | TIMESTAMPTZ NULL | |
| uploaded_by | UUID FK → admin_users | |
| created_at | | |

### 2.6 Communications, config, audit-as-workflow

**`communication_templates`**
| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| event_key | TEXT UNIQUE | `approved_with_link`, etc. |
| channel | ENUM(`email`,`sms`,`whatsapp`) | |
| subject | TEXT NULL | |
| body | TEXT | `{{placeholders}}` |
| is_active | BOOLEAN | |
| channels_enabled | TEXT[] | per-event channel map — open decision 5 |
| updated_at | | |

**`communication_events`**
| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| event_key | TEXT | |
| channel | ENUM | |
| recipient_ref | TEXT | masked in logs |
| template_id | UUID FK NULL | |
| status | ENUM(`pending`,`sent`,`failed`,`skipped_consent`) | `skipped_consent` = WhatsApp without opt-in |
| attempt_count | INT | |
| error | TEXT NULL | |
| dedupe_key | TEXT UNIQUE | `event:entity:channel` — prevents duplicate sends |
| created_at / sent_at | | |

**`configuration_settings`**
| Column | Type | Notes |
|---|---|---|
| key | TEXT PK | e.g. `payment_link.validity_hours` |
| value | JSONB | |
| value_type | ENUM(`int`,`bool`,`string`,`json`,`enum`) | |
| group | TEXT | `payment`, `otp`, `receipt`, `comms`, `programme`, `provider` |
| description | TEXT | admin UI help text |
| is_secret | BOOLEAN | **always false here — secrets live in env only** |
| decision_ref | TEXT NULL | `open_decision_1` … `9` |
| decision_status | ENUM(`decided`,`pending_prerna`) | |
| updated_by | UUID FK → admin_users | |
| updated_at | | |

**`workflow_events`** — *workflow data, not an audit log (OPEN_DECISIONS #14)*
| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| entity_type | TEXT | `donation_request`, `payment`, `receipt`, `mandate` |
| entity_id | UUID | |
| event | TEXT | `status_changed`, `approved`, `link_issued`… |
| previous_status | TEXT NULL | |
| new_status | TEXT NULL | |
| performed_by | UUID FK → admin_users NULL | system → NULL |
| metadata | JSONB | |
| created_at | TIMESTAMPTZ | **indexed on (`entity_type`,`entity_id`,`created_at`)** |

### 2.7 Reconciliation

**`reconciliation_exceptions`**
| Column | Type | Notes |
|---|---|---|
| id | UUID PK | |
| kind | ENUM(`missing_in_application`,`missing_in_gateway`,`amount_mismatch`,`status_mismatch`,`settlement_mismatch`) | |
| payment_id | UUID FK NULL | |
| gateway_transaction_id | UUID FK NULL | |
| settlement_id | UUID FK NULL | |
| expected_amount / actual_amount | NUMERIC(12,2) NULL | |
| status | ENUM(`open`,`resolved`,`ignored`) | |
| resolution_note | TEXT NULL | |
| resolved_by | UUID FK → admin_users NULL | |
| created_at / updated_at | | |

**Never auto-writes to `payments`** — comparison is read-only; only Admin/Finance resolves (requirement.md §GATEWAY RECONCILIATION).

---

## 3. Schema `cms`

**`programmes`**
| Column | Type | Notes |
|---|---|---|
| id | UUID PK | referenced cross-schema by donations |
| name | TEXT | Education / Healthcare / Sports |
| slug | TEXT UNIQUE | |
| description | TEXT | |
| content | JSONB | structured blocks — no raw HTML blobs |
| impact_info | JSONB | |
| cover_image_media_id | UUID FK → cms_media NULL | |
| status | ENUM(`draft`,`published`,`unpublished`) | |
| sort_order | INT | |
| is_active | BOOLEAN | `'Any'` pseudo-programme is a config entry, not a row |
| created_at / updated_at / deleted_at | | |

**`cms_pages`** — slug, title, template, content JSONB, seo_title, seo_description, og_image_media_id, status, published_at, updated_by
**`cms_page_versions`** — page_id, version_no, content JSONB, snapshot_at, author — enables preview + rollback
**`cms_media`** — id, filename, mime_type, byte_size, object_key, alt_text, width/height, uploaded_by, created_at
**`cms_news`** / **`cms_stories`** — slug, title, excerpt, body JSONB, cover_media_id, status, published_at, seo_*
**`cms_leadership`** — full_name, role, bio, photo_media_id, sort_order, status
**`cms_impact_figures`** — label, value, suffix, description, sort_order, status
**`cms_documents`** — title, category (`annual_report`,`audited_financials`,`fund_utilisation`), fiscal_year, media_id, status — drives `WEB-05` downloads

---

## 4. Constraint summary (the ones that carry business rules)

| Constraint | Rule protected |
|---|---|
| `donation_requests.status` CHECK ∈ 14 values | state machine integrity |
| `donation_request_programmes` has **no amount column** | BRL-09 never split |
| no `aadhaar` value in `donor_identifiers.kind` | BRL-17 |
| `payment_links.token_hash` UNIQUE + `used_at` guard | BRL-05 single-use, unguessable |
| `payment_events(gateway, event_id)` UNIQUE | PAY-03 idempotency |
| `receipts.payment_id` UNIQUE | one receipt per payment |
| `receipts.receipt_number` UNIQUE | BRL-14 never reused |
| `receipt_sequences` row lock | BRL-14 concurrent allocation |
| `communication_events.dedupe_key` UNIQUE | no duplicate sends |
| `mandates.donation_request_id` UNIQUE | BRL-08 one mandate per request |
| FK `receipts.donor_id` NOT NULL | receipts always attributable |
| `offline_donations.finance_confirmed_at` gates receipt | BRL-13 |
| `form_10be_certificates` has no generator path | BRL-10 |
| `reconciliation_exceptions` never cascades to `payments` | never silently overwrite financial records |

**Conventions:** UUID PKs everywhere · `created_at`/`updated_at` on all tables · soft delete (`deleted_at`) on CMS + donors only — **financial rows are never deleted** · FKs are `ON DELETE RESTRICT` for financial tables · indexes on `donation_requests(status, pending_approval_at)`, `donation_requests(origin, created_at)`, `payments(status, occurred_at)`, `workflow_events(entity_type, entity_id, created_at)`.
