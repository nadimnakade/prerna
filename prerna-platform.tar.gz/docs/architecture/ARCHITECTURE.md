# Prerna Platform — Architecture

**Documents:** BRD v1.1 · Scope of Work v2.0 · requirement.md
**Status:** Draft for approval (Gate 1 input — D1)
**Date:** 2026-09-26

---

## 1. System Architecture

Modular monolith. One FastAPI application, one PostgreSQL database with two schemas, one Celery worker codebase, one Next.js application.

```
                         ┌──────────────────────────────────────┐
   Public donor ───────► │  apps/web  (Next.js 15, App Router)  │
                         │   ├─ app/(public)  SSG / ISR         │
                         │   └─ app/(admin)   SSR + cookie      │
                         └───────────────┬──────────────────────┘
                                         │ REST /api/v1  (session cookie | public)
                         ┌───────────────▼──────────────────────┐
                         │  apps/api  (FastAPI, Python 3.12)    │
                         │   api/  →  application/  →  domain/  │
                         │                  │                   │
                         │        repositories/  services/      │
                         │                  │                   │
                         │       infrastructure/ integrations/  │
                         └───┬──────────┬───────────┬───────────┘
                             │          │           │
                     ┌───────▼──┐ ┌─────▼─────┐ ┌───▼─────────────────┐
                     │ Postgres │ │ Redis     │ │ Provider ports      │
                     │ 16       │ │ broker +  │ │  IPaymentGateway    │
                     │ schemas: │ │ rate limit│ │  IOtpProvider       │
                     │  cms     │ └─────┬─────┘ │  IIdentityVerif.    │
                     │  donations│      │       │  IEmail/Sms/WhatsApp│
                     └───────▲──┘ ┌─────▼─────┐ │  IObjectStorage     │
                             │    │ Celery    │ │  IReceiptRenderer   │
                             │    │ worker +  │ └───┬─────────────────┘
                             │    │ beat      │     │
                     ┌───────┴────┴───────────┴─┐   │
                     │  MinIO (S3-compatible)   │   │
                     │  documents · receipt PDFs│   │
                     └──────────────────────────┘   │
                                                    ▼
                              Gateway · OTP/SMS · Identity · Email · WhatsApp BSP
                              (simulated mode by default — Integration Test Harness)
```

### Invariants encoded in architecture

| Rule | Where enforced |
|---|---|
| BRL-01 no payment without approval | State machine transition table — `APPROVED` is the only predecessor of `LINK_ISSUED` / `RECORDED_OFFLINE` / `MANDATE_ACTIVE` |
| BRL-12 hosted checkout, no card data | `IPaymentGateway` surface has no card-accepting method; no column stores PAN-adjacent payment credentials |
| BRL-09 never split an amount | `donation_request_programmes` is a pure intent join; no amount column |
| BRL-11 WhatsApp opt-in | `IWhatsAppProvider` adapter refuses send unless `donor_preferences.whatsapp_opt_in = true`; hard check in adapter, not caller |
| BRL-10 never generate Form 10BE | No code path renders 10BE; `form_10be_certificates` only ingests Prerna-supplied files |
| Providers not hard-coded | Business code depends on `integrations/ports/*` only; selection by `PROVIDER_*_MODE` env |

---

## 2. Module Architecture

### 2.1 Backend — `apps/api`

```
app/
├── api/             HTTP routers, dependency injection, schema binding
├── core/            settings, security primitives, errors, logging, deps
├── domain/          state machine, BRL invariants, entities, value objects
├── services/        domain services (receipt numbering, ageing, reconciliation match)
├── application/     use cases — the only transaction boundary
├── models/          SQLAlchemy ORM tables
├── repositories/    persistence interfaces + SQLAlchemy implementations
├── infrastructure/  DB session, S3/MinIO client, crypto, config store
├── integrations/    ports + adapters (all third-party)
├── schemas/         Pydantic request/response/DTO
├── workers/         Celery tasks — thin, idempotent, call application use cases
└── tests/
```

**Dependency direction (lint-enforced, one-way):**

```
api ──► application ──► domain
              │            ▲
              ├─► services ─┘
              ├─► repositories ──► models
              └─► integrations/ports  (interfaces only)
                        ▲
              infrastructure ──────────┘
```

Prohibited imports:
- `domain/`, `services/` → anything (no I/O at all)
- `domain/`, `application/` → `integrations/*_adapter` concrete modules (ports only)
- any module → `api/`

Boundary enforcement is an import-linter contract in CI. This keeps the modular monolith splittable without it being a goal.

### 2.2 Module boundaries

| Module | Owns | Public interface |
|---|---|---|
| `donations` | request lifecycle, state machine, verification, approvals | `create_request`, `verify`, `approve`, `reject` |
| `payments` | links, gateway events, mandate lifecycle, offline collection | `issue_link`, `consume_link`, `process_payment_event`, `confirm_finance` |
| `receipts` | numbering, PDF render, dispatch | `issue_receipt(donation_id)` |
| `communications` | templates, event dispatch, channel routing | `send(event, recipient, context)` |
| `cms` | pages, media, news, stories, leadership, impact, documents | CRUD + publish/unpublish + revalidate |
| `donors` | profiles, identifiers, preferences, returning-donor match | `match_returning(mobile\|email)` |
| `reports` | the 9 reports, CSV/XLSX export | `render(report_id, filters)` |
| `reconciliation` | gateway import, exception detection, resolution | `import_batch`, `compare`, `resolve` |
| `admin` | auth, sessions, admin users, configuration settings | `authenticate`, `get_setting` |

Each module is a package with its own `services.py` / `use_cases.py` / `repository.py`. Cross-module calls go through the owning module's application-layer functions, never its tables directly.

### 2.3 Frontend — `apps/web`

```
src/
├── app/
│   ├── (public)/      SSG/ISR — 11 website sections + /donate + status tracker
│   └── (admin)/       SSR — session cookie, middleware guard
├── features/          website, donation, authentication, admin, approvals,
│                      donors, payments, mandates, receipts, reports,
│                      reconciliation, cms, settings
├── components/        shared UI (shadcn/ui + Prerna design system)
├── services/          generated API client from OpenAPI
├── hooks/ lib/ types/
```

Rules:
- All API calls live in `features/*/services/` → TanStack Query hooks.
- No business logic in components. **No financial logic anywhere in the frontend** — the form collects and validates, the server decides.
- Zod schemas are generated from the FastAPI Pydantic models, so client/server validation cannot drift.

---

## 3. Integration Architecture

### 3.1 Ports

```python
class IOtpProvider(Protocol):
    async def send(self, mobile: str, template: str) -> OtpChallenge: ...
    async def verify(self, challenge_id: str, code: str) -> OtpResult: ...

class IIdentityVerificationProvider(Protocol):
    async def verify_identifier(self, kind: IdentifierKind, value: str) -> VerificationOutcome: ...

class IPaymentGateway(Protocol):
    async def create_payment_link(self, req: LinkRequest) -> GatewayLink: ...
    async def get_payment_status(self, gateway_ref: str) -> GatewayStatus: ...
    def verify_webhook(self, payload: bytes, signature: str) -> GatewayEvent: ...
    async def process_payment_event(self, event: GatewayEvent) -> ProcessedEvent: ...
    async def create_recurring_mandate(self, req: MandateRequest) -> GatewayMandate: ...
    async def cancel_mandate(self, mandate_ref: str) -> None: ...

class IEmailProvider / ISmsProvider / IWhatsAppProvider(Protocol): ...
class IObjectStorage(Protocol): put, get, presign
class IReceiptRenderer(Protocol): render(receipt: ReceiptData) -> bytes
```

Every port has a `simulated` adapter and (later) a `live` adapter, selected by:

```
PROVIDER_PAYMENT_MODE=simulated|live
PROVIDER_OTP_MODE=...
PROVIDER_IDENTITY_MODE=...
PROVIDER_EMAIL_MODE=...   PROVIDER_SMS_MODE=...   PROVIDER_WHATSAPP_MODE=...
```

### 3.2 Integration Test Harness (SOW 7.1)

The simulated adapters are the **default** and the **contract-test reference**. A shared contract suite runs against both simulated and live adapters; a live adapter passes D6 only when it passes the identical suite. Construction never blocks on provider onboarding (SOW 12.3).

Simulator behaviour is deterministic and configurable per test:
- OTP: accepts a configured success code, rejects otherwise, honours expiry and retry limits.
- Identity: returns pass/fail/offline by identifier pattern.
- Gateway: produces signed webhook fixtures for capture, failure, refund, and duplicate delivery.

### 3.3 Webhook pipeline

```
POST /api/v1/webhooks/payment/{gateway}
  1. verify HMAC signature on raw bytes        → fail: 401, log, stop
  2. parse event id + type
  3. INSERT payment_events (gateway, event_id) → unique violation: return 200 (already seen)
  4. enqueue celery task process_payment_event:<event_id>
  5. return 200 fast
```

Async, replay-safe, signature-first. Ordering is handled by idempotent re-reads: each processing task re-reads current state and applies only transitions still valid.

### 3.4 Communication dispatch

```
domain event ─► communication_events (row, status=pending)
                     │
                     ▼ celery send_communication:<event_id>
              template render (communication_templates)
                     │
        ┌────────────┼──────────────┐
   IEmailProvider  ISmsProvider  IWhatsAppProvider
                     │
        WhatsApp only if donor_preferences.whatsapp_opt_in  (BRL-11, enforced in adapter)
```

Events: `request_received`, `new_request_alert_to_prerna`, `approved_with_link`, `rejected`, `payment_confirmed_with_receipt`, `mandate_confirmed`, `recurring_debit_receipt`, `form_10be_dispatch`. Final list is configurable (open decision 5).

---

## 4. Security Architecture

### 4.1 Authentication and sessions

- Single admin access level (RBAC contractually excluded — BRD §10).
- Login → `admin_sessions` row (random 256-bit token, SHA-256 stored, hashed password via **argon2id**) → `HttpOnly; Secure; SameSite=Lax` cookie.
- Idle expiry and absolute expiry, both configurable. Rotation on login. Revocation = delete session row.
- Public donor paths are anonymous; no donor accounts exist (donor self-service is out of scope).

### 4.2 Defence table

| Control | Implementation |
|---|---|
| HTTPS | TLS terminated at reverse proxy (staging/production); Compose is bound to localhost |
| CSRF | `SameSite=Lax` + Origin/Referer check on every mutating admin request |
| Rate limiting | Redis token bucket on `otp/request`, `otp/verify`, `auth/login`, public `POST /donation-requests` |
| Input validation | Pydantic strict on every endpoint; Zod mirrored client-side |
| SQL injection | SQLAlchemy ORM only; parameterised; no string-built SQL |
| XSS | React escaping + server-side allowlist sanitiser on CMS rich text + CSP |
| CORS | Explicit origin allowlist, `credentials: true`, no wildcard |
| Security headers | HSTS, CSP, `X-Content-Type-Options: nosniff`, `frame-ancestors 'none'`, `Referrer-Policy`, `Permissions-Policy` |
| Uploads | Extension + magic-byte MIME check, size cap, stored in MinIO outside webroot, served via signed URL as `attachment` |
| Identifier protection | AES-GCM at rest, `value_masked` for display, API never returns full value |
| Secrets | Environment only; `.env.example` committed, `.env` gitignored; never in `configuration_settings` |
| Payment tokens | 256-bit random; SHA-256 hash persisted, raw token never stored; single-use, time-bound |
| Webhook integrity | HMAC verified on raw body before parse |
| Log hygiene | Handler-level redaction filter for password, OTP, card, PAN, full identifier |
| Authorization | Every `/admin` route requires a valid session; public/admin split enforced in `api/` dependencies |

### 4.3 Data sensitivity

- PAN/identifiers: encrypted at rest, masked on screen (SOW 7.2).
- No card or payment credentials stored anywhere (BRL-12).
- Financial rows are never deleted or overwritten silently; corrections append with a `workflow_events` trail.

---

## 5. Deployment Architecture

### 5.1 Environments

| Env | Purpose | Provider mode |
|---|---|---|
| Development | local, `docker compose up` | all `simulated` |
| Staging | Prerna review + UAT | gateway test mode / simulated |
| Production | Prerna's hosting account | live providers |

### 5.2 Compose services (development reference)

| Service | Image | Notes |
|---|---|---|
| `db` | `postgres:16` | schemas `cms`, `donations`; volume-persisted |
| `redis` | `redis:7` | Celery broker/result, rate-limit counters |
| `api` | `python:3.12-slim` | uvicorn, hot reload via volume mount |
| `worker` | same image | Celery worker |
| `beat` | same image | link-expiry sweep, recurring debits, reconciliation, retry |
| `web` | `node:22-alpine` | Next.js dev, hot reload |
| `minio` | `minio/minio` | S3-compatible document/PDF store |

Pinned to **Python 3.12** in container — host Python is 3.14, where Pydantic/SQLAlchemy/Celery wheel availability is not guaranteed.

### 5.3 Migration and release

- Alembic migrations run as a discrete `api migrate` step before app start — never auto-migrate on boot in production.
- Backward-compatible migrations only (expand → migrate → contract) so web and API can roll independently.
- CI: lint → typecheck → pytest → Playwright → build images.
- CD: staging auto on merge to `main`; production manual trigger gated on Gate 4.

### 5.4 Explicitly not built

Per BRD §10 / SOW §8: RBAC, audit logging, backup/DR/HA/RPO/RTO, SOC/SIEM, VAPT, PCI-DSS, CRM, bank-statement reconciliation, accounting/ERP integration, donor portal, native apps, multilingual, newsletters, foreign currency, Aadhaar, complex priority engine, data migration, Form 10BD filing, Form 10BE generation.

If good practice incidentally produces something resembling the above, it is flagged here so it is never presented as delivered scope.
