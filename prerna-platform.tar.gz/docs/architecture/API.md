# Prerna Platform — API Route Map

**Base:** `/api/v1` · REST · JSON · OpenAPI auto-generated at `/api/v1/openapi.json`
**Types:** generated into `packages/shared` (Zod + TS) — no hand-written clients.

---

## 1. Conventions

| Concern | Rule |
|---|---|
| Versioning | URL path `/api/v1`. Breaking change → `/api/v2`, both served during one release |
| Auth (admin) | `HttpOnly; Secure; SameSite=Lax` session cookie + Origin check on mutations |
| Auth (public) | anonymous; rate-limited; returns non-sensitive data only |
| Webhooks | HMAC signature on raw body, **no session**, signature verified before parse |
| Errors | `application/problem+json` — `{type, title, status, detail, correlationId, errors?[]}` |
| Success | `200` / `201` + resource; `204` for void actions |
| Pagination | `?page=1&page_size=25` → `{items, page, page_size, total}` |
| Sorting/filtering | `?sort=waiting_time.desc&status=&programme=&date_from=&date_to=&origin=&frequency=&search=` |
| Rate limits | `otp/request`, `otp/verify`, `auth/login`, public `POST /donation-requests` — Redis token bucket; `429` + `Retry-After` |
| Action verbs | **No endpoint accepts a raw `status` value.** Only state-machine actions exist |

---

## 2. Public endpoints

### 2.1 Content

| Method | Path | Notes |
|---|---|---|
| GET | `/programmes` | published only |
| GET | `/programmes/{slug}` | includes `donate_url` with pre-selected programme |
| GET | `/cms/pages/{slug}` | published only; cached, ISR-revalidated |
| GET | `/cms/news` · `/cms/news/{slug}` | paginated |
| GET | `/cms/stories` · `/cms/stories/{slug}` | paginated |
| GET | `/cms/leadership` | board + team |
| GET | `/cms/impact-figures` | home page figures |
| GET | `/cms/documents?category=` | annual reports, audited financials, fund utilisation |
| GET | `/cms/contact` | contact + grievance details |

### 2.2 Donation request

| Method | Path | Notes |
|---|---|---|
| POST | `/donation-requests` | creates `SUBMITTED`. Rate-limited. Returns `reference` |
| GET | `/donation-requests/track/{reference}` | status + next-step copy + masked amount. **No login. No PII beyond what donor supplied** |
| POST | `/donation-requests/lookup` | `{mobile or email}` → returning-donor detection (VER-04) |

**POST `/donation-requests` body**
```jsonc
{
  "programmes": ["education", "sports"],   // or ["any"] — intent only, amount never split (BRL-09)
  "frequency": "one_time",                 // one_time | monthly
  "amount_inr": 5000,
  "purpose": "optional message",
  "donor": {
    "full_name": "", "email": "", "mobile": "",
    "identifier": {"kind": "pan", "value": ""},
    "address": {"line1":"","line2":"","city":"","state":"","pincode":""},
    "donor_type": "individual"
  },
  "preferences": {
    "email_enabled": true, "sms_enabled": true,
    "whatsapp_opt_in": false               // default false, never pre-ticked (BRL-11)
  }
}
```

### 2.3 Verification

| Method | Path | Notes |
|---|---|---|
| POST | `/verifications/otp/request` | `{reference}` → issues challenge. Rate-limited; honours `otp_length`, `otp_expiry`, `otp_retry_limit` |
| POST | `/verifications/otp/verify` | `{reference, code}` → transition `SUBMITTED → VERIFIED` |
| POST | `/verifications/identity` | runs `IIdentityVerificationProvider` on stored identifier |
| GET | `/verifications/{donation_request_id}` | verification outcomes visible to approver (VER-02) |

Identity-failure behaviour is the value of **open decision 6** — endpoint response reflects the configured policy, never a hard-coded branch.

### 2.4 Payment link (donor side)

| Method | Path | Notes |
|---|---|---|
| GET | `/payments/link/{token}` | resolves token → request summary + checkout handoff. `410 Gone` if expired or used (BRL-05) |
| POST | `/payments/link/{token}/consume` | atomic single-use claim: `UPDATE … WHERE used_at IS NULL AND expires_at > now()`; zero rows → `410` |

### 2.5 Webhooks

| Method | Path | Notes |
|---|---|---|
| POST | `/webhooks/payment/{gateway}` | verify → insert `payment_events` (unique) → enqueue → `200`. Duplicate → `200`, no side effects |
| POST | `/webhooks/recurring/{gateway}` | mandate authorized / debit success / debit failure / mandate cancelled |

---

## 3. Admin endpoints — auth

| Method | Path | Notes |
|---|---|---|
| POST | `/auth/login` | argon2id verify → session row → cookie. Rate-limited |
| POST | `/auth/logout` | revokes session row |
| GET | `/auth/me` | current admin user |

Single access level — **no role parameter exists anywhere in the API** (RBAC excluded).

---

## 4. Admin endpoints — approval (core)

| Method | Path | Body |
|---|---|---|
| GET | `/donation-requests` | filters: status, programme, origin, frequency, returning, date range, search |
| GET | `/donation-requests/{id}` | donor (masked), verifications, programmes, amount, frequency, returning flag, waiting time, 48h target, workflow history |
| POST | `/approvals/{id}/approve` | `{internal_note?}` → `PENDING_APPROVAL → APPROVED`, then auto-issue link or await mandate auth |
| POST | `/approvals/{id}/reject` | `{internal_note?}` → `REJECTED`; enqueues **standard configured rejection message** (BRL-06); **no reason returned to donor** |
| POST | `/approvals/{id}/note` | attach internal note without decision |

`GET /donation-requests` returns `waiting_hours` + `review_target_hours` + `breaching` boolean (APR-04).

---

## 5. Admin endpoints — payments, offline, mandates

| Method | Path | Notes |
|---|---|---|
| POST | `/payments/{request_id}/issue-link` | mints token (hash stored), sets `LINK_ISSUED`, enqueues delivery |
| POST | `/payments/{request_id}/revoke-link` | within validity |
| GET | `/payments?status=&origin=` | payment status of every approved request (PAY-05) |
| POST | `/offline-donations` | staff-created request — same fields as online (OFF-01) |
| POST | `/offline-donations/{id}/record-collection` | `{mode, reference, collected_at, notes}` → `RECORDED_OFFLINE` (OFF-03) |
| POST | `/offline-donations/{id}/confirm-finance` | **gates receipt generation** (OFF-04 / BRL-13) → `RECEIPT_CONFIRMED` |
| POST | `/offline-donations/{id}/issue-link` | Option B — rejoins online flow |
| GET | `/mandates?status=` | active / cancelled / failed register |
| POST | `/mandates/{id}/cancel` | gateway cancel where supported (REC-07) |
| POST | `/mandates/{id}/pause` · `/resume` | drives open-decision-2 failed-debit policy |

---

## 6. Admin endpoints — donors, receipts, communications

| Method | Path | Notes |
|---|---|---|
| GET | `/donors?search=` | search by name / mobile / masked identifier |
| GET | `/donors/{id}` | profile, **masked identifier only**, preferences, full history (DON-01/02) |
| PATCH | `/donors/{id}/preferences` | staff updates opt-in at donor's request (COM-06) |
| GET | `/receipts?date_from=&programme=&status=` | |
| GET | `/receipts/{id}/download` | presigned MinIO URL |
| POST | `/receipts/{id}/reissue` | re-dispatch, same number (never reused) |
| GET | `/communications/events?status=` | pending/failed sends |
| POST | `/communications/templates/{id}` | edit template + per-event channel map (open decision 5) |
| POST | `/communications/retry/{event_id}` | manual retry |

---

## 7. Admin endpoints — reports and reconciliation

All support `?format=csv|xlsx` and filters `date_from, date_to, programme, mode, status, origin, frequency, donor`.

| Method | Path | Report |
|---|---|---|
| GET | `/reports/donation-register` | RPT-01 |
| GET | `/reports/pending-approvals` | RPT-02 |
| GET | `/reports/programme-summary` | RPT-03 |
| GET | `/reports/donor-history/{donor_id}` | RPT-04 |
| GET | `/reports/mandates-register` | RPT-05 |
| GET | `/reports/csr-contributions` | RPT-06 |
| GET | `/reports/reconciliation-exceptions` | RPT-07 |
| GET | `/reports/form-10bd-export?financial_year=` | RPT-08 — export only, **never files** |
| GET | `/reports/form-10be-dispatch?financial_year=` | RPT-09 — dispatch status + unmatched list |
| POST | `/reports/{report_id}/export` | async → Celery → MinIO → download link |

**Reconciliation**

| Method | Path | Notes |
|---|---|---|
| POST | `/reconciliation/import` | upload gateway transaction/settlement CSV or trigger API pull |
| GET | `/reconciliation/runs` | past comparisons |
| GET | `/reconciliation/exceptions?kind=&status=` | 5 exception kinds |
| POST | `/reconciliation/exceptions/{id}/resolve` | `{resolution_note}` — **comparison never auto-writes `payments`** |
| POST | `/reconciliation/exceptions/{id}/ignore` | with note |

**Form 10BE certificate ingestion**

| Method | Path | Notes |
|---|---|---|
| POST | `/form-10be/certificates` | upload PDFs + mapping file (CSV or naming convention) |
| GET | `/form-10be/certificates?status=unmatched` | flagged for manual handling |
| POST | `/form-10be/certificates/{id}/remap` | manual donor assignment |
| POST | `/form-10be/certificates/{id}/dispatch` | email + WhatsApp-if-opted-in |

---

## 8. Admin endpoints — CMS, settings, users

| Method | Path | Notes |
|---|---|---|
| GET/POST/PATCH/DELETE | `/cms/pages` `/cms/pages/{id}` | draft / publish / unpublish / delete |
| POST | `/cms/pages/{id}/publish` | bumps `cms_page_versions`, triggers ISR revalidation |
| GET | `/cms/pages/{id}/preview?version=` | preview before publish |
| CRUD | `/cms/programmes` `/cms/news` `/cms/stories` `/cms/leadership` `/cms/impact-figures` `/cms/documents` `/cms/media` `/cms/legal` `/cms/contact` `/cms/csr` | same draft/publish lifecycle |
| POST | `/cms/media` | upload — MIME + magic-byte check, size cap, MinIO |
| GET | `/settings?group=` | non-secret settings only (`is_secret=false` enforced) |
| PATCH | `/settings/{key}` | validates `value_type`; records `updated_by`; **not a Change (SOW 13.3)** |
| POST | `/settings/{key}/decision` | marks an open decision `decided` |
| GET/POST | `/admin-users` | create (`ADM-04`) |
| PATCH | `/admin-users/{id}/deactivate` | **deactivate, never delete** |

---

## 9. Dashboard

| Method | Path | Returns |
|---|---|---|
| GET | `/dashboard/summary` | total requests, pending approvals (with ageing), approved, rejected, successful donations, monthly donations, failed payments, pending reconciliation, programme totals — ADM-02 |

Charts only where they aid comprehension (requirement.md §ADMIN DASHBOARD).

---

## 10. State-machine action surface (complete)

These are the **only** ways status changes:

| Action | Endpoint | Transition |
|---|---|---|
| submit | `POST /donation-requests` | → `SUBMITTED` |
| verify OTP | `POST /verifications/otp/verify` | `SUBMITTED → VERIFIED` |
| auto | (application layer) | `VERIFIED → PENDING_APPROVAL` |
| approve | `POST /approvals/{id}/approve` | `PENDING_APPROVAL → APPROVED` |
| reject | `POST /approvals/{id}/reject` | `PENDING_APPROVAL → REJECTED` |
| issue link | `POST /payments/{id}/issue-link` | `APPROVED → LINK_ISSUED` |
| authorize mandate | webhook `/webhooks/recurring/*` | `APPROVED → MANDATE_ACTIVE` |
| record collection | `POST /offline-donations/{id}/record-collection` | `APPROVED → RECORDED_OFFLINE` |
| gateway capture | webhook `/webhooks/payment/*` | `LINK_ISSUED → PAID` |
| gateway failure | webhook `/webhooks/payment/*` | `LINK_ISSUED → FAILED` |
| retry | `POST /payments/link/{token}/consume` | `FAILED → LINK_ISSUED` |
| expire | Celery beat sweep | `LINK_ISSUED → EXPIRED` |
| finance confirm | `POST /offline-donations/{id}/confirm-finance` | `RECORDED_OFFLINE → RECEIPT_CONFIRMED` |
| receipt | Celery task | `PAID → RECEIPTED`, `RECEIPT_CONFIRMED → RECEIPTED` |
| cancel mandate | `POST /mandates/{id}/cancel` or webhook | `MANDATE_ACTIVE → MANDATE_CANCELLED` |

Any other status mutation is **not routable**. There is no `PATCH /donation-requests/{id}` with a `status` field.

---

## 11. Response envelope examples

**Success**
```json
{ "data": { "reference": "PRN-2026-000123", "status": "pending_approval",
            "next_step": "Prerna will review within 48 hours." } }
```

**Error**
```json
{ "type": "https://api.prerna.example/problems/otp-invalid",
  "title": "Invalid OTP",
  "status": 422,
  "detail": "The code you entered is incorrect.",
  "correlationId": "01J...",
  "errors": [{"field": "code", "message": "Incorrect code. 2 attempts remaining."}] }
```

**Donor-facing error copy never reveals internal reason, approver note, or verification failure detail (BRL-06).**
