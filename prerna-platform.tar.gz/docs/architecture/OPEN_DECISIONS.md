# Prerna Platform — Open Decisions

**Sources:** BRD v1.1 §12 · SOW v2.0 §17 · requirement.md §FIRST TASK
**Rule:** *Never invent a business rule. Never silently change a requirement.*

**Handling (agreed):** every decision below is stored as a database-backed value in `configuration_settings`, seeded with a **provisional default**, tagged `PENDING_PRERNA`. Code paths stay single; no decision is hard-coded. Changing a setting is not a Change (SOW 13.3).

---

## Part 1 — Business open decisions

| # | Decision | Owner | Needed before | Affects | Provisional default (reversible) | Status |
|---|---|---|---|---|---|---|
| 1 | Minimum monthly amount | Prerna | Recurring build | REC-06 | `500` INR | `PENDING_PRERNA` |
| 2 | Handling of failed monthly debits, incl. pause rule | Prerna | Recurring build | REC-05 | retry next cycle ×3, then `MANDATE_ACTIVE → paused` + admin alert; no automatic cancellation | `PENDING_PRERNA` |
| 3 | Final donor field list, incl. Form 10BD fields | Prerna + CA | Gate 1 | REQ-03, RPT-08 | name, email, mobile, PAN, address (line1, line2, city, state, pincode), donor type (individual/corporate); **no Aadhaar** (BRL-17) | `PENDING_PRERNA` |
| 4 | Receipt content, format, numbering | Prerna + CA | Gate 1 | COM-01, COM-02 | configurable HTML template + `PRN/<FY>/<6-digit seq>`; sequential, unique, never reused (BRL-14) | `PENDING_PRERNA` |
| 5 | Message events and channels | Prerna | Gate 1 | COM-04, APR-07 | 8 events as listed in ARCHITECTURE §3.4; email always, SMS on OTP/link/receipt, WhatsApp only on opt-in (BRL-11) | `PENDING_PRERNA` |
| 6 | What happens when identity verification fails | Prerna | Gate 1 | VER-03 | `stay_submitted` — request remains retryable, approver sees failure reason | `PENDING_PRERNA` |
| 7 | How returning donors are prioritised | Prerna | Gate 1 | APR-08 | queue default sort: `waiting_time desc`; returning-donor badge shown, no automatic reordering | `PENDING_PRERNA` |
| 8 | Whether to launch the website early | Prerna | Gate 2 | WEB-14 | build both; donate action shows holding message if donation module disabled by setting | `PENDING_PRERNA` |
| 9 | Provider selection: gateway, SMS/OTP, verification, WhatsApp BSP, hosting | Prerna (Kavach advises) | Stage 2 | PAY, VER, COM | all adapters in `simulated` mode; `PROVIDER_*_MODE` switches per provider independently | `PENDING_PRERNA` |

### Design posture on each

- **1, 2** — both are settings; the failed-debit policy is a config enum, not a code branch, so Prerna's answer is a value change.
- **3** — donor field list is a config-driven schema section; adding a CA-required field later is a migration + setting, not a redesign. Address/PAN are already captured because receipting and 10BD need them.
- **4** — receipt is rendered from a stored template, so content/format changes need no deploy. Numbering format is a setting; the *uniqueness* guarantee is a constraint and is not configurable.
- **5** — event→channel mapping is a config table; WhatsApp is gated by consent regardless of mapping.
- **6** — policy enum; three behaviours implemented, one selected.
- **7** — sort preference setting; ageing always displayed either way (APR-04 is `Must`).
- **8** — build flag; no branch in the donation code path.
- **9** — mode flag per provider; already isolated behind ports.

**No decision above blocks Increment 1.** Decisions 3 and 4 block Gate 1 sign-off and must be answered before D1 is formally accepted.

---

## Part 2 — Document and interpretation questions

These are *not* business decisions. They are inconsistencies or gaps found while reading the source documents. Per BRD §1.3: *"raise it as a question in your response. Do not resolve it by assumption."* Interim readings below are stated explicitly so they can be overturned cheaply.

| # | Question | Source | Impact | Interim reading used in this design | Status |
|---|---|---|---|---|---|
| 10 | **SOW version conflict.** BRD v1.1 states "Scope of Work **v2.1** governs scope"; the supplied document is **v2.0** (filename and cover page). | BRD §1.3 vs SOW §1 | Precedence — a v2.1 delta could change scope | Treat supplied **v2.0** as governing; flag for confirmation | **OPEN — needs confirmation** |
| 11 | **Proposal not supplied.** Both BRD and SOW cite *Proposal Final, 16 September 2026* as the top-precedence document. It is not in the project folder. | BRD §1.3, SOW §1.1 | Highest-precedence scope source is unavailable | Design against BRD + SOW + requirement.md only | **OPEN — needs document** |
| 12 | **Companion document missing.** BRD references *Technical Approach Brief v1.1*. | BRD §1.1 | May constrain the technical approach we are proposing | Not applied | **OPEN — needs document** |
| 13 | `requirement.md` prescribes the technology stack. BRD §1.1 says the stack is explicitly ours to propose. | requirement.md vs BRD §1.1 | Stack freedom | **requirement.md wins** — it is a direct instruction from the requester, and BRD is silent rather than contradictory | Resolved |
| 14 | `requirement.md` lists `workflow_events` capturing full lifecycle transitions. BRD §10 excludes audit logging; APR-09 covers only "who decided, and when". | requirement.md vs BRD §10 | Scope boundary | `workflow_events` scoped as **workflow data, not an audit log** — status transitions and decisions only, no field-level change history, no login/access log | Resolved (flagged) |
| 15 | State naming: `requirement.md` orders states so that online payments appear to pass through `RECEIPT_CONFIRMED`. BRD §4.4 defines "Paid / Receipt confirmed" as one meaning: money confirmed *either* by gateway *or* by finance. | requirement.md vs BRD §4.4 | State semantics | `PAID` = gateway-confirmed; `RECEIPT_CONFIRMED` = finance-confirmed (offline Option A only); both → `RECEIPTED` | **OPEN — confirm reading** |
| 16 | Website section count: `requirement.md` enumerates 13 items; SOW §4 specifies **11 sections** (programme pages grouped as one item). | requirement.md vs SOW §4 | Acceptance criterion D4 says "all 11 sections" | **11 sections per SOW**, with Education/Healthcare/Sports as three pages under section 4 | Resolved |
| 17 | `requirement.md` mentions `IReceiptRenderer` is not listed among required providers; receipt rendering is nonetheless needed. | requirement.md §PAYMENT ADAPTER | Port inventory | Added `IReceiptRenderer` and `IObjectStorage` as internal ports — **flagged as incidental good practice**, not committed scope | Flagged |
| 18 | Verification failure for **staff-assisted (offline)** requests follows "Prerna's policy" (VER-05) — policy not yet supplied. | BRD VER-05, SOW §5.5 | Offline flow | Provisional: same OTP + identity flow as online; configurable per-origin override ready | **OPEN — needs policy** |

---

## Part 3 — Dependencies owned by others (not decisions)

Recorded so they are never mistaken for blocked work. Per SOW 12.3, construction proceeds against the Integration Test Harness regardless.

| Dependency | Needed for | Owner |
|---|---|---|
| Gateway merchant onboarding + KYC | Live payments, Gate 3 | Prerna |
| Gateway recurring/mandate enablement | Live monthly giving | Prerna + gateway |
| OTP/SMS account, DLT sender + template registration | Live OTP and SMS | Prerna |
| Identity verification provider account | Live verification | Prerna |
| WhatsApp Business account, BSP, template approval | Live WhatsApp | Prerna, Meta, BSP |
| Email sending service + domain config | Transactional email | Prerna (Kavach configures) |
| Hosting and domain | Staging and production | Prerna |
| CA confirmation: receipt format, field list, 10BD format | Receipts and reports | Prerna + CA |
| Content, branding, legal text, disclosures | Website | Prerna |

---

## Change log

| Date | Change |
|---|---|
| 2026-09-26 | Initial: 9 BRD/SOW decisions seeded, 9 interpretation questions raised |
