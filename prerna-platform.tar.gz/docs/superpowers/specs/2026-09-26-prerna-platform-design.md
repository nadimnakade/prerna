# Prerna Platform — Design Specification

**Date:** 2026-09-26
**Inputs:** `requirement.md` · BRD v1.1 · Scope of Work v2.0 · `docs/architecture/{ARCHITECTURE,OPEN_DECISIONS,ERD,API}.md`
**Status:** Approved design (Sections A–D) — pending written-spec review

---

## 1. Purpose

A digital platform for Prerna (Section 8 company; Education, Healthcare, Sports) comprising a public website with a custom CMS, and a basic donor management application where **every donation request is approved before any payment can be taken**.

Success criteria (BRD §2.4):
1. Staff update the website, publish stories and upload reports with no developer.
2. Donors complete a donation request comfortably on a phone.
3. Approvers see every pending request and how long it has waited.
4. Every completed donation produces a receipt automatically.
5. The CA obtains annual Form 10BD data without manual collation.
6. Finance sees where platform records and gateway data disagree.

---

## 2. Non-goals

Contractually excluded (BRD §10, SOW §8): RBAC · audit logging · backup/DR/HA/RPO/RTO · SOC/SIEM/VAPT/PCI-DSS · full CRM · bank-statement reconciliation · accounting/ERP integration · donor self-service accounts · native apps · multilingual · newsletters/marketing · foreign currency · Aadhaar collection · complex priority engine · data migration · Form 10BD filing · Form 10BE generation · expenditure-utilisation reporting · content writing/photography · load testing.

Incidental good practice that resembles the above is flagged so it is never presented as delivered scope.

---

## 3. Architecture (Section A)

**Modular monolith.** One FastAPI app (Python 3.12), one PostgreSQL 16 with two schemas (`cms`, `donations`), one Celery codebase (`worker` + `beat`), one Next.js 15 app with route groups `(public)` / `(admin)`, MinIO for S3-compatible storage.

Two schemas satisfy SOW 7.1 — CMS content structurally separate from donation data — without a second database.

### 3.1 Backend layers

```
api/ → application/ → domain/            (no I/O below this line)
           ├→ services/
           ├→ repositories/ → models/
           └→ integrations/ports ← infrastructure/
```

`api` binds HTTP, `application` owns the transaction boundary, `domain` holds the state machine and BRL invariants as pure code, `services` holds cross-entity domain logic (receipt numbering, ageing, reconciliation matching), `integrations` isolates every third-party behind a port. Import direction is lint-enforced in CI.

### 3.2 Module inventory

`donations` · `payments` · `receipts` · `communications` · `cms` · `donors` · `reports` · `reconciliation` · `admin`.

Each is a package with its own services/use-cases/repository. Cross-module calls go through the owning module's application layer, never its tables directly.

### 3.3 Provider ports

`IOtpProvider` · `IIdentityVerificationProvider` · `IPaymentGateway` · `IEmailProvider` · `ISmsProvider` · `IWhatsAppProvider` · `IObjectStorage` · `IReceiptRenderer`.

Every port ships a **simulated** adapter as default (the Integration Test Harness of SOW 7.1) and a **live** adapter later, selected by `PROVIDER_*_MODE`. A shared contract suite runs against both; a live adapter passes D6 only by passing the identical suite. Construction never blocks on provider onboarding (SOW 12.3).

### 3.4 Frontend rules

- API calls only in `features/*/services/` → TanStack Query hooks.
- **No business logic in components. No financial logic in the frontend.**
- Zod schemas generated from Pydantic — client/server validation cannot drift.
- Public pages SSG/ISR, revalidated on CMS publish; `/donate` and `/admin` dynamic.

---

## 4. Domain (Section B)

### 4.1 State machine

14 states. Transition table is **data**, covered by an exhaustive 14×14 test. Terminal states: `REJECTED`, `EXPIRED`, `RECEIPTED`, `MANDATE_CANCELLED`.

| From | To | Trigger | Actor |
|---|---|---|---|
| `SUBMITTED` | `VERIFIED` | OTP + identity pass | system |
| `VERIFIED` | `PENDING_APPROVAL` | automatic | system |
| `PENDING_APPROVAL` | `APPROVED` | approve | admin |
| `PENDING_APPROVAL` | `REJECTED` | reject | admin |
| `APPROVED` | `LINK_ISSUED` | link issued (one-time / offline Option B) | system |
| `APPROVED` | `MANDATE_ACTIVE` | mandate authorized | donor + gateway |
| `APPROVED` | `RECORDED_OFFLINE` | record collection (Option A) | admin |
| `LINK_ISSUED` | `PAID` | verified capture webhook | gateway → system |
| `LINK_ISSUED` | `FAILED` | gateway failure | gateway → system |
| `LINK_ISSUED` | `EXPIRED` | past validity | worker |
| `FAILED` | `LINK_ISSUED` | retry while valid | donor |
| `RECORDED_OFFLINE` | `RECEIPT_CONFIRMED` | finance confirms | admin |
| `PAID` | `RECEIPTED` | receipt generated + dispatched | worker |
| `RECEIPT_CONFIRMED` | `RECEIPTED` | receipt generated + dispatched | worker |
| `MANDATE_ACTIVE` | `MANDATE_CANCELLED` | cancel | admin / gateway / donor |

**BRL-01 is structural:** no transition reaches `PAID` or `RECORDED_OFFLINE` without passing `APPROVED`. Enforcing it is a property of the table, not a code review habit.

API exposes **actions only** — `verify`, `approve`, `reject`, `issue-link`, `record-collection`, `confirm-finance`, `cancel-mandate`. There is no status setter endpoint.

### 4.2 Status semantics

- `PAID` = money confirmed **by gateway**.
- `RECEIPT_CONFIRMED` = money confirmed **by Prerna finance** (offline Option A only).
- `RECEIPTED` = receipt generated **and dispatched**; dispatch failure leaves status untouched while `communication_events` records and retries it.

### 4.3 Data model

35 tables per requirement.md's list, in two schemas. Full column detail in `ERD.md`. Highlights:

- `donation_request_programmes` carries **no amount column** (BRL-09).
- `donor_identifiers.kind` has no `aadhaar` value (BRL-17); value is AES-GCM encrypted, matched by HMAC, displayed masked.
- `payment_links.token_hash` UNIQUE + atomic `used_at IS NULL AND expires_at > now()` claim → unguessable, time-bound, single-use (BRL-05).
- `payment_events(gateway, event_id)` UNIQUE → webhook idempotency.
- `receipts.payment_id` UNIQUE and `receipts.receipt_number` UNIQUE → one receipt per payment, numbers never reused (BRL-14).
- `receipt_sequences` allocated under `SELECT … FOR UPDATE`.
- Financial rows are never deleted; corrections append with a `workflow_events` trail.
- `form_10be_certificates` is ingest-only — **no generator code path exists** (BRL-10).
- `reconciliation_exceptions` never cascades into `payments`.

### 4.4 Idempotency

Five mechanisms: webhook insert-first; receipt unique per payment; receipt number row lock; atomic link consumption; Celery dedupe key `event:entity_id` plus DB state guard before side effects.

### 4.5 Flows

**P1 online one-time** — submit → OTP → identity → `PENDING_APPROVAL` (+ confirmation to donor, alert to Prerna) → approve → link (72h) → hosted checkout → verified webhook → `PAID` → receipt → email/SMS/WhatsApp-if-opted-in → `RECEIPTED`.

**P2 offline** — admin creates request → verify per policy → approve → **Option A**: record mode/reference/date → finance confirms → receipt; **Option B**: issue link → rejoins P1. `origin` keeps offline-origin online payments identifiable (BRL-16).

**P3 monthly** — same form, `frequency=monthly` → verify → identity → approve mandate **once** → donor authorizes (UPI AutoPay/NACH) → `MANDATE_ACTIVE` → beat debits monthly → each success creates a payment + receipt + comms. **No approval, no OTP on subsequent debits** (BRL-08).

---

## 5. Integration architecture

Webhook pipeline: verify HMAC on raw bytes → insert `payment_events` (unique violation = already seen, `200`) → enqueue → return `200` fast. Processing is async, replay-safe, and re-reads state so out-of-order delivery cannot double-apply.

Communications: domain event → `communication_events` row → Celery renders `communication_templates` → channel adapter. WhatsApp adapter refuses send unless `whatsapp_opt_in = true` — consent enforced at the boundary, not in the caller.

---

## 6. API and frontend surface

Full route map in `API.md`. All routes live under `/api/v1` in two families — public content, donation, verification, payment-link and webhooks; and cookie-authenticated admin routes for auth, approvals, payments, offline, mandates, donors, receipts, communications, reports, reconciliation, 10BE ingestion, CMS, settings, admin users and dashboard.

Public website = 11 SOW sections (programme pages grouped as one section) plus `/donate` and a public status tracker. Admin = 15 screen groups. Donation form = 5 mobile-first steps ending in a confirmation that tells the donor what happens next (REQ-08).

---

## 7. Error handling

```
domain      raises InvalidTransition | InvariantViolation | LinkExpired
application maps to NotFound | Conflict | PreconditionFailed | ValidationFailed
api         maps to RFC 7807 application/problem+json + correlationId
```

5xx returns a correlation ID only — no stack traces, no provider payloads. Startup fails fast on missing required env.

**Money state and side effects are decoupled.** If a payment succeeds but PDF rendering fails, status stays `PAID`, the job retries, the failure surfaces in admin. A status is never advanced to fake success.

Celery: exponential backoff → max retries → `failed` flag + admin alert. Every task idempotent, so retry is always safe.

---

## 8. Security

| Control | Mechanism |
|---|---|
| HTTPS | TLS at reverse proxy (staging/prod); Compose localhost-only |
| Admin auth | `admin_sessions` row, argon2id, HttpOnly + Secure + SameSite=Lax cookie, idle + absolute expiry, rotation on login |
| CSRF | SameSite=Lax + Origin/Referer check on mutating admin requests |
| Rate limiting | Redis token bucket on OTP request/verify, login, public request creation |
| Validation | Pydantic strict server-side, Zod client-side |
| SQL injection | SQLAlchemy ORM only, no string-built SQL |
| XSS | React escaping + server-side allowlist sanitiser on CMS rich text + CSP |
| CORS | Explicit allowlist, `credentials: true`, no wildcard |
| Headers | HSTS, CSP, `nosniff`, `frame-ancestors 'none'`, `Referrer-Policy`, `Permissions-Policy` |
| Uploads | Extension + magic-byte MIME check, size cap, MinIO outside webroot, signed URL served as `attachment` |
| Identifiers | AES-GCM at rest, HMAC for matching, masked for display, full value never returned |
| Secrets | env only; `.env.example` committed, `.env` gitignored; never in `configuration_settings` |
| Payment tokens | 256-bit random, SHA-256 hash persisted, single-use, time-bound |
| Webhooks | HMAC verified on raw body before parse |
| Logging | handler-level redaction of password, OTP, card, PAN, full identifier |
| Authorization | every `/admin` route requires a valid session; no role concept anywhere |

---

## 9. Testing

| Layer | Tool | Focus |
|---|---|---|
| Unit | pytest | exhaustive 14×14 state matrix; all 18 BRL rules as assertions |
| Integration | pytest + real Postgres | repositories, transactions, unique constraints |
| API | httpx | status codes, problem+json, auth enforcement |
| Adapter contract | shared suite | identical run against simulated and live adapters |
| Webhook | pytest | duplicate, out-of-order, bad signature, amount mismatch |
| Idempotency | pytest + concurrency | parallel receipt numbering, parallel link consumption, replayed webhook |
| Security | pytest | route protection, masking, upload rejection, CORS, rate limits |
| E2E | Playwright | the 18 critical scenarios in requirement.md |

**CI gate:** lint → typecheck → pytest → Playwright → build. Coverage thresholds `domain/` ≥90%, `application/` ≥80% (report-only elsewhere).

The 18 critical scenarios: new one-time donation · OTP failure · PAN verification failure · approval · rejection · expired payment link · failed payment · successful payment · duplicate payment webhook · offline donation · finance confirmation · monthly mandate · recurring debit · failed recurring debit · returning donor · receipt generation · Form 10BE dispatch · gateway reconciliation.

---

## 10. Configuration

Database-backed `configuration_settings`, changeable without deployment (BRL-18). Covers: payment link validity (72h), approval review target (48h), OTP length/expiry/retry, rejection message, programme list, minimum monthly amount, failed-debit handling, channels per event, receipt template + numbering, admin alert recipients.

All nine BRD/SOW open decisions are seeded as settings tagged `PENDING_PRERNA` with reversible provisional defaults — **no decision is hard-coded** (see `OPEN_DECISIONS.md`).

Secrets are never stored as settings.

---

## 11. Delivery

**14 working weeks, five stages, four gates** (SOW §10). Construction proceeds against the Integration Test Harness regardless of provider status.

**Increment 1 — core vertical slice (in scope):**

1. Monorepo skeleton + full Compose stack
2. Alembic baseline — 19 core tables: `admin_users`, `admin_sessions`, `donors`, `donor_identifiers`, `donor_preferences`, `programmes`, `donation_requests`, `donation_request_programmes`, `verification_records`, `approval_actions`, `payment_links`, `payments`, `payment_events`, `receipts`, `receipt_sequences`, `configuration_settings`, `workflow_events`, `communication_events`, `communication_templates`
3. State machine + exhaustive transition tests
4. Configuration settings + seeded defaults for all 9 open decisions
5. Admin auth (login / logout / session)
6. Public donation form — 5 steps, mobile-first, RHF + Zod
7. Simulated OTP + identity providers, plus the shared adapter contract-test suite (runs against simulated adapters in Increment 1; live adapters are added later and must pass the same suite at Gate 3 / D6)
8. Approval queue — list, detail, ageing, approve / reject / internal note
9. Payment link → simulated hosted checkout → signed webhook → `PAID`
10. Receipt PDF (configurable template) + sequential numbering
11. Simulated email/SMS adapters + `communication_events`
12. Celery worker + beat (link-expiry sweep)
13. `workflow_events` on every transition
14. pytest suite + 3 Playwright E2E (happy path, OTP failure, duplicate webhook)

**Deferred:** 11 website sections + CMS · offline donations · recurring · reports · reconciliation · 10BD/10BE · live provider adapters · remaining 15 E2E scenarios.

---

## 12. Assumptions

- Stack fixed by `requirement.md`, overriding BRD §1.1's silence (OPEN_DECISIONS #13).
- Supplied SOW v2.0 governs pending confirmation of the BRD's v2.1 reference (#10).
- Design built against BRD + SOW + `requirement.md`; the Proposal Final document is unavailable (#11).
- INR, domestic donors, English only, early-stage NGO volumes, no HA engineering (BRD §8, SOW §12.1).
- Prerna supplies all content, branding, legal text and disclosures in final form.
