# Prerna Production Platform — Architecture Specification

**Date:** 2026-10-11

**Status:** Approved conversational design; pending written-spec review

**Supersedes:** `2026-09-26-prerna-platform-design.md` where the two documents conflict

**Inputs:** BRD v1.1, Scope of Work v2.0, `requirement.md`, and the architecture documents under `docs/architecture/`

## 1. Purpose and success criteria

Build the complete production application described by the BRD, not a prototype or an approval-only demonstration. The platform has four distinct surfaces:

1. `www.prerna.org`: the public Prerna website, implemented in WordPress.
2. `www.prerna.org/wp-admin`: the CMS used by Prerna's content team.
3. `donate.prerna.org`: a mobile-first React donation journey.
4. `admin.prerna.org`: a React operational application for Prerna staff.

`api.prerna.org` exposes the FastAPI application interface. PostgreSQL is the authoritative store for donor, donation, payment, receipt, mandate, reconciliation, and reporting data.

Success means Prerna can manage public content without a developer; donors can complete the request and payment journey on a phone; staff can operate every BRD workflow through working navigation; and every financial report is derived from persisted transactional records. Empty navigation, placeholder screens, and sample-only workflows do not count as delivery.

## 2. Confirmed decisions

- Architecture: modular monolith.
- Application backend: Python 3.12 and FastAPI.
- Operational and donation frontends: React and TypeScript.
- Public website and CMS: WordPress, with its own MariaDB database.
- Transactional database: PostgreSQL.
- Payment gateway: Razorpay.
- Initial deployment: local, production-shaped Docker Compose.
- Data migration: none; this is a new system.
- Public website, donation journey, operational admin, and application interface use separate local hostnames corresponding to their future production subdomains.
- OTP, identity verification, SMS, WhatsApp, and email vendors are parked. They use provider-neutral interfaces and simulated local adapters until Prerna selects production providers.

## 3. System architecture

### 3.1 Deployable applications

- `apps/admin-web`: React staff application with responsive sidebar navigation, masters, transactions, reports, settings, and user administration.
- `apps/donation-web`: React donation journey only. It is not a second public website.
- `apps/api`: FastAPI modular monolith containing the application rules and HTTP interfaces.
- `apps/worker`: background jobs for webhooks, receipts, exports, notifications, reconciliation, expiry, and retry processing.
- WordPress: public pages, programmes, stories, reports, media, SEO, and navigation.
- MariaDB: WordPress-owned content data only.
- PostgreSQL: application-owned donor and financial data only.
- Redis: queue transport, rate limiting, distributed locks, and short-lived verification state. It is not an authoritative business store.
- S3-compatible object storage: SeaweedFS locally for receipts, exports, reports, and Form 10BE documents. This replaces the originally selected MinIO implementation because MinIO Community Edition was archived and its public images were withdrawn; the application-facing storage interface is unchanged.
- Reverse proxy: routes the local hostnames and provides the same origin separation expected in production.

WordPress never writes to PostgreSQL. WordPress Donate actions open `donate.prerna.org` and may pass a programme slug. The application resolves that slug through Programme Master data.

### 3.2 FastAPI modules

The backend is divided into deep modules with narrow interfaces:

- access and admin users
- donors and preferences
- programmes and lookup masters
- donation requests and verification
- approvals
- payments and Razorpay integration
- offline donations
- recurring mandates and debits
- receipts and receipt numbering
- communications
- reports and exports
- reconciliation
- Form 10BD and Form 10BE support
- configuration settings

Each module owns its rules and persistence implementation. Cross-module behavior uses the owning module's interface rather than reading its tables directly. Provider adapters sit at explicit seams so a parked provider can be selected without changing workflow code.

## 4. Operational admin application

The persistent responsive sidebar contains:

- Dashboard
- Donation Requests
- Approvals
- Donors
- Donations
- Payments
- Offline Donations
- Monthly Mandates
- Receipts
- Communications
- Reports
- Reconciliation
- Form 10BD / 10BE
- Masters
- Settings
- Admin Users

Masters include Programme, Donation Mode, Communication Template, Receipt Series, Financial Year, and configurable lookup data. WordPress owns programme content; Programme Master owns the transactional identifier and WordPress slug mapping.

Donor Master provides search and filters, contact details, masked identifiers, addresses, preferences, consent, returning-donor status, and complete histories of requests, donations, payments, receipts, and mandates.

## 5. Donation and payment lifecycle

Every donation is controlled by an action-based state machine. The conceptual path is:

`SUBMITTED -> OTP_VERIFIED -> IDENTITY_VERIFIED -> PENDING_APPROVAL -> APPROVED -> PAYMENT_LINK_ISSUED / MANDATE_PENDING / OFFLINE_PENDING -> PAID -> RECEIPTED`

Rejected, expired, cancelled, and failed states are explicit. No route exposes an unrestricted status setter, and no transition can create a payment, offline financial confirmation, or mandate before approval.

### 5.1 One-time online donation

The donor arrives from WordPress, submits a request, completes configured verification, awaits approval, receives a time-limited single-use Razorpay link, completes hosted checkout, and receives a receipt after a verified payment event.

### 5.2 Offline donation

Staff create the same underlying request. After approval, they either record physical collection and finance confirmation or issue a Razorpay payment link. Origin remains visible in records and reports.

### 5.3 Monthly donation

The donor selects monthly giving and follows verification and approval once. Razorpay mandate authorization creates an active mandate. Each successful debit creates its own payment and receipt. Subsequent debits do not repeat request approval.

### 5.4 Razorpay event processing

Webhook handling verifies the signature against the raw request body, stores each provider event once, returns promptly, and processes the event asynchronously. Unique constraints and transactional state checks make duplicate, replayed, and out-of-order events safe. Provider payloads are retained in a controlled form for investigation without exposing secrets or payment credentials.

## 6. Data ownership and financial integrity

PostgreSQL records include donors, protected identifiers, addresses, preferences, programmes, requests, verification attempts, approval decisions, payment links, payments, webhook events, settlements, offline collections, mandates, recurring transactions, receipts, communication events, reconciliation runs, exceptions, tax exports, certificate dispatches, settings, users, sessions, and operational history.

Financial rows are not hard-deleted. Corrections are represented by explicit actions and history. Receipt numbers are allocated transactionally and never reused. Each payment can produce at most one receipt. Payment and webhook identifiers have provider-scoped uniqueness constraints.

PAN and similar identifiers are encrypted before persistence, separately keyed for deterministic matching, and masked in application responses. Card, bank, UPI credential, and other checkout secrets never enter the platform.

## 7. Reports

All reports support relevant filters, pagination, totals, and CSV/XLSX export:

1. Donation register by date, programme, mode, status, and origin.
2. Pending approvals with waiting time.
3. Programme summary for Education, Healthcare, Sports, and Any.
4. Donor history statement.
5. Recurring mandate register.
6. CSR contribution report by corporate donor and programme.
7. Reconciliation exceptions.
8. Form 10BD-supporting export.
9. Form 10BE dispatch and unmatched-certificate status.
10. Monthly donation summary: total amount, successful and failed collections, one-time versus recurring amounts, and programme breakdown.

Report values come from immutable payment, receipt, and mandate records rather than cached dashboard figures. Large exports run as background jobs and produce expiring object-storage downloads.

## 8. Security and operational behavior

- Admin passwords use Argon2id. Sessions are stored server-side with HttpOnly, Secure, SameSite cookies in production.
- Login throttling, session rotation and expiry, account deactivation, origin checks, strict CORS, trusted hosts, CSP, security headers, and server-side validation are mandatory.
- WordPress and application administration have separate users, credentials, databases, and authorization domains.
- Every financial mutation is transactional and records its actor and cause.
- Background jobs use bounded retries and a visible terminal failure state. Communication or PDF failure never rewrites a successful payment as failed.
- Logs use correlation identifiers and redact passwords, OTPs, PAN, raw payment links, provider secrets, and sensitive provider payloads.
- Readiness checks cover PostgreSQL, Redis, object storage, schema migrations, and worker availability.
- Docker services run as non-root where supported, use health checks, persist named volumes, and expose only necessary ports.
- Local backup and restore procedures are exercised before release. Cloud hosting, HA, and external monitoring remain future deployment decisions.

Parked providers are never represented as live in production. Production startup or release checks must clearly fail or flag unresolved required adapters rather than silently using simulated delivery.

## 9. Failure handling

Domain failures map to stable problem responses with correlation identifiers. Internal stack traces and provider secrets never reach clients.

Money state and side effects remain separate. If Razorpay confirms payment but receipt rendering or delivery fails, the payment stays successful, the failed job remains visible, and retry is safe. Reconciliation surfaces differences without mutating the source payment automatically.

All asynchronous jobs are idempotent. Dead-lettered work can be inspected and replayed after its cause is corrected.

## 10. Testing and acceptance

Each delivered module includes:

- database migrations
- FastAPI interfaces and authorization tests
- React screens with loading, empty, error, and success states
- domain unit tests
- PostgreSQL integration tests
- interface and adapter contract tests
- browser-level acceptance tests

Financial workflows additionally test concurrency, duplicate webhooks, invalid signatures, out-of-order events, retry behavior, amount mismatch, receipt-number allocation, single-use links, and recovery from partial side-effect failure.

The continuous-integration gate is lint, static typing, unit tests, PostgreSQL integration tests, frontend tests, browser tests, production builds, migration checks, and container health checks. A navigation entry counts as complete only when its end-to-end workflow persists and retrieves real PostgreSQL data.

## 11. Delivery sequence

1. Platform foundation: local domains, PostgreSQL, Redis, MinIO, WordPress, React shells, FastAPI modules, migrations, security, and CI.
2. WordPress public website and CMS with programme-to-donation links.
3. Donation journey, verification adapters, and returning-donor recognition.
4. Operational admin shell, sidebar, dashboard, masters, settings, and admin users.
5. Approval workflow and secure Razorpay payment-link flow.
6. Payments, webhooks, offline donations, receipts, and communications.
7. Donor Master and complete donor history.
8. Monthly mandates and recurring collections.
9. Reports, exports, Form 10BD/10BE support, and reconciliation.
10. Production audit, security review, backup/restore exercise, complete browser tests, and release documentation.

Delivery uses production-complete vertical modules. Temporary simulators are permitted only at declared provider seams; placeholder pages and fake financial records are not accepted as completed modules.

## 12. Explicitly parked decisions

The following require Prerna selection before production activation but do not block local construction:

- OTP provider
- identity/PAN verification provider and policy
- SMS provider
- WhatsApp provider and approved templates
- email provider and sending domain
- cloud hosting and production DNS/TLS
- provider credentials and merchant onboarding details

Razorpay is selected, but live recurring capabilities still depend on the features enabled for Prerna's merchant account.
