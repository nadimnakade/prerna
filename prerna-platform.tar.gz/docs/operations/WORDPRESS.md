# WordPress content operations

## Responsibility boundary

WordPress owns public editorial content only. Donors, donation requests, approvals, payments, receipts, mandates, and reports remain in PostgreSQL and are never copied into WordPress or MariaDB.

## Roles

- Administrator: manages users, theme activation, platform updates, recovery, and configuration.
- Editor: creates, previews, publishes, updates, and unpublishes pages, programmes, stories, documents, and leadership profiles. Editors cannot install plugins, edit theme files, or manage users.

Use a named account for each person. Do not share the local bootstrap accounts outside development.

## Publishing checklist

1. Save new material as Draft and use Preview before publishing.
2. Add a descriptive title, concise excerpt, and approved body content.
3. Add meaningful alternative text to every informative image. Decorative images should use empty alternative text.
4. Complete the SEO title and meta description in the Search and social metadata panel.
5. For programmes, keep the WordPress slug aligned with the active Programme Master mapping in the React admin application.
6. Publish only Prerna-approved copy, images, financial documents, disclosures, and legal text.
7. To remove an item from the public website without deleting its history, change its status to Draft or Private.

Legal pages are seeded as drafts and are omitted from the public footer. Publishing an approved legal page automatically adds its footer link; changing it back to Draft removes the link.

## Enquiry delivery

The Contact and CSR pages include a server-side form with nonce validation, a honeypot, strict field limits, and safe Reply-To handling. Enquiries are sent to the WordPress Administration Email Address. Before production launch, configure that address for Prerna's nominated recipient and configure authenticated transactional SMTP; PHP's default local mail transport is not a production delivery mechanism. Do not place secrets in page content or theme files.

## Media constraints

- Images: WebP, JPEG, or PNG; maximum 2400 px on the longest edge; target less than 500 KB.
- Documents: PDF only for public reports and disclosures; use searchable text and an accessible document title.
- Video: host on an approved video platform and embed it; do not upload large video files to WordPress.
- Never upload donor data, identity documents, payment records, internal reports, credentials, or secrets.

## Programme donation mapping

WordPress asks the application API for active Programme Master mappings. A programme slug is added to a Donate URL only when the API confirms it is active. If the API is unavailable, a mapping is missing, or a programme is disabled, the Donate action safely opens unallocated giving without a programme parameter.

Mappings are cached in WordPress for five minutes. Allow up to five minutes after changing Programme Master, or clear WordPress transients during an urgent correction.

## Backup and recovery

Back up both the `wordpress_data` Docker volume and the MariaDB database. A database-only backup does not contain uploaded media; a files-only backup does not contain content or configuration.

Example local database backup:

```powershell
docker compose exec -T mariadb mariadb-dump -u root -p$env:MARIADB_ROOT_PASSWORD wordpress > wordpress.sql
```

Store backups encrypted outside the host and test restoration on a separate environment. Recovery order is MariaDB, WordPress files/uploads, version-controlled theme and must-use plugin, then smoke tests for the homepage, one programme, one story, one document, login, and donation handoff.

## Updates

1. Take and verify a database plus uploads backup.
2. Rehearse the update in a non-production environment.
3. Review WordPress and PHP compatibility notes.
4. Update the pinned image version in `compose.yml`; do not update production from the WordPress dashboard.
5. Rebuild, run PHP syntax checks, and complete responsive browser tests.
6. Roll back the image version and restore both backup parts if verification fails.

The dashboard file editor is disabled. Theme and content-model code changes must go through version control and the normal release process.
