# Donation journey operations

## Responsibility boundary

The React journey creates a verified donation request for administrative review. It never creates a payment, payment link, receipt, or mandate. Those actions belong to later approval and payment workflows.

## Verification configuration

`PRERNA_VERIFICATION_PROVIDER` selects the registered verification adapter. Local development uses `local`, which deterministically issues `123456` and displays it in the browser only when the API environment is `development` or `test`. Production responses never include a verification code.

Set `PRERNA_VERIFICATION_OTP_MINUTES` between 2 and 30 to control expiry. A contact target can request at most five codes per hour and each code permits at most five incorrect attempts. Replace the local adapter with an approved provider adapter before production launch; the donation workflow depends only on the provider interface.

## Sensitive data

- Protected identifiers are normalized, encrypted for recovery, HMAC-digested for matching, and masked for display.
- Full identifiers are not returned from an API and must not be added to application logs.
- Browser state exists only in React memory; the journey does not persist form values in local or session storage.
- Email and mobile are normalized before matching and masked in donation-request records returned to downstream workflows.

## Idempotency and recovery

Every browser journey generates one `Idempotency-Key` and reuses it for retries. PostgreSQL enforces uniqueness, so repeated submissions return the original request and do not create another donor or request.

If submission fails, the donor can retry while the verification token remains valid. A refresh intentionally clears the form to avoid leaving sensitive values on a shared device.
