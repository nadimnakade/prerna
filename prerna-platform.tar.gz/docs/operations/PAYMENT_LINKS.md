# Payment links

The approval workflow issues a payment link only after an immutable `APPROVE` decision. Issuance locks the donation request, records the provider reference and expiry, moves the request to `PAYMENT_LINK_SENT`, and creates a pending communication job in the same transaction. Message delivery is intentionally asynchronous and cannot roll back an approval or link.

## Local development

The default `PRERNA_PAYMENT_GATEWAY=local` adapter creates contract-compatible links without contacting Razorpay. `PRERNA_LOCAL_PAYMENT_BASE_URL` controls the destination. Retrying an active link returns the same URL and does not create another provider link or communication job.

## Production Razorpay configuration

Select Razorpay only through the production secret store:

```text
PRERNA_ENVIRONMENT=production
PRERNA_PAYMENT_GATEWAY=razorpay
PRERNA_RAZORPAY_KEY_ID=rzp_live_...
PRERNA_RAZORPAY_KEY_SECRET=...
```

Both credentials are mandatory. The application refuses to construct the real Razorpay adapter outside the production environment, so development and test runs cannot accidentally create real payment links. Never commit these values or include them in support logs.

## Token lifecycle

- Each internal access token is generated with a cryptographically secure random source. Only its SHA-256 hash is used for lookup and single-use consumption.
- An encrypted copy is retained solely so an administrator can safely recover an active link after a retry. The raw token is returned in the URL fragment, which browsers do not send in HTTP requests or access logs.
- Validity comes from the `payment_link_validity_hours` business setting (24 hours by default). An expired or consumed link may be reissued while the request remains `PAYMENT_LINK_SENT`.
- Consumption is atomic. The first valid use records `used_at`; subsequent, expired, or unknown tokens receive a generic unusable response.

The encrypted retry token is derived from `PRERNA_IDENTIFIER_ENCRYPTION_KEY`. Rotating that key requires expiring all outstanding payment links first, or migrating their ciphertext under both old and new keys before deployment.

## Operational checks

Before enabling Razorpay in production, verify HTTPS origins, PostgreSQL connectivity, the dedicated identifier keys, the configured link-validity setting, outbound access to `api.razorpay.com`, and processing of pending communication jobs. Exercise approval, safe retry, expiry/reissue, and single-use consumption in the release environment without printing response bodies containing link fragments.
