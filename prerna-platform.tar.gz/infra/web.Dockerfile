FROM node:24-alpine AS build

WORKDIR /app
ARG APP_WORKSPACE
COPY package.json package-lock.json ./
COPY apps/admin-web/package.json ./apps/admin-web/package.json
COPY apps/donation-web/package.json ./apps/donation-web/package.json
RUN npm ci
COPY apps/admin-web ./apps/admin-web
COPY apps/donation-web ./apps/donation-web
RUN npm --workspace "${APP_WORKSPACE}" run build

FROM nginx:1.29-alpine AS runtime
ARG APP_PATH
COPY infra/web-nginx.conf /etc/nginx/conf.d/default.conf
COPY --from=build /app/apps/${APP_PATH}/dist /usr/share/nginx/html
EXPOSE 8080
HEALTHCHECK --interval=15s --timeout=5s --retries=10 CMD wget --spider -q http://127.0.0.1:8080/healthz || exit 1
