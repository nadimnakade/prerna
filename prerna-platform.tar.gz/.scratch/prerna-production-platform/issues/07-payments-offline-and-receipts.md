# 07 — Implement payments, offline donations, receipts, and communications

Status: ready-for-agent
Blocked by: 06

## Outcome

Complete one-time online and offline financial processing from verified event through receipt and communication history.

## Work

- Verify Razorpay signatures over raw webhook bodies, insert provider events once, acknowledge quickly, and process asynchronously.
- Implement success, failure, abandonment, amount mismatch, unknown event, replay, and out-of-order handling.
- Implement offline Option A collection plus finance confirmation and Option B payment-link continuation.
- Generate immutable receipt records and PDFs with transaction-safe numbering and MinIO storage.
- Implement communication events, templates, consent enforcement, retries, and visible failed-delivery state using parked adapters.

## Acceptance

- Duplicate webhooks cannot duplicate payments or receipts.
- Failed receipt rendering or communication does not reverse a confirmed payment and can be retried safely.
- Offline origin remains visible through payment, receipt, donor history, and reports.
- Finance and admin screens expose real records, filters, details, and recovery actions.
