# 10 — Deliver operational and financial reports

Status: ready-for-agent
Blocked by: 07, 08, 09

## Outcome

Implement the complete reporting area, including the requested payment and total monthly donation reporting.

## Work

- Implement donation register, pending approvals, programme summary, donor history statement, recurring mandate register, and CSR contribution report.
- Implement the monthly donation summary with total amount, successful/failed collections, one-time versus recurring totals, and programme breakdown.
- Add date, programme, mode, status, origin, donor, frequency, and corporate filters where applicable.
- Generate CSV/XLSX exports asynchronously with consistent totals, explicit timezone, INR formatting, expiring download links, and export history.
- Ensure dashboard KPIs use the same query definitions as reports.

## Acceptance

- UI totals, downloaded totals, and direct PostgreSQL verification agree for seeded boundary datasets.
- Month boundaries, leap dates, empty periods, failed payments, refunds/corrections if supported, and offline-origin online payments are covered.
- Large exports do not block HTTP workers and cannot be downloaded by another session.
- Report filters are reflected in export files and reproducible from export metadata.
