# 05 — Build the donation journey and verification seams

Status: resolved
Blocked by: 02, 03, 04

## Outcome

Deliver the mobile-first donor request journey for one-time and monthly intent, including returning-donor matching and provider-neutral verification.

## Work

- Implement the five-step React form, programme preselection, donor details, address, protected identifier, preferences/consent, frequency, amount, review, and confirmation.
- Add draft-safe navigation and accessible validation without persisting sensitive values in browser storage.
- Implement rate-limited OTP and identity-verification interfaces with deterministic local adapters and contract tests.
- Match returning donors by normalized email/mobile and protected-identifier matching keys without exposing whether an unrelated donor exists.
- Create/update donor preferences only from explicit consent.

## Acceptance

- New, returning, invalid-verification, retry, expired-OTP, duplicate-submit, and monthly-intent browser scenarios pass.
- Submission creates a donor and request exactly once and never creates a payment.
- Sensitive data is masked in all subsequent responses and logs.
- Provider selection can change through configuration without editing workflow code.

## Answer

Delivered the five-step React donation-request journey with validated WordPress programme preselection, one-time/monthly intent, donor and address capture, protected identifier handling, contact verification, explicit communication consent, review, and confirmation. Draft values remain in React memory only.

Added a provider-neutral verification interface with a deterministic local adapter, persistent rate-limited OTP sessions, expiry and retry enforcement, and configuration-driven provider selection. Returning donors are matched using normalized email/mobile and protected-identifier HMAC keys without exposing unrelated records.

Submission uses a PostgreSQL-enforced idempotency key, creates or updates the donor and preferences only after explicit consent, creates one pending donation request, and never creates a payment.

Verified on 13 October 2026:

- New donor, returning donor, invalid identity, incorrect OTP, expired OTP, duplicate submission, and monthly intent contract scenarios pass.
- Live browser flow passed through programme selection, monthly intent, donor/address entry, OTP issue and confirmation, preference step, masked review, and responsive 390 px rendering without console errors or horizontal overflow.
- Active Education mapping preselects from `?programme=education`; unavailable mappings safely select the first active programme.
- PostgreSQL is at migration `20261013_0004`; live payment count remained zero.
- Ruff, 148 Python tests, TypeScript, ESLint, all React tests, Compose validation, and diff checks pass.
