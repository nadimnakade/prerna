# 03 — Build the operational admin shell and masters

Status: resolved
Blocked by: 01, 02

## Outcome

Deliver the real responsive admin application structure and the masters required by subsequent workflows.

## Work

- Implement authentication, session restoration, logout, protected routing, responsive sidebar, breadcrumbs, user menu, global error handling, and accessible loading/empty states.
- Add navigation for Dashboard, Donation Requests, Approvals, Donors, Donations, Payments, Offline Donations, Monthly Mandates, Receipts, Communications, Reports, Reconciliation, Form 10BD/10BE, Masters, Settings, and Admin Users.
- Implement Programme, Donation Mode, Communication Template, Receipt Series, Financial Year, and lookup masters with validation and active/inactive behavior.
- Implement configurable settings and add/deactivate admin-user workflows.
- Map Programme Master records to WordPress slugs.

## Acceptance

- Every sidebar destination resolves; unfinished later-ticket destinations are clearly marked as scheduled rather than falsely functional.
- Master CRUD persists in PostgreSQL, enforces uniqueness, and records the actor.
- Deactivated users cannot start or continue sessions.
- Desktop, tablet, and mobile browser tests pass keyboard and basic accessibility checks.

## Answer

Implemented the authenticated React admin shell with responsive navigation, breadcrumbs, protected routes, session restoration, logout, dashboard, approvals, masters, settings, and admin-user management. Every planned destination now resolves, with later-ticket workflows explicitly labelled as scheduled.

Added PostgreSQL-backed Programme, Donation Mode, Communication Template, Receipt Series, Financial Year, and Lookup masters with uniqueness enforcement, actor/timestamp auditing, active/inactive state, and WordPress slug mapping for programmes. Added configurable business-setting APIs and admin-user create/deactivate workflows; deactivation revokes active sessions and blocks future login.

Verification:

- API suite: 145 passed, 3 skipped.
- Admin and donor web typecheck, lint, and tests passed.
- Alembic schema drift check passed with no pending upgrade operations.
- All ten local services are healthy.
- Desktop, tablet, and 390px mobile browser checks passed for navigation, scheduled routes, responsive layout, accessible labels/focus affordances, and a clean error/warning console.
