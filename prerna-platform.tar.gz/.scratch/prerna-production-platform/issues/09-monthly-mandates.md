# 09 — Implement monthly mandates and recurring collections

Status: ready-for-agent
Blocked by: 06, 07, 08

## Outcome

Deliver Razorpay-supported monthly giving with one approval followed by independently recorded monthly debits.

## Work

- Implement mandate creation/authorization, active/cancelled/failed states, provider references, minimum amount setting, and cancellation behavior.
- Process recurring debit webhooks idempotently; create one payment and receipt per successful debit.
- Implement failed-debit retry/pause behavior as a configurable policy pending Prerna confirmation.
- Add admin mandate list/detail, donor history integration, worker schedules, and communication events.

## Acceptance

- A mandate cannot be activated before request approval and donor authorization.
- Subsequent debits do not repeat approval or OTP.
- Replayed debit events do not duplicate payments or receipts.
- Active, cancelled, failed, successful-debit, and retry scenarios pass contract, integration, and browser tests.
