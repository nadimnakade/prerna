# 08 — Deliver Donor Master and complete donor history

Status: ready-for-agent
Blocked by: 05, 07

## Outcome

Provide the BRD Donor Master rather than deriving donor details from request rows.

## Work

- Implement donor search, pagination, filters, returning status, corporate/individual type, contact details, masked identifiers, addresses, preferences, and consent history.
- Implement profile tabs for requests, donations, payments, receipts, mandates, communications, and operational history.
- Allow controlled contact/preference corrections while retaining financial history and preventing destructive deletion.
- Add a donor history statement entry point and secure receipt downloads.

## Acceptance

- Staff can locate a donor by supported identifiers without exposing full protected values.
- Every related record is traceable from the profile and amounts reconcile with payment records.
- Preference changes record actor/time and immediately affect future communications.
- Browser tests cover new, returning, corporate, opted-out, and multi-donation donors.
