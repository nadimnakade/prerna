# 04 — Deliver the WordPress public website and CMS

Status: resolved
Blocked by: 01, 03

## Outcome

Provide Prerna's content team with the public website and WordPress editing experience required by the SOW.

## Work

- Implement the agreed public sections, programme pages, stories, reports/documents, contact/CSR/volunteer content, legal pages, media, navigation, and SEO fields.
- Create a maintainable child theme or custom theme with version-controlled configuration and no business data stored in WordPress.
- Configure Donate actions to open the React journey with a validated programme slug.
- Document content roles, backups, media constraints, update procedure, and recovery.

## Acceptance

- An editor can create, preview, publish, update, and unpublish supported content without code changes.
- Donate actions from a programme page preselect the matching active programme.
- Missing or disabled mappings degrade safely to unallocated/Any giving.
- Public pages meet responsive, accessibility, metadata, and performance budgets defined in the ticket tests.

## Answer

Delivered a version-controlled WordPress public CMS with editable pages, programmes, stories, reports/documents, leadership profiles, navigation, SEO/social metadata, and accessible Contact/CSR enquiry forms. Legal pages remain drafts and stay out of the footer until approved and published.

Programme Donate actions validate the WordPress slug against the API's active Programme Master records and safely fall back to unallocated giving when the mapping is absent, inactive, or unavailable.

Verified on 13 October 2026:

- Editor create, preview/publish, update, unpublish, and cleanup workflow passed against the running WordPress instance.
- Education handoff resolved to `http://donate.localhost:8088?programme=education`; invalid or unavailable mappings fall back to the base Donate URL.
- Desktop and 390 px mobile browser checks passed with ordered headings, labelled form fields, no horizontal overflow, correct navigation switching, metadata, and no console warnings/errors.
- Legal-page publish/draft test showed and then removed the footer link automatically.
- Public homepage, programme, stories, reports, sitemap, and contact routes returned successfully; homepage response remained under the local performance budget.
- PHP syntax checks, Docker Compose validation, Ruff, 145 Python tests, React TypeScript checks, ESLint, and all React tests passed.
