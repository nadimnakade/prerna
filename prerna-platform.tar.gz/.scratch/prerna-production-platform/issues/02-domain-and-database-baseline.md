# 02 — Implement the domain and PostgreSQL baseline

Status: resolved
Blocked by: 01

## Outcome

Create the authoritative schema and domain state machine needed by every BRD workflow.

## Work

- Implement donors, protected identifiers, addresses, preferences, programmes, request programmes, verification attempts, approval decisions, payment links, payments, provider events, offline collections, mandates, mandate transactions, receipts, receipt sequences, communications, settings, workflow history, reconciliation, exports, and certificate-dispatch records.
- Replace the approval-only migration with forward migrations that preserve existing development data where feasible.
- Implement action-based transitions and prohibit unrestricted status mutation.
- Add encryption, matching-key, and masking facilities for PAN and similar identifiers.
- Add transactional uniqueness and foreign-key constraints for financial invariants.
- Seed only explicit development fixtures and configurable business defaults.

## Acceptance

- Alembic upgrades an empty PostgreSQL database to head and downgrades in a disposable test database.
- The exhaustive transition matrix proves no payment, mandate, or offline confirmation can precede approval.
- Concurrency tests cover single-use links, unique provider events, and receipt sequence allocation.
- Sensitive identifiers are encrypted at rest and never returned unmasked.

## Answer

Delivered the authoritative PostgreSQL baseline and action-based workflow state machine. The schema now covers donors, protected identifiers, addresses, preferences, programmes, request-programme intent, verification, approvals, single-use payment links, payments, provider events, offline collections, mandates and debits, receipt sequences and receipts, communications, business settings, workflow history, reconciliation, exports, and certificate dispatch.

Financial transitions reject payment, offline confirmation, and mandate actions before approval. PAN-like identifiers use randomized authenticated encryption for storage, a keyed HMAC digest for matching, and a separately stored masked display value; production rejects local development keys. Database uniqueness, checks, foreign keys, row locks, and atomic conditional updates protect provider idempotency, payment-link consumption, and receipt allocation.

Verification completed on 2026-10-12: an empty disposable PostgreSQL database upgraded to head and downgraded to base; Alembic reported no schema drift on the live local database; all three PostgreSQL concurrency tests passed; 142 local API/domain tests passed with three environment-gated concurrency tests skipped after their separate PostgreSQL run; frontend checks remained green; npm audit reported zero vulnerabilities; all ten Compose services are healthy; and the admin login/dashboard smoke test passed after migration. The disposable migration-test database was removed after verification.
