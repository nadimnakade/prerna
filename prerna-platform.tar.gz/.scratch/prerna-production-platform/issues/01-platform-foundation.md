# 01 — Establish the production-shaped local platform

Status: resolved

## Outcome

Replace the current combined Next.js proof-of-concept structure with independently deployable React admin and donation applications while preserving the verified approval behavior for later migration. Run WordPress, MariaDB, FastAPI, PostgreSQL, Redis, S3-compatible object storage, worker, and reverse proxy through one local Compose project.

## Work

- Create `apps/admin-web` and `apps/donation-web` using React, TypeScript, Vite, React Router, TanStack Query, and the shared design tokens.
- Restructure FastAPI into module packages without changing approved behavior.
- Add the worker entry point and Redis job infrastructure.
- Add WordPress/MariaDB, S3-compatible object storage, PostgreSQL, Redis, API, worker, both React builds, and reverse proxy to Compose.
- Configure local hostnames corresponding to `www`, `donate`, `admin`, and `api`.
- Add health checks, non-root containers where supported, named volumes, secrets documentation, and deterministic setup commands.
- Add CI commands for Python lint/tests, TypeScript checks/tests, builds, migrations, and container configuration.

## Acceptance

- One documented command starts the complete stack from a clean checkout.
- Every service reports healthy and survives restart with persisted database/object data.
- The three web surfaces are origin-separated and route only to their intended backend paths.
- Existing approval tests remain green during the structural migration.

## Answer

Delivered the production-shaped local foundation with separate React admin and donation builds, the existing layered FastAPI approval service, PostgreSQL, Redis/Celery, WordPress/MariaDB, SeaweedFS S3-compatible storage, and an origin-routing Nginx gateway. The full stack starts with `docker compose up --build -d` and defaults to port 8088 through the configurable `GATEWAY_PORT` setting.

Verification completed on 2026-10-11: all ten services became healthy; admin, donation, WordPress, and API host routes responded through the gateway; admin login and the persisted dashboard were exercised end-to-end; PostgreSQL, MariaDB, and object storage survived restart; Python lint and 10 API tests passed; all frontend type checks, lint, three unit tests, and production builds passed; `npm audit` reported zero vulnerabilities; and Compose configuration validation passed.
