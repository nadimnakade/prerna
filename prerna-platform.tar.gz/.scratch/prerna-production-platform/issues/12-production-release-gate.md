# 12 — Pass the production release gate

Status: ready-for-agent
Blocked by: 01, 02, 03, 04, 05, 06, 07, 08, 09, 10, 11

## Outcome

Verify that the locally deployed system is operationally ready and clearly identify external decisions that still block a live public launch.

## Work

- Run full lint, typing, unit, integration, contract, migration, security, browser, build, and container-health suites.
- Perform backup and restore of PostgreSQL, MariaDB, WordPress uploads, and S3-compatible objects into a clean environment.
- Review dependency vulnerabilities, secrets, cookies, origins, headers, upload handling, logs, and protected-data exports.
- Exercise webhook replay, worker restart, partial side-effect failure, database restart, expired session, and concurrent financial operations.
- Complete operator, deployment, recovery, provider activation, and release documentation.
- Produce a launch-blocker checklist for parked providers, Razorpay merchant capabilities, DNS, TLS, and hosting.

## Acceptance

- A clean machine can start the documented local release and pass its smoke tests.
- Backup restoration recreates reconciled financial and document records.
- No unfinished navigation is presented as complete.
- The release report distinguishes application completion from external provider/hosting activation and contains no unverified production-ready claim.
