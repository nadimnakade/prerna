# 11 — Implement reconciliation and Form 10BD/10BE support

Status: ready-for-agent
Blocked by: 07, 08, 10

## Outcome

Complete gateway comparison, statutory data export, and certificate dispatch support without claiming accounting integration or statutory filing.

## Work

- Import or retrieve Razorpay transactions/settlements through the selected supported mechanism and compare them with application payments.
- Surface missing, duplicate, amount, status, and settlement mismatches as reconciliation exceptions with resolution notes.
- Generate the Form 10BD-supporting export format agreed with Prerna's CA.
- Ingest Form 10BE certificates and mapping data, match to donors, dispatch through enabled channels, and flag unmatched/failed records.
- Never generate certificates or file Form 10BD.

## Acceptance

- Reconciliation never silently mutates source payments.
- Repeat imports are idempotent and retain run history.
- Tax exports mask or include protected data according to explicit privileged export rules and are access-controlled.
- Matched, unmatched, duplicate, invalid-file, delivery-failed, and replay scenarios pass.
