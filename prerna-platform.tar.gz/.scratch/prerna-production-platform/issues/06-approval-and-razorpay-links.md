# 06 — Complete approvals and Razorpay payment links

Status: resolved
Blocked by: 02, 03, 05

## Outcome

Replace the approval vertical slice with the complete persisted queue and issue secure Razorpay links only after approval.

## Work

- Add search, filters, waiting time, verification detail, donor history context, returning-donor indicator, internal notes, approve, and reject.
- Persist immutable approval decisions and prevent concurrent double decisions.
- Implement the Razorpay adapter, link issuance, token hashing, expiry, single-use consumption, provider reference storage, and safe retry behavior.
- Keep real Razorpay calls environment-gated; provide a contract-compatible local gateway adapter.
- Emit communication jobs without coupling approval transactions to delivery success.

## Acceptance

- No interface or race can issue a link for an unapproved request.
- Parallel approval and link-consumption tests resolve to one valid result.
- Approved, rejected, expired-link, and reissue flows pass browser and API tests.
- Raw payment tokens and provider secrets never persist or appear in logs.

## Resolution evidence

- The persisted admin queue now supports status/search filters, waiting time, verification state, returning-donor context, previous outcomes, internal notes, approval/rejection, and link recovery/reissue.
- Approval decisions and link issuance are serialized with database locks and immutable workflow/approval records. PostgreSQL concurrency coverage verifies one approval winner, one link creation, and one token-consumption winner when `PRERNA_POSTGRES_TEST_URL` is enabled.
- Payment-link tokens use a SHA-256 lookup hash plus encrypted retry ciphertext; the raw value is returned only in a URL fragment. Expiry, single-use consumption, safe retry, and expired-link reissue are covered by API tests.
- The production-only Razorpay adapter uses the fixed HTTPS provider endpoint and requires both credentials. Development and test environments use the contract-compatible local adapter and refuse real Razorpay construction.
- Issuance stores the provider reference and creates a pending communication job in the same transaction without coupling delivery to the approval decision.
- Browser acceptance verified the pending queue and `PAYMENT_LINK_SENT` detail/recovery states with no console errors. A live retry recovered the same local link without creating a duplicate.
- Validation: Ruff passed; 153 Python tests passed and 5 opt-in PostgreSQL tests skipped; React type checking and linting passed; both Vitest suites passed; Alembic migration `20261013_0005` was applied and previously verified at head. Docker Desktop was unavailable only for the final repeat of the already-completed migration check.
