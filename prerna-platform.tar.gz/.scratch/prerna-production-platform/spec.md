# Prerna Production Platform Delivery

Status: ready-for-agent

Authoritative design: `docs/superpowers/specs/2026-10-11-production-platform-design.md`

## Objective

Deliver the complete BRD application locally with WordPress for the public website and CMS, a React donation journey, a React operational admin application, FastAPI modules, PostgreSQL, Razorpay, Redis, S3-compatible object storage, and background processing.

## Delivery rule

Tickets are executed in dependency order. A ticket is complete only when its navigation and workflows use real PostgreSQL persistence, its migrations and tests pass, and its browser acceptance criteria pass. No placeholder page or simulated financial record is accepted as a completed module.

## Ordered tickets

1. `01-platform-foundation.md`
2. `02-domain-and-database-baseline.md`
3. `03-admin-shell-and-masters.md`
4. `04-wordpress-public-cms.md`
5. `05-donation-journey-and-verification.md`
6. `06-approval-and-razorpay-links.md`
7. `07-payments-offline-and-receipts.md`
8. `08-donor-master.md`
9. `09-monthly-mandates.md`
10. `10-reports-and-exports.md`
11. `11-reconciliation-and-tax-support.md`
12. `12-production-release-gate.md`

## Parked integrations

OTP, identity verification, SMS, WhatsApp, and email remain behind provider interfaces with local simulated adapters. A production release must identify them as unresolved until Prerna selects vendors and provides credentials.
