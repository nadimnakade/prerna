import os
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

ACCENT = "1F4E79"
LIGHT = "DEEAF6"
GATE = "FFF2CC"

doc = Document()

st = doc.styles["Normal"]
st.font.name = "Calibri"
st.font.size = Pt(10.5)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Calibri")
st.paragraph_format.space_after = Pt(6)
st.paragraph_format.line_spacing = 1.08

for name, size, color in (("Heading 1", 18, ACCENT), ("Heading 2", 14, ACCENT), ("Heading 3", 11.5, "2E75B6")):
    s = doc.styles[name]
    s.font.name = "Calibri"
    s.font.size = Pt(size)
    s.font.color.rgb = RGBColor.from_string(color)
    s.font.bold = True
    s.paragraph_format.space_before = Pt(14 if name != "Heading 3" else 10)
    s.paragraph_format.space_after = Pt(6)

for s in doc.sections:
    s.left_margin = s.right_margin = Inches(0.85)
    s.top_margin = Inches(0.8)
    s.bottom_margin = Inches(0.75)


def shade(cell, hexcolor):
    el = OxmlElement("w:shd")
    el.set(qn("w:val"), "clear")
    el.set(qn("w:fill"), hexcolor)
    cell._tc.get_or_add_tcPr().append(el)


def para(text, size=10.5, bold=False, italic=False, align=None, space_after=6, color=None):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.font.size = Pt(size)
    r.bold = bold
    r.italic = italic
    if color:
        r.font.color.rgb = RGBColor.from_string(color)
    if align:
        p.alignment = align
    p.paragraph_format.space_after = Pt(space_after)
    return p


def bullet(text, level=0):
    p = doc.add_paragraph(text, style="List Bullet")
    p.paragraph_format.left_indent = Inches(0.25 + 0.25 * level)
    p.paragraph_format.space_after = Pt(3)
    return p


def code(text):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.font.name = "Consolas"
    r.font.size = Pt(8)
    r._element.rPr.rFonts.set(qn("w:eastAsia"), "Consolas")
    p.paragraph_format.space_after = Pt(8)
    p.paragraph_format.space_before = Pt(4)
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:fill"), "F2F2F2")
    p._p.get_or_add_pPr().append(shd)
    return p


def table(headers, rows, widths=None, header_fill=ACCENT, row_fills=None):
    t = doc.add_table(rows=1, cols=len(headers))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr = t.rows[0].cells
    for i, h in enumerate(headers):
        hdr[i].text = ""
        p = hdr[i].paragraphs[0]
        r = p.add_run(h)
        r.bold = True
        r.font.size = Pt(9.5)
        r.font.color.rgb = RGBColor.from_string("FFFFFF")
        shade(hdr[i], header_fill)
    for ri, row in enumerate(rows):
        cells = t.add_row().cells
        fill = row_fills[ri] if row_fills and ri < len(row_fills) else None
        for ci, val in enumerate(row):
            cells[ci].text = ""
            p = cells[ci].paragraphs[0]
            p.paragraph_format.space_after = Pt(2)
            r = p.add_run(str(val))
            r.font.size = Pt(9)
            if ci == 0 and len(headers) > 2:
                r.bold = True
            if fill:
                shade(cells[ci], fill)
    if widths:
        for ri in range(len(t.rows)):
            for ci, w in enumerate(widths):
                t.rows[ri].cells[ci].width = Inches(w)
    doc.add_paragraph().paragraph_format.space_after = Pt(4)
    return t


def footer_page_numbers():
    footer = doc.sections[0].footer
    p = footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("Prerna Platform — Project Plan & Technical Approach   |   Page ")
    r.font.size = Pt(8)
    r.font.color.rgb = RGBColor.from_string("808080")
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), "PAGE")
    p._p.append(fld)


# ============================================================ TITLE
para("PRERNA", size=11, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=0, color=ACCENT)
para("Website & Basic Donor Management Application", size=13, italic=True,
     align=WD_ALIGN_PARAGRAPH.CENTER, space_after=26, color="595959")

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run("Project Plan and\nTechnical Approach")
r.font.size = Pt(30)
r.bold = True
r.font.color.rgb = RGBColor.from_string(ACCENT)
p.paragraph_format.space_after = Pt(18)

para("Prepared for CTO review", size=12, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, space_after=4)
para("14 working weeks  ·  5 stages  ·  4 approval gates", size=11,
     align=WD_ALIGN_PARAGRAPH.CENTER, space_after=30, color="595959")

table(
    ["Field", "Detail"],
    [
        ["Client", "Prerna (IRPrerna) — Section 8 Company"],
        ["Programmes", "Education · Healthcare · Sports"],
        ["Service provider", "Kavach"],
        ["Document", "Project Plan & Technical Approach — v1.0"],
        ["Date", "26 September 2026"],
        ["Governing documents", "Prerna BRD v1.1 · Scope of Work v2.0 · requirement.md"],
        ["Status", "DRAFT — for CTO review, pending Gate 1"],
    ],
    widths=[1.6, 5.3],
)

doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)

# ============================================================ 1 EXEC
doc.add_heading("1. Executive Summary", level=1)
para(
    "Prerna is a newly incorporated Section 8 company with no website and no way to accept donations "
    "digitally. Corporate CSR teams routinely check an organisation's website, governance and financial "
    "disclosures before releasing funds — without a credible online presence Prerna is largely invisible "
    "to that funding base."
)
para(
    "This engagement delivers two things: an 11-section public website that Prerna's non-technical staff "
    "can maintain without a developer, and a basic donor management application that accepts online, "
    "offline, one-time and monthly donations — with receipts, reporting and gateway reconciliation."
)

doc.add_heading("1.1 The one rule that shapes everything", level=2)
p = doc.add_paragraph()
r = p.add_run(
    "Every donation request, at any amount, requires Prerna's explicit approval BEFORE any payment can "
    "be taken. There is no automatic approval — and returning donors are re-approved every time."
)
r.bold = True
r.font.size = Pt(11)
r.font.color.rgb = RGBColor.from_string("C00000")
para(
    "This is a deliberate choice by Prerna's founder to review every donor before accepting funds. "
    "It adds friction to the donor journey and is not open to redesign. Our design makes the approval "
    "step as smooth as possible — it does not work around it."
)

doc.add_heading("1.2 Design consequences", level=2)
for b in [
    "Approval is enforced structurally by the state machine, not by convention: no code path can reach a paid state without passing through approved.",
    "Every third-party provider sits behind a port with a simulated default, so construction never blocks on vendor onboarding.",
    "All nine unresolved business decisions are database settings with reversible defaults — no guess is hard-coded.",
    "Website content (CMS schema) is structurally separate from donation data (donations schema), per SOW 7.1.",
    "A modular monolith: one API, one database, one worker codebase — deliberately not microservices.",
]:
    bullet(b)

doc.add_heading("1.3 What we are NOT building", level=2)
para(
    "Contractually excluded: role-based access control (single admin level agreed) · audit logging · "
    "backup/DR/HA · managed security, SOC/SIEM, VAPT, PCI-DSS · full CRM · bank-statement reconciliation · "
    "accounting/ERP integration · donor self-service portal · native apps · multilingual · newsletters "
    "and marketing · foreign currency · Aadhaar collection · complex priority engine · data migration · "
    "Form 10BD filing · Form 10BE generation · expenditure-utilisation reporting · content creation.",
    size=9.5, italic=True,
)

# ============================================================ 2 STACK
doc.add_heading("2. Technology Stack", level=1)
para("Fixed by requirement.md. Containerised on Python 3.12 because the host toolchain ships Python 3.14, "
     "where Pydantic / SQLAlchemy / Celery wheel availability is not yet guaranteed.", size=9.5, italic=True)

doc.add_heading("2.1 Frontend — apps/web", level=2)
table(["Layer", "Choice", "Rationale"], [
    ["Framework", "Next.js 15 (App Router)", "SSG/ISR for public pages, SSR for admin"],
    ["Language", "TypeScript 5.x, strict", "No any in domain-facing types"],
    ["UI", "React 19", ""],
    ["Styling", "Tailwind CSS v4", "Mobile-first, fast iteration"],
    ["Components", "shadcn/ui + Radix", "Accessible, no vendor lock-in"],
    ["Forms", "React Hook Form + Zod", "Zod schemas generated from Pydantic — cannot drift"],
    ["Data", "TanStack Query v5", "All API calls isolated in features/*/services"],
    ["Charts", "Recharts", "Dashboard only, where it aids comprehension"],
    ["E2E", "Playwright", "18 critical scenarios"],
    ["Quality", "ESLint + Prettier", "CI gate"],
], widths=[1.1, 2.2, 3.6])

doc.add_heading("2.2 Backend — apps/api", level=2)
table(["Layer", "Choice", "Rationale"], [
    ["Runtime", "Python 3.12 (pinned in container)", "Avoids 3.14 wheel risk"],
    ["Framework", "FastAPI", "Async, OpenAPI generated automatically"],
    ["Validation", "Pydantic v2, strict mode", "Server-side authority"],
    ["ORM", "SQLAlchemy 2.0 async", "No string-built SQL anywhere"],
    ["Migrations", "Alembic", "Discrete migrate step; never auto-migrate in production"],
    ["Database", "PostgreSQL 16", "Two schemas: cms and donations"],
    ["Queue", "Celery 5 + Redis 7", "Worker + beat (expiry sweep, debits, retries)"],
    ["Passwords", "argon2id (argon2-cffi)", "Modern password hashing"],
    ["PDF", "WeasyPrint", "Receipt = HTML/CSS stored as a setting — serves open decision 4"],
    ["Storage", "boto3 to MinIO (dev) / S3 (prod)", "Behind IObjectStorage port"],
    ["Crypto", "cryptography — AES-GCM + HMAC", "Identifiers encrypted at rest, matched without decrypting"],
    ["Logging", "structlog + redaction filter", "Never logs password, OTP, card, PAN, full identifier"],
    ["Tests", "pytest · Playwright", "Unit, integration, API, webhook, idempotency, security, E2E"],
    ["Quality", "ruff · mypy strict · import-linter", "Layer boundaries enforced in CI, not by convention"],
], widths=[1.1, 2.4, 3.4])

doc.add_heading("2.3 Infrastructure", level=2)
table(["Item", "Choice"], [
    ["Containers", "Docker + Compose: db · redis · api · worker · beat · web · minio"],
    ["Reverse proxy", "Caddy (staging/production) — automatic TLS"],
    ["CI/CD", "GitHub Actions — lint, typecheck, pytest, Playwright, build, deploy"],
    ["Environments", "Development · Staging (Prerna review + UAT) · Production (Prerna's hosting)"],
    ["Secrets", "Environment only; .env.example committed, .env gitignored — never in settings table"],
    ["Package managers", "pnpm 9 (web) · uv (api, lockfile-pinned)"],
], widths=[1.4, 5.5])

doc.add_heading("2.4 Providers — all behind ports, simulated by default", level=2)
para("SOW 7.1 committed approach: build and test against simulated providers (the Integration Test "
     "Harness), then connect live adapters as accounts become available. Delivery never waits on "
     "provider onboarding. A shared contract suite runs against both — a live adapter passes Gate 3 "
     "only by passing the identical suite.", size=9.5, italic=True)
table(["Port", "Default", "Live candidates", "Switch"], [
    ["IPaymentGateway", "SimulatedPaymentGateway", "Razorpay (subject to onboarding)", "PROVIDER_PAYMENT_MODE"],
    ["IOtpProvider / ISmsProvider", "Simulated", "MSG91 · Twilio · Karix (DLT required)", "PROVIDER_OTP_MODE"],
    ["IIdentityVerificationProvider", "Simulated", "Digio · Karza · Signzy", "PROVIDER_IDENTITY_MODE"],
    ["IEmailProvider", "Simulated", "AWS SES · Resend · SMTP", "PROVIDER_EMAIL_MODE"],
    ["IWhatsAppProvider", "Simulated", "Meta Cloud API via BSP", "PROVIDER_WHATSAPP_MODE"],
    ["IObjectStorage", "MinIO", "Amazon S3", "STORAGE_ENDPOINT"],
    ["IReceiptRenderer", "WeasyPrint", "same", "-"],
], widths=[1.7, 1.6, 2.3, 1.5])

# ============================================================ 3 ARCH
doc.add_heading("3. Architecture", level=1)
doc.add_heading("3.1 Shape", level=2)
para("Modular monolith. One FastAPI application, one PostgreSQL database with two schemas, one Celery "
     "codebase, one Next.js application. Two schemas satisfy SOW 7.1 — CMS content structurally separate "
     "from donation data — without paying for a second database.")
code(
    "Public donor -> apps/web (Next.js 15) -- REST /api/v1 --> apps/api (FastAPI)\n"
    "                   (public) SSG/ISR             |                |\n"
    "                   (admin)  SSR + cookie         |       api > application > domain\n"
    "                                                 |                 |\n"
    "                          +----------------------+---+   repositories / services\n"
    "                          |  PostgreSQL 16          |          |\n"
    "                          |   schema cms            |   infrastructure > integrations/ports\n"
    "                          |   schema donations      |          |\n"
    "                          +-------------------------+   MinIO · Redis · Celery\n"
    "                                                                |\n"
    "                                     Gateway · OTP/SMS · Identity · Email · WhatsApp\n"
    "                                     (simulated by default — Integration Test Harness)"
)

doc.add_heading("3.2 Backend layers", level=2)
code(
    "api/  -->  application/  -->  domain/          (no I/O below this line)\n"
    "                 |-- services/\n"
    "                 |-- repositories/ --> models/\n"
    "                 +-- integrations/ports <-- infrastructure/"
)
for b in [
    "api/ — HTTP binding only. No business logic.",
    "application/ — the single transaction boundary; the only place that composes.",
    "domain/ — state machine and business rules as pure code. Zero I/O.",
    "services/ — cross-entity logic: receipt numbering, ageing, reconciliation matching. Zero I/O.",
    "integrations/ — every third-party isolated behind a port.",
    "Import direction is lint-enforced in CI (import-linter). The monolith stays splittable without that being a goal.",
]:
    bullet(b)

doc.add_heading("3.3 State machine — 14 states, 15 transitions", level=2)
para("The transition table is data, covered by an exhaustive 14x14 test. The API exposes actions only "
     "(verify, approve, reject, issue-link, record-collection, confirm-finance, cancel-mandate). "
     "There is no endpoint that accepts a raw status value.", size=9.5, italic=True)
table(["From", "To", "Trigger", "Actor"], [
    ["SUBMITTED", "VERIFIED", "OTP + identity pass", "system"],
    ["VERIFIED", "PENDING_APPROVAL", "automatic", "system"],
    ["PENDING_APPROVAL", "APPROVED", "approve", "admin"],
    ["PENDING_APPROVAL", "REJECTED", "reject (terminal)", "admin"],
    ["APPROVED", "LINK_ISSUED", "link issued — one-time / offline Option B", "system"],
    ["APPROVED", "MANDATE_ACTIVE", "mandate authorised", "donor + gateway"],
    ["APPROVED", "RECORDED_OFFLINE", "record collection — Option A", "admin"],
    ["LINK_ISSUED", "PAID", "verified capture webhook", "gateway"],
    ["LINK_ISSUED", "FAILED", "gateway failure", "gateway"],
    ["LINK_ISSUED", "EXPIRED", "past validity (terminal)", "worker"],
    ["FAILED", "LINK_ISSUED", "retry while valid", "donor"],
    ["RECORDED_OFFLINE", "RECEIPT_CONFIRMED", "finance confirms deposit", "admin"],
    ["PAID", "RECEIPTED", "receipt generated + dispatched (terminal)", "worker"],
    ["RECEIPT_CONFIRMED", "RECEIPTED", "receipt generated + dispatched (terminal)", "worker"],
    ["MANDATE_ACTIVE", "MANDATE_CANCELLED", "cancel (terminal)", "admin / gateway / donor"],
], widths=[1.5, 1.6, 2.6, 1.4],
   row_fills=[None] * 3 + [LIGHT] + [None] * 4 + [GATE] + [None] * 5)

p = doc.add_paragraph()
r = p.add_run("BRL-01 is structural, not procedural: ")
r.bold = True
p.add_run("no transition reaches PAID or RECORDED_OFFLINE without passing APPROVED. Enforcing the "
          "approval rule is a property of the table, not a code-review habit.")

doc.add_heading("3.4 Idempotency — five mechanisms", level=2)
for b in [
    "Webhook: insert into payment_events first; unique violation = already processed = 200, no side effects.",
    "Receipt: one receipt per payment (partial unique index).",
    "Receipt numbers: allocated under SELECT ... FOR UPDATE on receipt_sequences — serial, race-free, never reused.",
    "Payment link: atomic UPDATE ... WHERE used_at IS NULL AND expires_at > now() — no read-then-write race.",
    "Celery: dedupe key event:entity_id plus a database state guard before any side effect.",
]:
    bullet(b)

# ============================================================ 4 REPO
doc.add_heading("4. Repository Structure", level=1)
code(
    "prerna/\n"
    "+-- apps/\n"
    "|   +-- api/\n"
    "|   |   +-- app/\n"
    "|   |   |   +-- api/            routers, deps, schema binding\n"
    "|   |   |   +-- core/           settings, security, errors, logging\n"
    "|   |   |   +-- domain/         state machine, business rules, entities\n"
    "|   |   |   +-- services/       receipt numbering, ageing, reconciliation match\n"
    "|   |   |   +-- application/    use cases — the transaction boundary\n"
    "|   |   |   +-- models/         SQLAlchemy ORM\n"
    "|   |   |   +-- repositories/   persistence interfaces + implementations\n"
    "|   |   |   +-- infrastructure/ DB session, S3, crypto, config store\n"
    "|   |   |   +-- integrations/   ports/ + otp/ identity/ payment/ email/ sms/ whatsapp/\n"
    "|   |   |   +-- schemas/        Pydantic DTOs\n"
    "|   |   |   +-- workers/        Celery tasks\n"
    "|   |   |   +-- tests/\n"
    "|   |   +-- alembic/            migrations\n"
    "|   |   +-- pyproject.toml      uv lockfile\n"
    "|   |   +-- Dockerfile\n"
    "|   +-- web/\n"
    "|       +-- src/\n"
    "|       |   +-- app/(public)/   11 sections + donate + status tracker\n"
    "|       |   +-- app/(admin)/    15 screen groups\n"
    "|       |   +-- features/       website donation authentication admin approvals\n"
    "|       |   |                   donors payments mandates receipts reports\n"
    "|       |   |                   reconciliation cms settings\n"
    "|       |   +-- components/ lib/ hooks/ services/ types/\n"
    "|       +-- playwright/\n"
    "|       +-- Dockerfile\n"
    "+-- packages/shared/            generated TS types + Zod from OpenAPI\n"
    "+-- docs/                       architecture · specs · user guides\n"
    "+-- .github/workflows/          ci.yml · cd-staging.yml\n"
    "+-- docker-compose.yml          + docker-compose.test.yml\n"
    "+-- .env.example\n"
    "+-- Makefile\n"
    "+-- README.md"
)

# ============================================================ 5 DATA
doc.add_heading("5. Data Model", level=1)
para("35 tables in the list specified by requirement.md, across two PostgreSQL schemas. Full column "
     "detail is in docs/architecture/ERD.md.", size=9.5, italic=True)
table(["Schema", "Tables"], [
    ["cms", "programmes · cms_pages · cms_page_versions · cms_media · cms_news · cms_stories · "
            "cms_leadership · cms_impact_figures · cms_documents"],
    ["donations — access", "admin_users · admin_sessions"],
    ["donations — donors", "donors · donor_identifiers · donor_preferences"],
    ["donations — request", "donation_requests · donation_request_programmes · verification_records · approval_actions"],
    ["donations — payment", "payment_links · payments · payment_events · offline_donations · gateway_transactions · gateway_settlements"],
    ["donations — recurring", "mandates · mandate_transactions"],
    ["donations — receipt/tax", "receipts · receipt_sequences · form_10bd_exports · form_10be_certificates"],
    ["donations — comms", "communication_events · communication_templates"],
    ["donations — ops", "configuration_settings · workflow_events · reconciliation_exceptions"],
], widths=[1.6, 5.3])

doc.add_heading("5.1 Constraints that carry the business rules", level=2)
table(["Constraint", "Rule protected"], [
    ["donation_requests.status CHECK in 14 values", "State machine integrity"],
    ["donation_request_programmes has no amount column", "BRL-09 — amount is never split between programmes"],
    ["donor_identifiers.kind has no 'aadhaar' value", "BRL-17 — Aadhaar must not be collected"],
    ["payment_links.token_hash UNIQUE + used_at guard", "BRL-05 — unguessable, time-bound, single-use"],
    ["payment_events(gateway, event_id) UNIQUE", "PAY-03 — duplicate webhooks never duplicate a donation"],
    ["receipts.payment_id UNIQUE · receipts.receipt_number UNIQUE", "BRL-14 — one receipt per payment, numbers never reused"],
    ["receipt_sequences row lock", "BRL-14 — safe concurrent number allocation"],
    ["communication_events.dedupe_key UNIQUE", "No duplicate sends"],
    ["mandates.donation_request_id UNIQUE", "BRL-08 — one mandate per approved request"],
    ["offline_donations.finance_confirmed_at gates receipt", "BRL-13 — no receipt before finance confirms"],
    ["no generator path for form_10be_certificates", "BRL-10 — the platform never generates Form 10BE"],
    ["reconciliation_exceptions never cascades to payments", "Never silently overwrite financial records"],
], widths=[3.1, 3.8])
para("Conventions: UUID primary keys · created_at/updated_at everywhere · soft delete on CMS and donor "
     "rows only — financial rows are never deleted · ON DELETE RESTRICT on all financial foreign keys.",
     size=9.5, italic=True)

# ============================================================ 6 EPICS
doc.add_heading("6. Module and Epic Breakdown", level=1)
para("Structure: EPIC - FEATURE - STORY - TASK - ACCEPTANCE CRITERIA", size=9.5, italic=True)
table(["Epic", "Scope", "Requirement IDs", "Week"], [
    ["E0 Foundations", "Repository, Compose, Alembic, auth, config store, provider ports + test harness, CI", "ADM-01/04/05, BRL-18", "3"],
    ["E1 Website + CMS", "11 sections, CMS CRUD / draft / publish / preview, media, SEO, enquiry forms, content load", "WEB-01…WEB-16", "4-6"],
    ["E2 Donation request + verification", "5-step mobile form, OTP, identity, returning-donor prefill", "REQ-01…08, VER-01…05", "7"],
    ["E3 Approval workflow", "Queue, ageing vs 48h, approve/reject/note, search, alerts, decision record", "APR-01…09", "8"],
    ["E4 Online payment", "Link issue/consume/expire, hosted checkout, webhook verify + idempotency", "PAY-01…05, BRL-05", "9"],
    ["E5 Offline donations", "Staff-created request, Option A collection, finance confirm, Option B link, origin tracking", "OFF-01…05", "10"],
    ["E6 Recurring giving", "Mandate setup, authorisation, debits, failure handling, cancellation, minimum amount", "REC-01…08", "11"],
    ["E7 Receipts + communications", "PDF receipt, sequential numbering, templates, 3 channels, consent gate", "COM-01…06, BRL-10…14", "9, 11"],
    ["E8 Donor records", "Profile, masked identifiers, history, returning recognition", "DON-01…03", "10"],
    ["E9 Admin dashboard", "Summary counts, search/filter across all lists", "ADM-02, ADM-03", "8"],
    ["E10 Reporting", "9 reports, CSV/XLSX, Form 10BD export, Form 10BE ingest/dispatch", "RPT-01…09", "12"],
    ["E11 Reconciliation", "Gateway import, comparison, exception review and resolution", "RCN-01", "12"],
    ["E12 Assurance", "Full test suite, UAT, training, documentation, production launch", "SOW 7.3, D7-D10", "13-14"],
], widths=[1.5, 3.2, 1.6, 0.6])

# ============================================================ 7 PLAN
doc.add_page_break()
doc.add_heading("7. Fourteen-Week Delivery Plan", level=1)
para("Five stages, four approval gates, seven two-week sprints. Stages overlap and are sequenced by "
     "technical dependency (SOW section 10). At each gate Kavach pauses for Prerna's written approval.")


def gate_line(text):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold = True
    r.font.color.rgb = RGBColor.from_string("BF8F00")
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(8)


doc.add_heading("Sprint 1 — Weeks 1-2 · Stage 1 Planning and design", level=2)
for b in ["Requirements confirmation; reference review of comparable NGO websites",
          "D1 Architecture and Design document (this plan is its foundation)",
          "D2 Visual design — home page, programme page, donation form, admin approval queue (2 revision rounds)",
          "Database ERD, API specification, UI sitemap and screen list",
          "Requirements traceability matrix and open-decisions register"]:
    bullet(b)
gate_line(">> GATE 1 — Prerna approves design and approach (D1 + D2)")

doc.add_heading("Sprint 2 — Week 3 · Stage 2 Foundations (runs parallel with Stage 3)", level=2)
for b in ["Domain, hosting, SSL and official email configured on Prerna's accounts -> D3",
          "Repository, environments, CI pipeline",
          "Alembic baseline — 19 core tables plus the full schema",
          "Admin auth: argon2id + HttpOnly session cookie",
          "configuration_settings seeded with all nine open decisions",
          "Provider ports + Integration Test Harness (simulated adapters and contract suite)"]:
    bullet(b)

doc.add_heading("Sprint 3 — Weeks 4-5 · Stage 3 Website build", level=2)
for b in ["Sections 1-6: Home · About · Leadership · Programme pages · Impact · Ways to Give",
          "CMS foundation: pages, versions, media upload, draft/publish/preview, SEO metadata",
          "Responsive mobile-first build; first visual-design round applied"]:
    bullet(b)

doc.add_heading("Sprint 4 — Week 6 · Stage 3 completed", level=2)
for b in ["Sections 7-11: Donation page · CSR · News and Stories · Contact and Grievance · Legal",
          "CMS: news, stories, leadership, impact figures, documents, legal, contact",
          "Sitemap, robots.txt, Open Graph metadata, analytics placeholder",
          "Initial content load (Prerna-supplied; placeholders where outstanding)"]:
    bullet(b)
gate_line(">> GATE 2 — Website D4 reviewed on Staging; early public release optional (open decision 8)")

doc.add_heading("Sprint 5 — Weeks 7-8 · Stage 4 Donation system (core first)", level=2)
for b in ["W7 — 5-step donation form (React Hook Form + Zod, mobile-first), OTP flow, identity verification, returning-donor prefill, validation and rate limiting",
          "W7 — State machine plus exhaustive 14x14 transition tests",
          "W8 — Approval queue with ageing, approve / reject / internal note, alerts, decision record, dashboard counts",
          "Playwright: happy path · OTP failure · PAN verification failure · approval · rejection"]:
    bullet(b)

doc.add_heading("Sprint 6 — Weeks 9-10 · Stage 4 continued", level=2)
for b in ["W9 — Payment link issue/consume/expire, hosted checkout, webhook signature verification and idempotency, receipt PDF with sequential numbering, communication events",
          "W10 — Offline donations (Option A and B), finance confirmation, donor records, masking, prefill",
          "Playwright: successful payment · failed payment · expired link · duplicate webhook · offline donation · finance confirmation · returning donor · receipt generation"]:
    bullet(b)

doc.add_heading("Sprint 7 — Weeks 11-12 · Stage 4 completed", level=2)
for b in ["W11 — Recurring: mandate setup, authorisation, debits, failure handling, cancellation; full communication system with templates",
          "W12 — Nine reports with CSV/XLSX export, Form 10BD supporting export, Form 10BE ingestion and dispatch, gateway reconciliation and exceptions",
          "Playwright: monthly mandate · recurring debit · failed debit · Form 10BE dispatch · reconciliation",
          "-> D5 demonstrated end to end · D6 provider connections"]:
    bullet(b)

doc.add_heading("Stage 5 — Weeks 13-14 · Testing, training and launch", level=2)
for b in ["W13 — Integration testing, cross-device and browser matrix, security test pass, bug fixing, Prerna UAT (5 working-day sign-off), live test transaction",
          "W14 — Two remote training sessions (D8), documentation set (D9), production deployment (D10)",
          "After go-live — D11 source repository, credentials and technical handover"]:
    bullet(b)
gate_line(">> GATE 3 (end W13) — real-transaction readiness (D6 + D7)        >> GATE 4 (end W14) — public launch (D8, D9, D10)")

doc.add_heading("7.1 Milestone summary", level=2)
table(["Milestone", "Week", "Deliverable", "Gate"], [
    ["Requirements, architecture, UX, database and API design", "1-2", "D1, D2", "GATE 1"],
    ["Infrastructure, authentication, database, CMS foundation", "3", "D3", "-"],
    ["Public website and content management", "4-6", "D4", "GATE 2"],
    ["Donation form, OTP, verification, approval", "7-8", "-", "-"],
    ["Payments, links, webhooks, receipts, offline, donor records", "9-10", "-", "-"],
    ["Recurring, communications, reports, 10BD/10BE, reconciliation", "11-12", "D5, D6", "-"],
    ["Integration testing, UAT, defect fixing", "13", "D7", "GATE 3"],
    ["Training, documentation, production launch", "14", "D8, D9, D10", "GATE 4"],
], widths=[3.3, 0.7, 1.6, 1.3],
   row_fills=[GATE, None, GATE, None, None, None, GATE, GATE])

# ============================================================ 8 TESTING
doc.add_heading("8. Testing Strategy", level=1)
table(["Layer", "Tool", "Focus"], [
    ["Unit", "pytest", "Exhaustive 14x14 state matrix; all 18 business rules as assertions"],
    ["Integration", "pytest + real Postgres", "Repositories, transactions, unique constraints"],
    ["API", "httpx", "Status codes, problem+json shape, auth enforcement"],
    ["Adapter contract", "Shared suite", "Identical run against simulated and live adapters"],
    ["Webhook", "pytest", "Duplicate, out-of-order, bad signature, amount mismatch"],
    ["Idempotency", "pytest + concurrency", "Parallel receipt numbering, parallel link consumption, replayed webhook"],
    ["Security", "pytest", "Route protection, masking, upload rejection, CORS, rate limits"],
    ["E2E", "Playwright", "The 18 critical scenarios defined in requirement.md"],
], widths=[1.2, 1.5, 4.2])
para("CI gate: lint -> typecheck -> pytest -> Playwright -> build. Coverage thresholds: domain/ 90% or "
     "above, application/ 80% or above (report-only elsewhere — API glue is not worth chasing).",
     size=9.5, italic=True)
para("The 18 critical scenarios: new one-time donation · OTP failure · PAN verification failure · "
     "approval · rejection · expired payment link · failed payment · successful payment · duplicate "
     "payment webhook · offline donation · finance confirmation · monthly mandate · recurring debit · "
     "failed recurring debit · returning donor · receipt generation · Form 10BE dispatch · gateway "
     "reconciliation.", size=9.5)

# ============================================================ 9 SECURITY
doc.add_heading("9. Security Summary", level=1)
para("These are engineering safeguards appropriate to the agreed scope (SOW 7.2). They are not a "
     "security programme, certification or compliance attestation.", size=9.5, italic=True)
table(["Control", "Mechanism"], [
    ["HTTPS", "TLS at reverse proxy (staging/production); Compose bound to localhost in development"],
    ["Admin authentication", "admin_sessions row, argon2id, HttpOnly + Secure + SameSite=Lax cookie, idle and absolute expiry, rotation on login"],
    ["CSRF", "SameSite=Lax plus Origin/Referer check on every mutating admin request"],
    ["Rate limiting", "Redis token bucket on OTP request/verify, login, public request creation"],
    ["Input validation", "Pydantic strict server-side; Zod mirrored client-side"],
    ["SQL injection", "SQLAlchemy ORM only — no string-built SQL anywhere"],
    ["XSS", "React escaping + server-side allowlist sanitiser on CMS rich text + CSP"],
    ["CORS", "Explicit origin allowlist, credentials enabled, no wildcard"],
    ["Security headers", "HSTS, CSP, nosniff, frame-ancestors 'none', Referrer-Policy, Permissions-Policy"],
    ["File uploads", "Extension + magic-byte MIME check, size cap, MinIO outside webroot, signed URL served as attachment"],
    ["Identifier protection", "AES-GCM at rest, HMAC for matching, masked for display; full value never returned by any API"],
    ["Secrets", "Environment only; .env.example committed, .env gitignored; never stored as settings"],
    ["Payment tokens", "256-bit random; SHA-256 hash persisted, raw token never stored; single-use, time-bound"],
    ["Webhook integrity", "HMAC verified on raw body before parsing"],
    ["Logging", "Handler-level redaction of password, OTP, card, PAN and full identifier"],
    ["Authorization", "Every admin route requires a valid session; no role concept exists anywhere (RBAC excluded)"],
], widths=[1.6, 5.3])

# ============================================================ 10 RISKS
doc.add_heading("10. Risks", level=1)
table(["#", "Risk", "Impact", "Mitigation", "Owner"], [
    ["R1", "Gate 3 and Gate 4 both land in weeks 13-14 — zero float", "High",
     "Pull UAT scenarios into week 12; run soft UAT alongside sprint 7", "Kavach"],
    ["R2", "Provider onboarding (gateway KYC, DLT, WhatsApp BSP) slips", "High",
     "Integration Test Harness means build never blocks; but Gate 3 needs one live transaction — start gateway KYC in week 1", "Prerna"],
    ["R3", "Gate 1 inputs outstanding (donor field list, receipt format, comms events, verification policy)", "High",
     "Decisions registered as settings with reversible defaults; D1 cannot be formally accepted until answered", "Prerna + CA"],
    ["R4", "Content supply slips (brand, copy, legal text, disclosures, reports)", "Medium",
     "Gate 2 acceptance explicitly allows placeholders; content deadline is week 5 for launch quality", "Prerna"],
    ["R5", "Recurring not enabled by gateway at launch", "Medium",
     "REC-08 explicitly permits launching without monthly giving and switching it on later", "Prerna + gateway"],
    ["R6", "UAT sign-off capacity (5 working days) not met", "Medium",
     "Book UAT resources in week 10; scenarios delivered with D5", "Prerna"],
    ["R7", "No volume forecasts given — early-stage NGO", "Low",
     "Volumes assumed low; no load or performance engineering (out of scope). Assumption stated in D1", "Both"],
], widths=[0.35, 2.0, 0.6, 3.0, 0.95])

# ============================================================ 11 OPEN
doc.add_heading("11. Open Questions", level=1)
para("Full inventory in docs/architecture/OPEN_DECISIONS.md. 9 tracked business decisions plus 34 "
     "additional questions identified during document review.", size=9.5, italic=True)

doc.add_heading("11.1 Document and scope precedence — blocks Gate 1", level=3)
table(["#", "Question", "Status"], [
    ["A1", "SOW v2.1 or v2.0? The BRD cites v2.1; v2.0 was supplied", "OPEN — blocks everything"],
    ["A2", "Supply Proposal Final, 16 September 2026 — cited as top-precedence, missing", "OPEN — blocks everything"],
    ["A3", "Supply Technical Approach Brief v1.1 or confirm not applicable", "OPEN"],
    ["A4", "Confirm requirement.md's fixed stack overrides BRD 1.1 ('stack is ours to propose')", "Assumed yes"],
    ["A5", "Confirm workflow_events is lifecycle workflow data, not an audit log", "Assumed yes"],
], widths=[0.35, 4.7, 1.85])

doc.add_heading("11.2 Prerna business decisions", level=3)
table(["#", "Decision", "Owner", "Needed before", "Provisional default"], [
    ["B1", "Minimum monthly amount", "Prerna", "Recurring build", "Rs 500"],
    ["B2", "Failed monthly debit handling, incl. pause rule", "Prerna", "Recurring build", "Retry x3, then pause + alert"],
    ["B3", "Final donor field list, incl. Form 10BD fields", "Prerna + CA", "GATE 1", "Name, email, mobile, PAN, address, donor type"],
    ["B4", "Receipt content, format, numbering", "Prerna + CA", "GATE 1", "Configurable HTML template; PRN/FY/000000"],
    ["B5", "Communication events and channels", "Prerna", "GATE 1", "8 events; email always, WhatsApp on opt-in only"],
    ["B6", "What happens when identity verification fails", "Prerna", "GATE 1", "Request stays submitted and retryable"],
    ["B7", "How returning donors are prioritised", "Prerna", "GATE 1", "Sort by waiting time; returning badge shown"],
    ["B8", "Launch the website before the donation system", "Prerna", "GATE 2", "Build both; donate shows holding message if disabled"],
    ["B9", "Provider selection: gateway, SMS/OTP, verification, WhatsApp, hosting", "Prerna (Kavach advises)", "Stage 2", "All adapters simulated"],
], widths=[0.35, 2.4, 1.3, 0.9, 1.95])

doc.add_heading("11.3 New questions surfaced during review", level=3)
para("Not raised anywhere in the BRD or SOW — these need answers and are not yet in any register.",
     size=9.5, italic=True)
table(["#", "Question", "Why it matters"], [
    ["E1", "Is PAN mandatory to submit a request, or optional with verification failing if absent?", "Form validation rule — BRL-03 mandates verification, never says the field is required"],
    ["E2", "Minimum one-time donation amount?", "Only the monthly minimum is tracked as an open decision"],
    ["E3", "Maximum one-time amount?", "Unstated anywhere"],
    ["E4", "Corporate/CSR donor fields — company name, GSTIN, authorised signatory?", "CSR contribution report is unusable without them"],
    ["E5", "Is 'in memory' giving informational only, or a data attribute on the request?", "Changes the donation form schema"],
    ["E6", "Is volunteering informational only, or does it capture enquiries?", "Scope of the website section"],
    ["E7", "Is the CSR enquiry route the same form as contact? Delivered to which address?", "WEB-07 and WEB-13 acceptance"],
    ["E8", "Can one donor hold multiple open requests simultaneously?", "Data rule"],
    ["E9", "Can an APPROVED request be voided after its link expires? EXPIRED is terminal and no such transition exists", "State machine gap"],
    ["E10", "Refunds — post-PAID handling is absent from all three documents; is a refunded status in scope?", "Financial correctness"],
    ["E11", "Receipt reissue to a changed email address — allowed? Does the number change?", "BRL-14 versus practical support"],
    ["E12", "Should self-approval be restricted when the same person records and approves an offline donation?", "BRD says this is Prerna's process control, not a system feature — confirm"],
    ["C1", "Verification policy for staff-assisted / offline requests — is OTP actually sent to a walk-in donor?", "VER-05 references a policy that has not been supplied"],
    ["C6", "What counts as a 'returning donor' — any prior request, or only a completed donation?", "Drives the queue badge and prefill logic"],
], widths=[0.35, 3.4, 3.15])

# ============================================================ 12 NEXT
doc.add_heading("12. Recommended Next Steps", level=1)
table(["Step", "Action", "Owner", "When"], [
    ["1", "Resolve document precedence — confirm SOW version, supply Proposal and Technical Approach Brief", "Prerna / Kavach", "Immediate"],
    ["2", "CTO review of this plan; approve architecture and technical approach", "CTO", "This week"],
    ["3", "Answer Gate 1 decisions (B3-B7) with CA involvement; supply policies and wording (C1-C6, D1-D4)", "Prerna + CA", "Week 1"],
    ["4", "Start gateway merchant KYC, DLT registration and provider selection (B9)", "Prerna", "Week 1"],
    ["5", "Approve visual design direction (D2) within two revision rounds", "Prerna", "Week 2"],
    ["6", "Provision hosting, domain, SSL and official email; establish repository and CI", "Prerna + Kavach", "Week 3"],
    ["7", "Deliver brand assets and final content for all 11 sections", "Prerna", "Week 5"],
], widths=[0.4, 3.9, 1.5, 1.1])

doc.add_heading("12.1 Increment 1 — first build slice", level=2)
para("Before any of the wider scope, we build and prove the financially risky path end to end against "
     "simulated providers:")
for b in ["Repository skeleton and full Compose stack",
          "Alembic baseline — 19 core tables",
          "State machine with exhaustive transition tests",
          "Configuration settings seeded with all nine open decisions",
          "Admin authentication",
          "Public donation form — five steps, mobile-first",
          "Simulated OTP and identity providers plus the shared adapter contract suite",
          "Approval queue with ageing, approve / reject / internal note",
          "Payment link, simulated hosted checkout, signed webhook, PAID",
          "Receipt PDF with configurable template and sequential numbering",
          "Simulated email/SMS adapters and communication events",
          "Celery worker and beat (link-expiry sweep)",
          "workflow_events on every transition",
          "pytest suite plus three Playwright E2E: happy path, OTP failure, duplicate webhook"]:
    bullet(b)
para("Deferred to later increments: the 11 website sections and CMS, offline donations, recurring, "
     "reports, reconciliation, Form 10BD/10BE, live provider adapters, and the remaining 15 E2E scenarios.",
     size=9.5, italic=True)

# ============================================================ APPENDIX
doc.add_page_break()
doc.add_heading("Appendix A — Supporting Documents", level=1)
table(["Document", "Location", "Contents"], [
    ["Architecture", "docs/architecture/ARCHITECTURE.md", "System, module, integration, security and deployment architecture"],
    ["Open Decisions", "docs/architecture/OPEN_DECISIONS.md", "9 business decisions + 9 interpretation questions + dependencies"],
    ["ERD", "docs/architecture/ERD.md", "35 tables, column detail, constraint-to-rule mapping"],
    ["API Route Map", "docs/architecture/API.md", "All /api/v1 routes and the state-machine action surface"],
    ["Design Specification", "docs/superpowers/specs/2026-09-26-prerna-platform-design.md", "Approved design, Sections A-D"],
    ["Business Requirements", "Prerna_BRD_v1.1_Kavach_1.pdf", "20 pages — business rules, requirements, constraints, open decisions"],
    ["Scope of Work", "Prerna_Scope_of_Work_v2.0_Kavach.pdf", "23 pages — scope, deliverables, gates, acceptance, exclusions"],
    ["Requirements brief", "requirement.md", "Technology stack, architecture, module and testing requirements"],
], widths=[1.5, 2.7, 2.7])

doc.add_heading("Appendix B — Requirements Traceability (summary)", level=1)
table(["Group", "Count", "Covered by"], [
    ["WEB — Website", "16", "E1"],
    ["REQ — Donation request", "8", "E2"],
    ["VER — Verification", "5", "E2"],
    ["APR — Approval", "9", "E3"],
    ["PAY — Online payment", "5", "E4"],
    ["OFF — Offline donations", "5", "E5"],
    ["REC — Monthly giving", "8", "E6"],
    ["COM — Receipts and communication", "6", "E7"],
    ["DON — Donor records", "3", "E8"],
    ["ADM — Administration", "5", "E0, E9"],
    ["RPT — Reporting", "9", "E10"],
    ["RCN — Reconciliation", "1", "E11"],
    ["BRL — Business rules", "18", "Enforced structurally in domain/ and database constraints"],
], widths=[2.4, 0.8, 3.7])

footer_page_numbers()

out = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                   "Prerna_Project_Plan_and_Technical_Approach.docx")
doc.save(out)
print("SAVED:", out, os.path.getsize(out), "bytes")
